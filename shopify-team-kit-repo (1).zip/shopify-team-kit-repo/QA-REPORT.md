# QA report: Shopify Team Kit v2.0.0 (final)

Date: 12 Nov 2026. Scope: plugin structure, skills/agents/commands, `quick-audit.sh`, embedded Liquid snippets, and content accuracy against Shopify, W3C and Claude Code documentation.

## Defects found and fixed

| # | Severity | Finding | How found | Fix |
|---|---|---|---|---|
| 1 | High | 8 of 12 slash commands had invalid YAML frontmatter (unquoted `argument-hint` with several `[..]` groups, `: ` inside descriptions). Claude Code could drop their descriptions or fail to load them | PyYAML strict parse of every frontmatter | Quoted all `description` and `argument-hint` values; 0 failures on re-run |
| 2 | High | Audit script flagged 31 HIGH on Dawn (Shopify's reference theme), almost all false positives: focus rings replaced via `box-shadow`, bounded menu loops, error-message `autofocus`, guarded `<h1>`, preconnect/shopifycloud URLs, conditional lazy loading | Ran script on real Dawn clone and read each flagged line | Rule-aware focus check, catalog-aware loop depth, context filters. Dawn now HIGH 0, MED 8 (all legitimate "verify" items). LOW findings hidden by default (`--verbose`) |
| 3 | Medium | Marketplace layout used `source: "./"` (plugin at repo root). Documented examples use `./plugins/<name>`, and a Shopify repo issue reports friction with the root form | Docs and examples review | Restructured to `.claude-plugin/marketplace.json` + `plugins/shopify-team-kit/` |
| 4 | Medium | README gave the Shopify toolkit install command only from a third-party guide; Shopify's own README gives a different pair | Compared sources | README now leads with Shopify's commands and lists the alternative |
| 5 | Medium | Team auto-enable settings were left as "see docs" | Docs review | Exact `extraKnownMarketplaces` / `enabledPlugins` JSON added (format confirmed in Claude Code docs) |
| 6 | Low | Shellcheck: 3 fragile `for x in $(ls/find)` loops | shellcheck 0.x | Replaced with globs and `while read`; shellcheck clean |
| 7 | Low | SEO skill hedged on article structured data | shopify.dev filter reference | Confirmed: `structured_data` supports `product` and `article` only; text updated |
| 8 | Low | Perf and ADA tap-target numbers differed (48 vs 44 vs 24) | Cross-read Shopify perf and a11y pages and WCAG 2.5.8 | Single rule: 44 px minimum on primary controls (48 preferred), never below 24 px |

## Verification evidence

| Check | Standard / tool | Result |
|---|---|---|
| Plugin manifests parse | JSON, Claude Code plugin layout | Pass |
| Skill frontmatter | name matches folder; description under 1,024 chars (max 664); SKILL.md under 500 lines (max 120) | Pass |
| Agent and command frontmatter | YAML parse | Pass after fix 1 |
| Shell script quality | shellcheck | Clean |
| Liquid in skills (section skeleton, head metadata, OG, Organization, Breadcrumb, Product JSON-LD) | Shopify Theme Check (`@shopify/theme-check-node`) on a theme assembled from the kit's own snippets | 0 errors (2 "unused snippet" notes, expected in a demo) |
| Script on seeded-defect theme | 33 planted issues | All HIGH classes caught; clean theme: HIGH 0 |
| Script on real theme | Shopify Dawn | 1 s runtime; HIGH 0, MED 8 |
| `--changed` mode | git branch diff | Only changed files reported |
| Exit codes | 0 clean / 1 HIGH / 2 bad dir; `--no-fail` | Pass |

## Standards coverage

| Standard | What the kit enforces | Statically detectable | Needs manual or tool test |
|---|---|---|---|
| WCAG 2.2 AA (incl. 6 new A/AA criteria) | Build rules + criterion map | 1.4.4 (viewport zoom), 2.4.1 (skip link), 2.4.3 (tabindex), 2.4.7 (focus), 3.1.1 (lang), 4.1.2 (role misuse), parts of 1.1.1 / 3.3.2 | Contrast, keyboard flows, focus not obscured, target size, reflow, screen reader, status messages, auth |
| Shopify Theme Store a11y and perf requirements | Skill rules; Lighthouse target 80 vs store minimum 60 | Deprecated patterns, blocking scripts, CDN/fonts | Lighthouse, Web Performance Dashboard |
| Core Web Vitals | LCP/INP/CLS rules and thresholds | Lazy+fetchpriority conflicts, nested loops, background-image heroes | Real-user data |
| SEO (title, description, canonical, JSON-LD, headings) | Snippets and checklist | Missing canonical/title/description, hardcoded Product JSON-LD, header h1 | Rich Results Test, Search Console |

## Not verified (be aware)
1. The plugin was not installed into a live Claude Code session, so slash-command namespacing, skill auto-triggering and agent delegation are untested. Run `/plugin marketplace add ./shopify-team-kit-repo` locally and try `/shopify-team-kit:setup-project` on a test theme first.
2. Skill trigger quality was not measured with evals. Tune the skill descriptions after a week of real use.
3. Figma tool names come from the official Figma MCP and community skills; confirm with `/mcp`.
4. No screen-reader, browser or Lighthouse testing was possible here; the script is a complement, not a certification.
5. Script tested on Linux bash; macOS and Git Bash not run (no bash 4-only features used).
6. Sources are current as of 12 Nov 2026; Shopify and WCAG guidance changes, so review quarterly.


---

## Round 2 (fixes re-tested)

| # | Severity | Finding | Fix |
|---|---|---|---|
| 9 | Medium | Remaining Dawn findings included 5 false positives: tabindex="-1" focus targets, `:hover` and `.disabled` outline rules, a newsletter banner flagged as a hero, a password-page logo h1 | A02 now only treats `:focus` selectors as Medium and global selectors as High; other outline rules are Low; narrower hero file list; password pages skipped. Dawn: HIGH 0, MED 3 (all legitimate "verify" items) |
| 10 | Medium | No repeatable test suite, so fixes could silently regress | Added `tests/run-tests.sh` with defect, clean and "guards" fixtures (36 checks). Mutation test confirmed the guards fail when a guarded pattern is made bad |
| 11 | Medium | Test bug found while testing: the optional Theme Check assertion passed even when Theme Check reported an error (`grep -vq`), and the clean fixture was missing `locales/` and an asset | Assertion rewritten and proven able to fail; fixture completed |
| 12 | Low | Windows line endings could break the script | Added `.gitattributes` forcing LF for `.sh` and `.md` |
| 13 | Low | CI gate was only offered | Added `templates/github-workflow-theme-qa.yml` (static audit on changed files + Theme Check) |

Re-test results (fresh extract of the zip): 36 of 36 checks pass, shellcheck clean, Theme Check 0 offenses on the clean fixture, Dawn HIGH 0 / MED 3.

Still not verified: live install in Claude Code, skill trigger quality, macOS and Git Bash runs, real screen-reader and Lighthouse testing, GitHub Actions workflow run (YAML validated only).


---

## Round 3: `/figma-to-page` added

New: `commands/figma-to-page.md` (6 phases with an approval stop before any theme code), `skills/figma-to-shopify/references/page-orchestration.md`, `templates/page-plan.md`, `templates/page-report.md`.

Checks added to `tests/run-tests.sh` (now 40): every command is documented in the README, page templates exist, the approval stop is present, and the command never targets the live theme. Mutation test confirmed the docs check fails when a command is missing from the README. The page-template JSON example parses and passes Shopify Theme Check when used with matching sections.

Test-harness defect found while mutation-testing: a failing check containing `exit` aborted the whole suite silently (no FAIL line, no summary). Checks now run in a subshell; mutation tests (README missing a command, approval stop removed) now show a visible FAIL and a summary.

Not verified: `/figma-to-page` has not been run against a real Figma file or the live Figma MCP, so phase behavior, context use on large pages, and automated visual comparison (needs a browser tool) are untested. Treat the first real run as a pilot on a small page.


---

## Round 4: foundation, single `/build` entry, shared quality gate

Added: `/foundation` (global, SEO, accessibility, performance standards applied after an approved plan), `/build` (route + build + gate + QA plan in one run), skill `shopify-quality-gate` (standard and strict profiles, fix loop, Done report), `scripts/contrast-check.py`, `--fail-on high|med`, opt-in Stop hook `scripts/stop-quality-gate.sh` with settings snippet, foundation templates (`kit-base.css`, skip link, meta tags, Organization JSON-LD, locale keys).

| # | Severity | Finding | Fix |
|---|---|---|---|
| 14 | High | `--changed` ignored new untracked files, so a brand-new section was never audited (and the Stop hook would have let it through) | `--changed` now includes `git ls-files --others`; test added; hook test confirms a new untracked file with a High is blocked |
| 15 | Medium | Contrast checker reported every scheme as "settings" | Names now taken from the parent key; ratios verified against known values (21.0, 4.54, 4.48) |
| 16 | Low | New commands were missing from the README, caught by the docs-consistency test | README updated (the test did its job) |

Verification: foundation templates assembled into a theme pass the audit with no High and no Medium and pass Shopify Theme Check with 0 offenses and 0 warnings; the contrast checker gives correct WCAG ratios and works on Dawn (15 pairs, all pass); the stop hook was tested for no changes, High on an untracked file, loop guard, Medium under standard vs strict, and non-theme directories (all as designed); test suite grew to 54 checks.

Not verified: the Stop hook inside a live Claude Code session (exit-code-2 blocking and `stop_hook_active` follow Claude Code's documented hook contract, and are tested here only as a script), `/foundation` and `/build` against a real client theme, and Claude Code's own handling of the new commands. Pilot on a non-critical theme first.


---

## Round 5: resolve-first (automatic fixing, ask only when blocked)

Change of behavior: the gate no longer ends with a QA to-do list. It finds, fixes, re-verifies, and asks only for real blockers.

Added: rewritten `shopify-quality-gate` skill (fix loop, ask policy, Done report with "Needs your input", no manual test lists), `references/auto-fix-playbook.md` (one recipe per rule id, with the exact conditions that require asking), `scripts/rendered-qa.mjs` (axe-core on jsdom plus 15 SEO/performance/structure rules on rendered HTML, with `--fail-on`), audit commands now fix by default (`--report-only` opts out), `/build` batches questions into one message with recommended defaults.

| # | Severity | Finding | Fix |
|---|---|---|---|
| 17 | Medium | `/audit`, `/ada-audit`, `/perf-audit`, `/seo-audit`, the page report and `/build` all ended by handing the user a manual test list | Audit commands fix by default; report templates replaced the list with "Verified automatically / Needs input / Not verifiable here"; a test fails if a manual-test list returns |
| 18 | Low | Rendered QA dependencies (jsdom, axe-core) are not bundled | Script exits 2 with a clear message; setup installs them into `scripts/qa/`; tests install them or skip with a visible SKIP |

Verification:
- **Playbook is real:** applying its recipes to the planted-defect theme took the static audit from HIGH 9 / MED 14 to HIGH 0 / MED 0.
- **Playbook is complete:** a test fails if any rule id emitted by either audit script lacks a recipe (mutation-tested by deleting a row).
- **Rendered QA:** catches 8 High and 7 Medium classes on a deliberately bad page, passes a clean page, Medium-only page passes by default and fails with `--fail-on med`, unreachable target is a High. Mutation-tested by breaking a rule.
- Suite: 81 checks, all passing from a fresh extract.

Not verified: the fix loop itself (Claude applying the playbook inside a live session), `shopify theme dev` auto-start, and rendered QA against a live Shopify preview. The rendered check cannot see color contrast, focus visibility, target size or JavaScript-rendered content (jsdom has no layout engine), so those rely on `contrast-check.py` and the reviewer agent; real screen-reader and device behavior is reported on one line as "Not verifiable here". Pilot on a non-critical theme.


---

## Round 6: official tooling, installer, end-to-end run on real Dawn

Verified with the real Claude Code CLI (v2.1.323) in an isolated home directory:

| Check | Result |
|---|---|
| `claude plugin validate` on the marketplace | Passed (after adding a marketplace description) |
| `claude plugin validate` on the plugin, and with `--profile directory` | Passed (after adding a LICENSE; only the optional listing icon remains, needed only for the public directory) |
| `claude plugin marketplace add` + `claude plugin install` from the local repo | Installed and enabled |
| `claude plugin details` | 21 skill-type entries (6 skills + 15 commands) and 2 agents; always-on cost about 1,500 tokens per session |
| `install.sh` | Works on a fresh home, is idempotent on re-run, and fails clearly on a bad source |

| # | Severity | Finding | Fix |
|---|---|---|---|
| 19 | Low | Validator: marketplace had no description; plugin had no license | Added both. The LICENSE is a proprietary internal-use placeholder: replace it with the license you want |
| 20 | Medium | End-to-end run on Dawn: after fixing a new section, Shopify Theme Check still reported a missing locale key and a missing asset that the static audit cannot see | Added a Theme Check section to the auto-fix playbook (add locale keys; a missing asset whose content is unknown becomes a question to the user); test added |

End-to-end simulation on a copy of real Dawn: kit setup (scripts, QA dependencies, CLAUDE.md, .shopifyignore) -> baseline (HIGH 0, contrast 15/15 pass) -> a new section with common mistakes -> Stop hook blocked it with 3 High findings -> playbook fixes applied -> audit 0/0/0 and hook allowed -> Theme Check caught the locale key and asset -> locale key added.

Remaining unverified (cannot be tested without a logged-in Claude session and a real store): the LLM behavior of `/build`, `/foundation` and the fix loop; `shopify theme dev` auto-start; rendered QA against a live Shopify preview; the Stop hook inside a live session; Figma flows. Pilot on a non-critical theme first.


---

## Round 7: independent QA using Anthropic's official plugin-dev QA tooling

Source: `anthropics/claude-plugins-official`, plugin `plugin-dev` (commit f75f5b2, 12 Nov 2026), added to an isolated Claude Code home with the real CLI. Its `plugin-validator` and `skill-reviewer` agent checklists were applied to this kit, its `validate-agent.sh`, `hook-linter.sh` and `validate-hook-schema.sh` were run (after reading them: local read-only checks, no network or destructive commands), and its command-frontmatter reference was used as the standard. Nothing from that plugin is shipped in this kit.

| # | Severity | Finding (official standard) | Fix |
|---|---|---|---|
| 21 | High | All 15 commands granted bare `Bash` in `allowed-tools`; Anthropic's reference lists this as incorrect ("missing command filter") and it pre-approves arbitrary shell commands | Replaced with filtered grants (`Bash(git status:*)`, `Bash(bash scripts/quick-audit.sh:*)`, `Bash(shopify theme check:*)`, ...). Pushing, committing, `shopify theme push` and `shopify theme dev` are deliberately not pre-approved, so they still ask |
| 22 | Medium | Both agents lacked `color`, `<example>` blocks and the "Use this agent when" description pattern; QA agent prompt did not start with "You are" | Rewritten to the plugin-dev standard |
| 23 | Medium | Hook settings snippet had no `matcher` (the official example uses `"*"` for Stop) | Added; passes the official hook schema validator |
| 24 | Low | Skill descriptions were not in third person and two exceeded 500 characters; two second-person phrases in skill bodies | All six rewritten ("This skill should be used when ..."), 330 to 399 characters |
| 25 | Low | No `.gitignore` | Added |

Findings accepted or explained (no change):
- SKILL.md bodies are 665 to 1,012 words (guide: 1,000 to 3,000). Lean by design: detail lives in `references/` (about 5,900 words in total) for progressive disclosure.
- Agents keep unfiltered `Bash` in `tools` because the agent frontmatter has no per-command filter; the reviewer is instructed read-only, the QA agent is invoked only on request.
- Tool limitations (not kit defects): the official `validate-agent.sh` and `hook-linter.sh` abort after their first warning because of `set -e` with counters (run from patched temp copies); `validate-agent.sh` reads block-scalar descriptions (`description: |`) as "|", giving three false warnings, and the same three appear on Anthropic's own `plugin-validator` agent; `hook-linter.sh` asks for `set -e` (the Stop hook deliberately fails open without it, now commented) and flags two variables that are inside double-quoted strings.
- Security scan from the plugin-validator checklist: no hardcoded credentials, no destructive or pipe-to-shell commands (apart from the official Claude installer line in the README), no insecure `http://` URLs.

Verification after fixes: suite 88 checks (3 new: plugin-dev standards, hook snippet, .gitignore; each mutation-tested by breaking an agent color, adding a bare Bash and un-thirding a description), `claude plugin validate` passes for plugin and marketplace.


---

## Round 8: tested on downloaded real themes (Dawn, Horizon, Skeleton)

Downloaded from Shopify's own repositories: **Dawn** (classic OS 2.0), **Horizon** (newer architecture with a `blocks/` folder, 145 snippets, 95 blocks) and **Skeleton** (minimal starter). Ran the static audit, contrast check and Shopify Theme Check on each, inspected every High/Medium finding in the real code, and ran the strict-profile hook flow on Horizon.

First results on Horizon were poor: **HIGH 1 / MED 41**. Reading the flagged code showed real bugs in the audit script:

| # | Severity | Bug found | Root cause | Fix |
|---|---|---|---|---|
| 26 | High | False HIGH: "`<html>` has no lang" on Horizon | Check read one line; Horizon writes the tag over several lines with a Liquid `if` inside | New tag-aware scanner that reads multi-line tags, skips Liquid inside tags, and ignores doc, comment, schema, script and style blocks (also used for A05, A08, A11, A13) |
| 27 | Medium | 15 false A08 "autoplay" findings | Matched a Liquid variable named `autoplay` | Only `<video>`/`<audio>` tags and `video_tag` are checked; muted autoplay is LOW |
| 28 | Medium | False A05 (img without alt) | Matched `<img>` inside a `{% doc %}` comment and multi-line tags with alt on another line | Scanner above |
| 29 | Medium | False S05 (hardcoded canonical) | Canonical `<link>` split over lines | 7-line window |
| 30 | Medium | False T01 and P04 | JSON preset text in a schema; a jQuery URL in a comment | Filters |
| 31 | Medium | 10 A02 outline findings that were valid modern patterns | Rings moved to wrappers, pseudo-elements, `:has(:focus-visible)` | Theme-wide focus-ring detection and container awareness: LOW (hidden by default) when a global ring exists |
| 32 | Low | P05 flagged a 32px flag icon as a hero | No context | MED only in hero-like files, else LOW |

Result after fixes (default output, MED/HIGH only): **Dawn HIGH 0 / MED 2, Horizon HIGH 0 / MED 4, Skeleton HIGH 0 / MED 4** (Horizon MED 41 to 4). The remaining findings were checked against the code and are real or legitimate "verify" items (Skeleton has no skip link, an `<img>` with no alt and an `<a role="button">`; variant loops in quick-order lists; hardcoded English in a demo snippet).

Hardening: 10 new fixtures/tests (multi-line defects that must be caught, real-world patterns that must not be flagged); the old script fails 11 of them (proves they catch the bugs); `tests/real-themes.sh` downloads the three themes and asserts HIGH 0, a MED ceiling and runtime under 15 s (all pass: 1 to 2 s each).

Horizon end-to-end (strict profile, new `blocks/` architecture): a promo block with 10 typical mistakes was blocked by the Stop hook (3 High, 7 Medium, because strict fails on Medium); after the playbook fixes the audit was 0/0/0 and the hook allowed it. Theme Check then found three more things the static audit cannot see: a missing locale key, a missing asset, and **`MissingRenderSnippetArguments`** (Horizon's `price` snippet requires `product_resource`, so converting `include` to `render` is not enough). A playbook recipe for it was added (read the snippet's `{% doc %}` params; ask when a required value is unknown).

Still not tested: the Claude-driven steps (`/build`, `/foundation`, the fix loop, Figma) inside a live session, and rendered QA against a live Shopify preview.


---

## Round 9: field report on `ks-bootshop-master` (Windows, Git Bash)

An external tester ran the kit step by step on a Bootstrap-based theme and reported real problems. Each one was reproduced as a fixture or test where possible and fixed.

| # | Severity | Reported problem | Cause | Fix and evidence |
|---|---|---|---|---|
| 33 | High | Audit took 63 s on 94 files in Git Bash (too slow for a 120 s Stop hook) | Hundreds of grep, sed and awk processes; process start-up is very expensive on Windows | Rewrote as one Node process (`quick-audit.mjs`). Linux, Horizon: 2,300 ms to 370 ms; Dawn 230 ms, Skeleton 64 ms. Windows was not measured here, but the process count drops from hundreds to one. Findings are identical to the old script on 9 themes and fixtures (0 differences, including LOW) |
| 34 | High | Contrast check, frontmatter check and hook-JSON check need Python (8 tests fail on Windows) | Python used in scripts and tests | No Python anywhere: `contrast-check.mjs`, Node test helpers (`tests/lib/check.mjs`, `theme-check.mjs`), a test that fails if Python returns. Windows run not verified here |
| 35 | High | Contrast check silently checked 0 pairs on flat color settings (`color_primary`, `color_body_bg`, `color_body_color`) and looked like a pass | It only understood nested `background`/`text` schemes | Pairs flat settings by naming convention (`<stem>_bg` with `<stem>_color`), accepts `--pair fg:bg`, adds ASSUMED checks for brand/link colors, prints what it scanned, and **exits 3 "NOT VERIFIED" when nothing could be paired**; the gate skill says never to report exit 3 as a pass. Reproduces the reported numbers (body 15.43:1, primary on white 4.50:1) |
| 36 | Medium | Hook may never trigger when the theme is in a subfolder of a bigger git repo | **Confirmed, and worse:** `git diff --name-only` (also used by `--changed`) returns repo-root paths | `--changed` uses `--relative` from the theme folder. New Node hook finds the theme up to three folders down. Tests: hook blocks with the project dir at the repo root and at the nested theme; `--changed` returns theme-relative paths |
| 37 | Medium | Hook was silent when it could not work | Fail-open without a message | Now fails open with a visible `systemMessage` (audit script missing; not a git repo); silent only for non-theme projects |
| 38 | Medium | Not-a-theme-root message gave no help for a double folder | None | Searches three levels down and prints "Did you mean: <path>" (exit 2) |
| 39 | Medium | 9 of 13 Medium findings were one Bootstrap pattern | No grouping or Bootstrap awareness | Repeated findings print once with a count and samples (`--no-group` lists all); `role="button"` with `data-bs-toggle` is LOW with a "verify Space/Enter and aria-expanded" message |
| 40 | Medium | Nothing in the tests checked Theme Check schema validation | Optional, env-var gated | Test installs the Theme Check engine into `tests/node_modules` and asserts that an invalid schema is reported as a `ValidSchema` error, plus clean and foundation themes pass with 0 errors (foundation also 0 warnings) |
| 41 | Medium | v2 commands unavailable after installing over v1 (same plugin name) | Same version number | Version 2.0.0; README "Upgrading" section. Proven with the real CLI: an installed 1.4.2 copy updated to 2.0.0 via `claude plugin marketplace update` and `claude plugin update` gained `/build`, `/foundation` and `/figma-to-page` (restart required) |

Also changed: the CI workflow template and installer now require Node 18+ instead of Python; `quick-audit.sh` and `stop-quality-gate.sh` remain as thin wrappers for older projects.

Verification: suite grew to 114+ checks including all of the above, each new check mutation-tested where the logic is non-trivial (YAML check proved in both the library and the fallback mode); real themes (Dawn, Horizon, Skeleton) still HIGH 0 with MED 2, 4 and 4.

Not verified: a run on Windows itself (speed and test results are reported by the field tester, not reproduced here), the tester's private theme (reproduced as fixtures instead), and the Claude-driven steps (`/build`, `/foundation`, the fix loop, Figma flows, rendered QA on a live store).
