# Shopify Team Kit (Claude Code plugin marketplace)

Plug-and-play Shopify theme workflow: standards, accessibility (WCAG 2.2 AA), performance (Core Web Vitals), SEO, Figma-to-section, a review agent, slash commands and a static audit script.

Repo layout (marketplace at the root, plugin in `plugins/`):

```
.claude-plugin/marketplace.json
plugins/shopify-team-kit/   (skills, agents, commands, scripts, templates)
QA-REPORT.md
```

## Requirements
Node 18 or newer, git, and Claude Code. Python is not needed. On Windows, use Git for Windows (Git Bash) to run `install.sh` and `tests/run-tests.sh`; the audit, contrast check and stop hook themselves are plain Node and run anywhere Node runs. If your theme sits in a subfolder (for example a zip that extracted into `theme/theme`), pass that folder: `node scripts/quick-audit.mjs path/to/theme`, or run it from the project root and it will suggest the right folder.

## Upgrading (v1 to v2)
The plugin name is the same across versions, so upgrade explicitly. After you push or pull the new version:
```bash
claude plugin marketplace update shopify-team-kit-marketplace
claude plugin update shopify-team-kit@shopify-team-kit-marketplace
# restart Claude Code, then check:  claude plugin details shopify-team-kit
```
v2 adds `/build`, `/foundation`, `/figma-to-page` and the Node scripts. In each theme project re-run `/shopify-team-kit:setup-project` once to copy the new scripts into `scripts/` (it replaces the old bash scripts; if you enabled the Stop hook, point its command at `node "$CLAUDE_PROJECT_DIR/scripts/stop-quality-gate.mjs"`).

## Quick install (one command)

```bash
bash install.sh                 # from this folder; or: bash install.sh <your-org>/shopify-team-kit-repo
bash install.sh --with-figma    # also connect the official Figma MCP (sign in later with /mcp)
```

`install.sh` checks prerequisites, adds the marketplace, installs the plugin and prints the next steps. It is safe to re-run. Installing from a **local folder** loads the plugin in place, so keep that folder (or install from your Git source for the team). Verified with the real Claude Code CLI: `claude plugin validate` passes for the marketplace and the plugin, and the install lists 6 skills, 15 commands and 2 agents (about 1,500 tokens added to each session; skills load fully only when used).

## Install step by step (once per machine)

```bash
# 1. Tools
npm install -g @shopify/cli@latest
curl -fsSL https://claude.ai/install.sh | bash

# 2. Figma MCP
claude mcp add --transport http figma https://mcp.figma.com/mcp
```

Inside Claude Code:

```
# 3. Official Shopify toolkit (docs lookup, Liquid and GraphQL validation) - commands from Shopify's README
/plugin marketplace add Shopify/shopify-ai-toolkit
/plugin install shopify-plugin@shopify-ai-toolkit
#    If that fails, third-party guides list: claude plugin install shopify-ai-toolkit@claude-plugins-official
#    Review the toolkit's telemetry settings before using confidential code.

# 4. This kit (push this repo to your Git host first)
/plugin marketplace add <your-org>/shopify-team-kit-repo
/plugin install shopify-team-kit@shopify-team-kit-marketplace
```

Test locally before pushing: `/plugin marketplace add ./shopify-team-kit-repo`.
Run `/mcp` and sign in to Figma. Restart Claude Code if tools do not appear.

### Enable for the whole team automatically
Commit this to the theme repo as `.claude/settings.json` (team members are prompted to trust the folder, then the marketplace and plugin install):

```json
{
  "extraKnownMarketplaces": {
    "shopify-team-kit-marketplace": {
      "source": { "source": "github", "repo": "<your-org>/shopify-team-kit-repo" }
    }
  },
  "enabledPlugins": {
    "shopify-team-kit@shopify-team-kit-marketplace": true
  }
}
```

## The whole flow in three commands

```
/shopify-team-kit:setup-project     once per project: facts, CLAUDE.md, baseline
/shopify-team-kit:foundation        once per project: global, SEO, accessibility, performance standards (plan, approve, apply, baseline)
/shopify-team-kit:build <anything>  every task: build + full quality gate + QA plan in the same run
```

`/build` accepts plain text, a bug description, a Figma frame link or a Figma page link and routes to the right workflow. Every build ends with the same **resolve-first gate**: theme check, static audit, rendered-page QA (axe-core + SEO/performance rules on real HTML), contrast, reviewer, then an **automatic fix loop** driven by a per-rule auto-fix playbook. You get work that already passed, not a QA to-do list.

### When it asks you
Only for real blockers, all in **one batched message at the end**, each with a recommended default: a missing dependency or input (preview URL or password, dev theme ID, Figma access, assets, copy, licensed fonts), a conflict between a standard and the design or an app (brand color failing contrast, autoplay hero, an app's script), anything with wide blast radius or that is irreversible, or genuinely ambiguous intent. Everything else it fixes itself.

### Quality profile (set in CLAUDE.md)
| | standard | strict |
|---|---|---|
| Must be clean | no High | no High and no Medium |
| Reviewer verdict | not BLOCK | OK TO MERGE |
| Contrast check | when colors change | always |
| Fix rounds | 3 | 4 |

### Optional: automatic enforcement (opt-in)
Add `templates/hooks/settings.hooks.json` to the project's `.claude/settings.json` and copy `scripts/stop-quality-gate.mjs` to the repo's `scripts/`. Claude then cannot finish a turn while changed theme files fail the audit for the profile. It fails open, never blocks twice in a row, and does nothing outside a theme repo.

## Per project (5 minutes)

```
cd your-theme-repo
claude
/shopify-team-kit:setup-project
```

Copies `scripts/quick-audit.mjs` and `scripts/contrast-check.mjs` into the repo (commit it so CI and teammates can run it), creates `CLAUDE.md` (project facts only) and `.shopifyignore`, checks `.gitignore`, runs a baseline audit.

## What is inside

| Part | Purpose |
|---|---|
| Skills (auto-loaded by context) | `shopify-theme-standards`, `shopify-ada-wcag`, `shopify-performance`, `shopify-seo`, `figma-to-shopify`, `shopify-quality-gate` |
| Agents | `shopify-code-reviewer` (read-only diff review used inside the gate), `shopify-qa-tester` (a written QA plan, only when you ask for one via `/qa-checklist`) |
| Commands | `setup-project`, `foundation`, `build`, `new-section`, `figma-to-section`, `figma-to-page`, `fix-bug`, `ada-audit`, `perf-audit`, `seo-audit`, `audit`, `review`, `qa-checklist`, `client-update`, `bulk-update` |
| Scripts (all Node, no Python) | `scripts/quick-audit.mjs [dir] [--changed] [--verbose] [--no-fail] [--no-group] [--fail-on high|med]`: one-process static checks (A = accessibility, P = performance, S = SEO, T = standards); repeated findings are grouped with a count; exit 1 on any HIGH, so it works as a CI gate. `scripts/contrast-check.mjs [dir] [--pair fg:bg]`: WCAG contrast for nested color schemes (Dawn, Horizon) and flat settings (`color_body_bg` with `color_body_color`); exit 3 means NOTHING could be checked (never a pass). `scripts/stop-quality-gate.mjs`: opt-in Stop hook (works for themes in subfolders). `scripts/rendered-qa.mjs <url or html>`: axe-core + SEO/performance rules on rendered pages (deps installed into `scripts/qa/` by setup). The `.sh` files are thin wrappers kept for older projects |
| Templates | `foundation/` (kit-base.css, skip link, meta tags, Organization JSON-LD, locale keys), `hooks/settings.hooks.json`, `CLAUDE.md`, `.shopifyignore`, `pull_request_template.md`, `page-plan.md`, `page-report.md`, `github-workflow-theme-qa.yml` (CI: audit + Theme Check on every PR) |
| Tests | `tests/real-themes.sh` (optional: downloads Dawn, Horizon and Skeleton and checks the audit stays quiet), `tests/run-tests.sh` (36 checks: structure, defect fixtures, false-positive guards, CLI, optional Theme Check). Run after any change to the script or skills |

Commands are namespaced: `/shopify-team-kit:new-section`.

## Daily flow
1. `/build <task | bug | figma link>`: build, gate and QA plan in one run (the individual commands `/new-section`, `/fix-bug`, `/figma-to-section`, `/figma-to-page` remain available).
2. Read the Done report: what was verified, what was auto-fixed, and any questions it needs you to answer.
3. `/client-update`: status message. Before release: `/audit` (fixes automatically; `--report-only` to just report).

## Definition of done
`theme check` passes, no High in quick-audit, Theme Editor behavior verified, mobile and desktop checked, keyboard path checked, review done, change summary written.

## Standards sources
Shopify: performance, accessibility and SEO metadata docs, Liquid `structured_data` filter reference (shopify.dev). W3C WCAG 2.2. Fudge WCAG 2.2 AA checklist for Shopify. Community inputs: karimmtarek CLAUDE.md gist, iromanovich/claude-code-setup, Let's Talk Shop guide.

## Limits
- Static checks find patterns; they cannot prove accessibility, speed or SEO. Automated scanners cover only about 30 to 40% of WCAG criteria: always do the keyboard and screen-reader passes and real Lighthouse runs.
- No hooks, no network calls in this kit. Review any third-party plugin before installing.
- Re-check the shopify.dev pages quarterly and update the skills.
