# Sourced by run-tests.sh. Regression tests for problems found in field testing on real themes.
# Uses functions (not eval'd strings) so quoting stays readable. Variables: $A (audit command), $ROOT.

echo "== Contrast checker (Node, flat and nested color settings)"
c_good()   { node scripts/contrast-check.mjs tests/fixtures/contrast-good; }
c_bad()    { node scripts/contrast-check.mjs tests/fixtures/contrast-bad; [ $? -eq 1 ]; }
c_ratios() { O="$(node scripts/contrast-check.mjs tests/fixtures/contrast-ratios)"; printf '%s' "$O" | grep -q '21.00' && printf '%s' "$O" | grep -q '4.54' && printf '%s' "$O" | grep -q '4.48'; }
c_flat()   { node scripts/contrast-check.mjs tests/fixtures/contrast-flat | grep -q '15.43'; }
c_none()   { node scripts/contrast-check.mjs tests/fixtures/contrast-none >/dev/null; [ $? -eq 3 ]; }
c_none_msg() { node scripts/contrast-check.mjs tests/fixtures/contrast-none | grep -q 'NOT VERIFIED'; }
c_pairs()  { node scripts/contrast-check.mjs tests/fixtures/contrast-good | grep -q 'paired by name'; }
checkf "contrast: good schemes exit 0" c_good
checkf "contrast: bad schemes exit 1" c_bad
checkf "contrast: ratios correct (black/white 21.00, #767676 4.54, #777 4.48)" c_ratios
checkf "contrast: flat Bootstrap-style settings are paired (body 15.43:1)" c_flat
checkf "contrast: a theme with no colors exits 3 (NOT VERIFIED, never a pass)" c_none
checkf "contrast: the no-colors message says NOT VERIFIED" c_none_msg
checkf "contrast: Dawn-style nested schemes still work" c_pairs

echo "== Problems found in field testing (nested folders, subfolder repos, grouping, Bootstrap)"
NF="$(mktemp -d)"; mkdir -p "$NF/outer/inner"; cp -r tests/fixtures/clean/. "$NF/outer/inner/"
f_nested() { O="$($A "$NF/outer")"; rc=$?; [ $rc -eq 2 ] && printf '%s' "$O" | grep -q 'Did you mean' && printf '%s' "$O" | grep -q 'inner'; }
checkf "audit: a folder that is not a theme root exits 2 and suggests the nested theme" f_nested
rm -rf "$NF"

f_group()   { O="$($A tests/fixtures/grouping --no-fail)"; [ "$(printf '%s\n' "$O" | grep -c '^MED | A11 |')" -eq 1 ] && printf '%s' "$O" | grep -q 'x5 in 5 files'; }
f_nogroup() { O="$($A tests/fixtures/grouping --no-fail --no-group)"; [ "$(printf '%s\n' "$O" | grep -c '^MED | A11 |')" -eq 5 ]; }
f_bs()      { $A tests/fixtures/guards --no-fail --verbose | grep -q '^LOW | A11 |.*Bootstrap'; }
checkf "audit: repeated findings are grouped with a count (5 files, one line)" f_group
checkf "audit: --no-group lists every occurrence" f_nogroup
checkf "audit: Bootstrap data-bs-toggle role=button is LOW, not MED" f_bs

NG="$(mktemp -d)"; cp -r tests/fixtures/clean/. "$NG/"
f_nogit() { $A "$NG" --changed --no-fail | grep -q 'not a git repository'; }
checkf "audit: --changed outside a git repo says so and audits everything" f_nogit
rm -rf "$NG"

MONO="$(mktemp -d)"; mkdir -p "$MONO/web/theme/scripts"; cp -r tests/fixtures/clean/. "$MONO/web/theme/"
cp scripts/quick-audit.mjs scripts/stop-quality-gate.mjs "$MONO/web/theme/scripts/"
( cd "$MONO" && git init -q -b main . && echo x > README.md && git add -A && git -c user.email=t@t -c user.name=t commit -qm base ) >/dev/null 2>&1
printf '<script src="x.js"></script>\n' > "$MONO/web/theme/sections/new.liquid"
f_sub_changed() { O="$(cd "$MONO/web/theme" && node scripts/quick-audit.mjs . --changed --no-fail)"; printf '%s' "$O" | grep -q '^HIGH | P03 | sections/new.liquid:1'; }
f_hook_root()   { printf '{}' | CLAUDE_PROJECT_DIR="$MONO" node "$MONO/web/theme/scripts/stop-quality-gate.mjs" >/dev/null 2>&1; [ $? -eq 2 ]; }
f_hook_theme()  { printf '{}' | CLAUDE_PROJECT_DIR="$MONO/web/theme" node "$MONO/web/theme/scripts/stop-quality-gate.mjs" >/dev/null 2>&1; [ $? -eq 2 ]; }
checkf "audit --changed works for a theme inside a bigger git repo (theme-relative paths)" f_sub_changed
checkf "hook blocks when the project dir is the repo root and the theme is two folders down" f_hook_root
checkf "hook blocks when the project dir is the nested theme folder" f_hook_theme
rm -rf "$MONO"

NS="$(mktemp -d)"; mkdir -p "$NS/hookonly"; cp -r tests/fixtures/clean/. "$NS/"; cp scripts/stop-quality-gate.mjs "$NS/hookonly/"
( cd "$NS" && git init -q -b main . && git add -A && git -c user.email=t@t -c user.name=t commit -qm base ) >/dev/null 2>&1
f_hook_msg() { O="$(printf '{}' | CLAUDE_PROJECT_DIR="$NS" node "$NS/hookonly/stop-quality-gate.mjs")"; [ $? -eq 0 ] && printf '%s' "$O" | grep -q 'systemMessage' && printf '%s' "$O" | grep -q 'quick-audit.mjs was not found'; }
checkf "hook is not silent when the audit script is missing (visible systemMessage, exit 0)" f_hook_msg
rm -rf "$NS"

NGH="$(mktemp -d)"; cp -r tests/fixtures/clean/. "$NGH/"
f_hook_nogit() { O="$(printf '{}' | CLAUDE_PROJECT_DIR="$NGH" node scripts/stop-quality-gate.mjs)"; [ $? -eq 0 ] && printf '%s' "$O" | grep -q 'not a git repository'; }
checkf "hook is not silent outside a git repo (visible systemMessage, exit 0)" f_hook_nogit
rm -rf "$NGH"

f_speed() { s=$(date +%s); for _ in 1 2 3; do $A tests/fixtures/defects --no-fail >/dev/null; $A tests/fixtures/guards --no-fail >/dev/null; done; [ $(( $(date +%s) - s )) -le 6 ]; }
checkf "speed: six audit runs finish within 6 seconds" f_speed
f_nopython() { ! grep -rIlE '(^|[^A-Za-z])python3?([ "]|$)' scripts tests/run-tests.sh tests/lib/*.mjs tests/lib/*.sh ../../install.sh 2>/dev/null | grep -v field-tests.sh | grep -q .; }
checkf "no Python anywhere in scripts, tests or installer" f_nopython
