#!/usr/bin/env bash
# Regression tests for the Shopify Team Kit. Run from the plugin root: bash tests/run-tests.sh
# Needs: bash (Git Bash on Windows), Node 18+, git. No Python. Test-only npm packages (yaml, Theme Check) are installed into tests/node_modules.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT" || exit 2
A="node scripts/quick-audit.mjs"
if [ ! -d tests/node_modules/yaml ] && command -v npm >/dev/null 2>&1; then ( cd tests && npm install --no-audit --no-fund >/dev/null 2>&1 ); fi
TC="node tests/lib/theme-check.mjs"; HAVE_TC=0; [ -d tests/node_modules/@shopify/theme-check-node ] && HAVE_TC=1
CK="node tests/lib/check.mjs"
checkf() { if ( "$2" ) >/dev/null 2>&1; then ok "$1"; else bad "$1"; fi; }  # run a shell function in a subshell
PASS=0; FAIL=0
ok()  { PASS=$((PASS+1)); printf '  PASS  %s\n' "$1"; }
bad() { FAIL=$((FAIL+1)); printf '  FAIL  %s\n' "$1"; }
check() { if ( eval "$2" ) >/dev/null 2>&1; then ok "$1"; else bad "$1"; fi; }  # subshell so an "exit" inside a check cannot abort the suite

echo "== Structure"
check "plugin.json parses" "$CK json .claude-plugin/plugin.json"
check "marketplace.json parses (repo root, if present)" "[ ! -f ../../.claude-plugin/marketplace.json ] || $CK json ../../.claude-plugin/marketplace.json"
check "frontmatter valid (YAML parses; skills, agents, commands)" "$CK frontmatter"
check "plugin-dev standards (agents: color, examples, 'Use this agent when'; skills: third person, <=520 chars; commands: no bare Bash)" "$CK standards"
check ".gitignore present at repo root (node_modules, pycache, DS_Store)" "[ ! -f ../../.gitignore ] || grep -q node_modules ../../.gitignore"
if command -v shellcheck >/dev/null 2>&1; then check "shellcheck clean (wrappers and installer)" "shellcheck -S warning scripts/*.sh ../../install.sh"; else echo "  SKIP  shellcheck not installed"; fi

echo "== Docs consistency"
check "every command in commands/ is documented in README" "for f in commands/*.md; do n=\$(basename \$f .md); grep -q \"\$n\" README.md || exit 1; done"
check "page templates exist" "[ -f templates/page-plan.md ] && [ -f templates/page-report.md ] && [ -f skills/figma-to-shopify/references/page-orchestration.md ]"
check "figma-to-page has an approval stop before coding" "grep -q 'Do not write theme code before approval' commands/figma-to-page.md"
check "figma-to-page never targets the live theme" "! grep -qE -- '--live|--allow-live' commands/figma-to-page.md"

echo "== Defect fixture (must be caught)"
OUT="$($A tests/fixtures/defects --no-fail)"; $A tests/fixtures/defects >/dev/null 2>&1; RC=$?
check "exit code 1 when HIGH exists" "[ $RC -eq 1 ]"
for id in A01 A02 A03 P01 P03 P06 P14 S01 S02; do check "HIGH $id detected" "printf '%s\n' \"\$OUT\" | grep -q \"^HIGH | $id |\""; done
for id in A05 A08 A11 A14 A15 P05 P09 P10 P12 P15 S03 S06 S09; do check "MED  $id detected" "printf '%s\n' \"\$OUT\" | grep -q \"^MED | $id |\""; done

echo "== Multi-line and real-world patterns (found by testing Horizon and Skeleton)"
MOUT="$($A tests/fixtures/multiline-defects --no-fail)"
check "multi-line <html> without lang is caught (HIGH A12)" "printf '%s\n' \"\$MOUT\" | grep -q '^HIGH | A12 |'"
check "multi-line <img> without alt is caught (A05)" "printf '%s\n' \"\$MOUT\" | grep -q '^MED | A05 |'"
check "multi-line <video autoplay> without muted is caught (A08)" "printf '%s\n' \"\$MOUT\" | grep -q '^MED | A08 |'"
check "multi-line role=button on a div is caught (A11)" "printf '%s\n' \"\$MOUT\" | grep -q '^MED | A11 |'"
GV="$($A tests/fixtures/guards --no-fail --verbose)"
check "guards: multi-line <html lang> is not an A12" "! printf '%s\n' \"\$GV\" | grep -q 'A12'"
check "guards: a Liquid variable named autoplay is not an A08" "! printf '%s\n' \"\$GV\" | grep -q 'A08'"
check "guards: <img> inside {% doc %} and multi-line <img alt> are not A05" "! printf '%s\n' \"\$GV\" | grep -q 'A05'"
check "guards: multi-line canonical with canonical_url is not S05" "! printf '%s\n' \"\$GV\" | grep -q 'S05'"
check "guards: JSON preset text and jquery URL in a comment are not T01/P04" "! printf '%s\n' \"\$GV\" | grep -qE 'T01|P04'"
check "guards: wrapper-ring and dialog outline removal are only LOW" "printf '%s\n' \"\$GV\" | grep -q '^LOW | A02 |' && ! printf '%s\n' \"\$GV\" | grep -qE '^(HIGH|MED) \\| A02'"

echo "== Clean fixture (no HIGH)"
check "clean theme exits 0" "$A tests/fixtures/clean"

echo "== False-positive guards (Dawn-style patterns must not raise HIGH or MED)"
GOUT="$($A tests/fixtures/guards --no-fail)"
check "guards: HIGH=0" "printf '%s\n' \"\$GOUT\" | grep -q 'HIGH=0'"
check "guards: MED=0"  "printf '%s\n' \"\$GOUT\" | grep -q 'MED=0'"

echo "== CLI behaviour"
check "bad directory exits 2" "$A /nonexistent/dir; [ \$? -eq 2 ]"
check "--no-fail exits 0 with HIGH present" "$A tests/fixtures/defects --no-fail"
check "--verbose lists LOW" "$A tests/fixtures/defects --no-fail --verbose | grep -q '^LOW |'"
TMP="$(mktemp -d)"; cp -r tests/fixtures/clean/. "$TMP/"; ( cd "$TMP" && git init -q -b main . && git add -A && git -c user.email=t@t -c user.name=t commit -qm base && git checkout -q -b feature/x && printf '<img src="a.jpg">\n' > sections/new.liquid && git add -A && git -c user.email=t@t -c user.name=t commit -qm change ) >/dev/null 2>&1
CH="$(cd "$TMP" && node "$ROOT/scripts/quick-audit.mjs" . --changed --no-fail)"
check "--changed reports only changed files (committed or untracked)" "printf '%s\n' \"\$CH\" | grep -q 'sections/new.liquid' && ! printf '%s\n' \"\$CH\" | grep -q 'layout/theme.liquid'"
rm -rf "$TMP"

echo "== Quality profiles, hook, contrast, foundation"
check "--fail-on med fails on Medium findings" "$A tests/fixtures/clean --fail-on med; [ \$? -eq 1 ]"
check "--fail-on med passes the guards fixture" "$A tests/fixtures/guards --fail-on med"
check "--fail-on rejects bad values" "$A tests/fixtures/clean --fail-on bogus; [ \$? -eq 2 ]"
HK="$(mktemp -d)"; cp -r tests/fixtures/clean/. "$HK/"; mkdir -p "$HK/scripts"; cp scripts/quick-audit.mjs "$HK/scripts/"
( cd "$HK" && git init -q -b main . && git add -A && git -c user.email=t@t -c user.name=t commit -qm base ) >/dev/null 2>&1
hook() { printf '%s' "$1" | CLAUDE_PROJECT_DIR="$HK" node scripts/stop-quality-gate.mjs >/dev/null 2>&1; }
check "hook allows when nothing changed" "$(declare -f hook); HK='$HK'; hook '{}'"
printf '<script src="x.js"></script>\n' > "$HK/sections/new.liquid"
check "hook blocks (exit 2) on a new untracked file with a High" "$(declare -f hook); HK='$HK'; hook '{}'; [ \$? -eq 2 ]"
check "hook never blocks twice (stop_hook_active)" "$(declare -f hook); HK='$HK'; hook '{\"stop_hook_active\": true}'"
rm -f "$HK/sections/new.liquid"; printf '<img src="a.jpg">\n' > "$HK/sections/med.liquid"
check "hook ignores Medium in standard profile" "$(declare -f hook); HK='$HK'; hook '{}'"
printf -- '- Quality profile: strict\n' > "$HK/CLAUDE.md"
check "hook blocks Medium in strict profile" "$(declare -f hook); HK='$HK'; hook '{}'; [ \$? -eq 2 ]"
rm -rf "$HK"
FD="$(mktemp -d)"; mkdir -p "$FD/layout" "$FD/snippets" "$FD/assets" "$FD/sections" "$FD/templates" "$FD/locales" "$FD/config"
cp templates/foundation/snippets/*.liquid "$FD/snippets/"; cp templates/foundation/assets/kit-base.css "$FD/assets/"; cp templates/foundation/locales/en.default.foundation.json "$FD/locales/en.default.json"
cat > "$FD/layout/theme.liquid" <<'LIQ'
<!doctype html>
<html lang="{{ request.locale.iso_code }}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ page_title }}{% unless page_title contains shop.name %} &ndash; {{ shop.name }}{% endunless %}</title>
  {{ 'kit-base.css' | asset_url | stylesheet_tag }}
  {% render 'kit-meta-tags' %}
  {% render 'kit-structured-data' %}
  {{ content_for_header }}
</head>
<body>
  {% render 'kit-skip-link' %}
  <main id="MainContent" tabindex="-1">{{ content_for_layout }}</main>
</body>
</html>
LIQ
echo '{"sections":{"main":{"type":"main-text"}},"order":["main"]}' > "$FD/templates/index.json"
printf '<section><h1>{{ section.settings.heading | escape }}</h1></section>\n{%% schema %%}\n{"name":"Main text","settings":[{"type":"text","id":"heading","label":"Heading"}],"presets":[{"name":"Main text"}]}\n{%% endschema %%}\n' > "$FD/sections/main-text.liquid"
echo '[{"name":"theme_info","theme_name":"f","theme_version":"1.0.0","theme_author":"x","theme_documentation_url":"https://example.com","theme_support_url":"https://example.com"},{"name":"Brand","settings":[{"type":"image_picker","id":"logo","label":"Logo"},{"type":"image_picker","id":"share_image","label":"Share image"}]}]' > "$FD/config/settings_schema.json"
check "foundation theme passes audit with no High and no Medium" "$A $FD --fail-on med"
check "foundation theme has skip link, canonical, lang, kit-base first" "grep -q kit-skip-link $FD/layout/theme.liquid && grep -q canonical_url $FD/snippets/kit-meta-tags.liquid && grep -q 'request.locale.iso_code' $FD/layout/theme.liquid"
FOUNDATION_DIR="$FD"
. tests/lib/field-tests.sh

echo "== Resolve-first behaviour (auto-fix, ask-only-when-blocked)"
check "auto-fix playbook covers every audit rule id" "ids=\$( { grep -oE '\\b(A|P|S|T)[0-9]{2}\\b' scripts/quick-audit.mjs; echo A02 P14 P15; grep -oE '\"R[0-9]{2}\"' scripts/rendered-qa.mjs | tr -d '\"'; } | sort -u ); for id in \$ids; do grep -q \"| \$id |\" skills/shopify-quality-gate/references/auto-fix-playbook.md || { echo missing \$id; exit 1; }; done"
check "gate skill defines the ask policy and Needs your input" "grep -q 'Ask policy' skills/shopify-quality-gate/SKILL.md && grep -q 'Needs your input' skills/shopify-quality-gate/SKILL.md"
check "gate skill forbids manual test lists in the report" "grep -q 'no manual test lists' skills/shopify-quality-gate/SKILL.md"
check "no command or template hands the user a manual-test list" "! grep -rliE 'manual tests? (still )?required' commands templates"
check "audit commands fix by default (--report-only opt-out)" "for c in audit ada-audit perf-audit seo-audit; do grep -q -- '--report-only' commands/\$c.md || exit 1; done"
check "/build tells Claude to fix automatically and batch questions" "grep -q 'ONE message' commands/build.md && grep -qi 'automatically' commands/build.md"

check "playbook has a Theme Check section (TranslationKeyExists, MissingAsset)" "grep -q 'Shopify Theme Check offenses' skills/shopify-quality-gate/references/auto-fix-playbook.md && grep -q 'TranslationKeyExists' skills/shopify-quality-gate/references/auto-fix-playbook.md && grep -q 'MissingAsset' skills/shopify-quality-gate/references/auto-fix-playbook.md && grep -q 'MissingRenderSnippetArguments' skills/shopify-quality-gate/references/auto-fix-playbook.md"
check "hook settings snippet is valid, has a Stop matcher and runs the Node hook" "$CK hook-snippet"
check "installer script is valid bash" "[ ! -f ../../install.sh ] || bash -n ../../install.sh"
if command -v claude >/dev/null 2>&1 && claude plugin validate --help >/dev/null 2>&1; then
  check "official validator: plugin passes (claude plugin validate)" "claude plugin validate \"$ROOT\""
  [ -f ../../.claude-plugin/marketplace.json ] && check "official validator: marketplace passes" "claude plugin validate \"$ROOT/../..\""
else
  echo "  SKIP  official validator (claude CLI not installed)"
fi

echo "== Rendered-page QA (axe + SEO/perf rules)"
check "rendered-qa fails with exit 2 and a clear message when deps are missing" "node scripts/rendered-qa.mjs tests/fixtures/rendered/good.html 2>&1 | grep -q 'Missing dependencies'; [ \${PIPESTATUS[0]} -eq 2 ]"
RQ="$(mktemp -d)"; cp scripts/rendered-qa.mjs "$RQ/"; cp scripts/qa-package.json "$RQ/package.json"
if [ -n "${RENDERED_QA_DIR:-}" ] && [ -d "$RENDERED_QA_DIR/node_modules" ]; then cp -r "$RENDERED_QA_DIR/node_modules" "$RQ/"; elif command -v npm >/dev/null 2>&1; then ( cd "$RQ" && npm install --no-audit --no-fund >/dev/null 2>&1 ); fi
if [ -d "$RQ/node_modules/jsdom" ]; then
  Q="node $RQ/rendered-qa.mjs"; F="tests/fixtures/rendered"
  BOUT="$($Q $F/bad.html --no-fail 2>&1)"
  for id in R01 R03 R05 R14 axe:image-alt axe:label axe:button-name axe:link-name; do check "rendered-qa catches $id on the bad page" "printf '%s\n' \"\$BOUT\" | grep -q \"^HIGH | $id |\""; done
  for id in R02 R04 R08 R09 R10 R13 R18; do check "rendered-qa catches $id (Medium) on the bad page" "printf '%s\n' \"\$BOUT\" | grep -q \"^MED | $id |\""; done
  check "rendered-qa exits 1 on the bad page" "$Q $F/bad.html; [ \$? -eq 1 ]"
  check "rendered-qa passes the good page (exit 0, no findings)" "$Q $F/good.html | grep -q 'HIGH=0  MED=0'"
  check "Medium-only page passes by default" "$Q $F/medium-only.html"
  check "Medium-only page fails with --fail-on med" "$Q $F/medium-only.html --fail-on med; [ \$? -eq 1 ]"
  check "unreachable target is a High (R00)" "$Q $F/does-not-exist.html | grep -q 'R00'"
else
  echo "  SKIP  rendered-qa tests (no node/npm or no network to install jsdom and axe-core; set RENDERED_QA_DIR)"
fi
rm -rf "$RQ"

echo "== Shopify Theme Check (the engine behind shopify theme check)"
if [ "$HAVE_TC" -eq 1 ]; then
  check "theme check: clean fixture has no errors" "$TC tests/fixtures/clean"
  TS="$(mktemp -d)"; cp -r tests/fixtures/clean/. "$TS/"; cp tests/fixtures/schema-defects/sections/bad-schema.liquid "$TS/sections/"
  check "theme check: an invalid section schema is detected (ValidSchema error)" "$TC $TS | grep -q 'ERROR ValidSchema'; [ \${PIPESTATUS[0]} -eq 1 ]"
  rm -rf "$TS"
else
  echo "  SKIP  theme check (tests/node_modules not installed: needs npm and network)"
fi
if [ "$HAVE_TC" -eq 1 ] && [ -n "${FOUNDATION_DIR:-}" ]; then
  check "theme check: the foundation theme has no errors and no warnings" "$TC $FOUNDATION_DIR --warnings-fail"
fi
[ -n "${FOUNDATION_DIR:-}" ] && rm -rf "$FOUNDATION_DIR"
echo; echo "Result: $PASS passed, $FAIL failed"; [ "$FAIL" -eq 0 ]
