/**
 * Based on http://jeromeetienne.github.com/jquery-qrcode/
 */
export function qr() { return 1; }
