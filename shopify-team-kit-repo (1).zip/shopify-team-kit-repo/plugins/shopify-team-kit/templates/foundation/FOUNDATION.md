# Foundation: global standards applied once per project

Applied by `/shopify-team-kit:foundation` (also offered at the end of `/setup-project`). Every item is additive and reversible; nothing is applied before you approve the plan.

## Files added (from `templates/foundation/`)
| File | Purpose |
|---|---|
| `assets/kit-base.css` | Two-tone focus ring, `.visually-hidden`, `.skip-link`, `.kit-target`, reduced motion, media max-width, scroll padding |
| `snippets/kit-skip-link.liquid` | Skip to content link (WCAG 2.4.1) |
| `snippets/kit-meta-tags.liquid` | Meta description, canonical, Open Graph, Twitter card |
| `snippets/kit-structured-data.liquid` | Organization JSON-LD on the home page |
| `locales/en.default.foundation.json` | Keys to merge into `locales/en.default.json` (never replace the file) |

Skip adding a snippet when the theme already has an equivalent (for example Dawn's `meta-tags` snippet). Reuse it and record that in the foundation report.

## Edits to `layout/theme.liquid`
| Area | Required state | Standard |
|---|---|---|
| `<html>` | `lang="{{ request.locale.iso_code }}"` | WCAG 3.1.1, SEO |
| viewport | `width=device-width, initial-scale=1` (no `maximum-scale`, no `user-scalable=no`) | WCAG 1.4.4 |
| `<title>` | from `page_title` with tag, page number and shop name handling | SEO |
| head | `{% render 'kit-meta-tags' %}` and `{% render 'kit-structured-data' %}` | SEO |
| stylesheets | `{{ 'kit-base.css' | asset_url | stylesheet_tag }}` first, before theme CSS and before `content_for_header` | Performance (first paint), A11y |
| body start | `{% render 'kit-skip-link' %}` | WCAG 2.4.1 |
| main | `<main id="MainContent" tabindex="-1">{{ content_for_layout }}</main>` | WCAG 2.4.1, landmarks |
| scripts | every `<script src>` has `defer` (or `async` when independent, or `type="module"`) | Performance |
| fonts | no Google/Typekit links; theme font pickers or self-hosted in `/assets` | Performance, privacy |

## Global checks run (reported, not auto-fixed)
- Color contrast of every color scheme in `config/settings_data.json` (`scripts/contrast-check.mjs`): text/background and button label/button at 4.5:1.
- `shopify theme check` and `quick-audit.mjs` baseline counts.
- `robots.txt.liquid`, sitemap, hreflang (Markets), header `h1` pattern, stylesheet count, third-party app scripts.
- Lighthouse mobile baseline for home, collection, product (manual; recorded in `docs/foundation-report.md`).

## Project-level defaults written to CLAUDE.md
Quality profile (`standard` or `strict`), targets (WCAG 2.2 AA, CWV, Lighthouse), ownership mode, dev theme, breakpoints, apps.
