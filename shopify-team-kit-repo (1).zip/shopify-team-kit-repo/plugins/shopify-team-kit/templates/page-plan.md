# Page plan: [page name]

- Figma page link:
- Mobile link:
- Template file: templates/[name].json
- Branch: feature/page-[name]
- Dev theme ID:
- Status: PLAN (awaiting approval) | BUILDING | QA | DONE

## Sections (in page order)
| # | Section | Figma node-id | Action (reuse / adapt / new) | Files | Settings and blocks | JS | Risk | Status |
|---|---|---|---|---|---|---|---|---|
| 1 | | | | | | | | [ ] |

## Global tokens
| Token | Figma value | Theme variable | Status (exists / add / snapped) |
|---|---|---|---|

## Design gaps and questions
- [ ]

## Data-dependent behavior (not in Figma)
- [ ]

## Approval
Approved by / date:
