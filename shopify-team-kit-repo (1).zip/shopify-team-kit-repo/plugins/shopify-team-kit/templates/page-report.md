# Page report: [page name]

Date:
Branch / commits:
Preview URL (dev theme):

## Build summary
| Section | Action | Files | Commit | Open gaps |
|---|---|---|---|---|

## Quality gate
| Check | Result |
|---|---|
| shopify theme check | |
| quick-audit (High / Med / Low) | |
| shopify-code-reviewer verdict | |
| One h1, heading order, landmarks | |
| Title, description, canonical, JSON-LD | |
| LCP element and loading | |
| New JS / CSS size, new stylesheets | |

## Fidelity vs Figma
| Section | Desktop | Mobile | Deviations and reason |
|---|---|---|---|

## Open items for the team
- Images to upload:
- Content to confirm:
- Design gaps / decisions needed:
- Data-dependent behavior to implement or confirm:

## Verified automatically
- theme check / audit / rendered QA / contrast / review (before -> after):

## Needs input from the team (each with a recommended default)
- 

## Not verifiable here
- 
