#!/usr/bin/env bash
# Backward-compatible wrapper for projects whose settings still point at the old bash hook.
exec node "$(dirname "$0")/stop-quality-gate.mjs" "$@"
