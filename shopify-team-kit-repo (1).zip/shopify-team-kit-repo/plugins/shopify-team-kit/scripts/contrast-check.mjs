#!/usr/bin/env node
/**
 * contrast-check.mjs: WCAG contrast check for the colors configured in a Shopify theme (no Python needed).
 *
 * Usage: node contrast-check.mjs [theme-dir] [--min 4.5] [--pair fgKey:bgKey ...] [--strict]
 * Reads config/settings_data.json (the "current" settings; falls back to the defaults in settings_schema.json).
 * It finds color pairs three ways:
 *   1. Nested color schemes: an object with "background" and "text" (Dawn, Horizon): text/background,
 *      button_label/button, secondary_button_label/background.
 *   2. Flat settings by naming convention: <stem>_bg with <stem>_color or <stem>_text (for example
 *      color_body_bg with color_body_color), and <stem> with <stem>_text for buttons.
 *   3. Your own mapping with --pair fgKey:bgKey (repeatable), for themes with other names.
 * ASSUMED checks (reported as WARN, they fail the run only with --strict): brand colors (primary, secondary,
 * accent, link...) against the body background, and against white text.
 *
 * Exit: 0 all checked pairs pass; 1 a pair is below the minimum; 3 NOTHING could be checked (contrast is NOT
 * verified: never treat 3 as a pass); 2 usage error.
 */
import fs from "node:fs";
import path from "node:path";

const argv = process.argv.slice(2);
let dir = ".", min = 4.5, strict = false; const userPairs = [];
for (let i = 0; i < argv.length; i++) {
  if (argv[i] === "--min") min = parseFloat(argv[++i]);
  else if (argv[i] === "--strict") strict = true;
  else if (argv[i] === "--pair") userPairs.push(argv[++i]);
  else dir = argv[i];
}

// ---- color parsing
const named = { white: "#ffffff", black: "#000000" };
function parseColor(v) {
  if (typeof v !== "string") return null;
  let s = v.trim().toLowerCase();
  if (named[s]) s = named[s];
  let m = /^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/.exec(s);
  if (m) { let h = m[1]; if (h.length <= 4) h = [...h].map((c) => c + c).join(""); return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)); }
  m = /^rgba?\(\s*([\d.]+)[ ,]+([\d.]+)[ ,]+([\d.]+)/.exec(s);
  if (m) return [m[1], m[2], m[3]].map((x) => Math.round(parseFloat(x)));
  m = /^hsla?\(\s*([\d.]+)(?:deg)?[ ,]+([\d.]+)%[ ,]+([\d.]+)%/.exec(s);
  if (m) { const h = parseFloat(m[1]) / 360, sat = parseFloat(m[2]) / 100, l = parseFloat(m[3]) / 100; const f = (n) => { const k = (n + h * 12) % 12, a = sat * Math.min(l, 1 - l); return Math.round(255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)))); }; return [f(0), f(8), f(4)]; }
  return null;
}
const lum = (rgb) => { const [r, g, b] = rgb.map((c) => { c /= 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
const ratio = (a, b) => { const la = lum(a), lb = lum(b); return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05); };

function readJson(p) { const raw = fs.readFileSync(p, "utf8").replace(/\/\*[\s\S]*?\*\//g, ""); return JSON.parse(raw); }
const isColorStr = (v) => typeof v === "string" && parseColor(v) !== null;

// collect groups: [{path, colors: {key: value}}] for every object that holds at least one color value
function collectGroups(node, p, out) {
  if (Array.isArray(node)) { node.forEach((v, i) => collectGroups(v, `${p}[${i}]`, out)); return; }
  if (node && typeof node === "object") {
    const colors = {};
    for (const [k, v] of Object.entries(node)) if (isColorStr(v)) colors[k] = v;
    if (Object.keys(colors).length) out.push({ path: p, colors });
    for (const [k, v] of Object.entries(node)) if (v && typeof v === "object") collectGroups(v, p ? `${p}/${k}` : k, out);
  }
}

function main() {
  const root = path.resolve(dir);
  const dataPath = path.join(root, "config", "settings_data.json"), schemaPath = path.join(root, "config", "settings_schema.json");
  let groups = [], source = "";
  if (fs.existsSync(dataPath)) {
    try {
      const data = readJson(dataPath);
      let cur = data.current;
      if (typeof cur === "string" && data.presets && data.presets[cur]) cur = data.presets[cur];
      collectGroups(cur && typeof cur === "object" ? cur : data, "", groups); source = "config/settings_data.json (current settings)";
    } catch (e) { console.log(`Cannot parse ${dataPath}: ${e.message}`); process.exit(2); }
  }
  if (!groups.length && fs.existsSync(schemaPath)) {
    try { // defaults from the schema: build {id: default} objects per settings group
      const schema = readJson(schemaPath);
      for (const sec of Array.isArray(schema) ? schema : []) {
        const colors = {};
        for (const s of sec.settings || []) if (s.type === "color" && isColorStr(s.default)) colors[s.id] = s.default;
        if (Object.keys(colors).length) groups.push({ path: sec.name || "schema", colors });
      }
      source = "config/settings_schema.json (default values; settings_data.json had no colors)";
    } catch (e) { console.log(`Cannot parse ${schemaPath}: ${e.message}`); process.exit(2); }
  }
  const total = groups.reduce((n, g) => n + Object.keys(g.colors).length, 0);
  console.log(`Minimum ratio: ${min}:1 (normal text, WCAG 1.4.3; UI components use 3:1)`);
  console.log(`Scanned: ${total} color settings in ${groups.length} group(s) from ${source || "no settings file found"}`);

  const rows = []; // {kind, group, label, ratio, need, explicit}
  const addPair = (g, fgKey, bgKey, need, explicit, note = "") => {
    const fg = parseColor(g.colors[fgKey]), bg = parseColor(g.colors[bgKey]);
    if (!fg || !bg) return;
    rows.push({ group: g.path || "(root)", label: `${fgKey === "__white" ? "white text" : fgKey} ${g.colors[fgKey]} on ${bgKey} ${g.colors[bgKey]}${note}`, ratio: ratio(fg, bg), need, explicit });
  };
  const seenPair = new Set();
  const pair = (g, f, b, need, explicit, note) => { const k = `${g.path}|${f}|${b}`; if (g.colors[f] !== undefined && g.colors[b] !== undefined && !seenPair.has(k)) { seenPair.add(k); addPair(g, f, b, need, explicit, note); } };

  for (const g of groups) {
    const keys = Object.keys(g.colors);
    // 1. nested schemes
    if (g.colors.background && g.colors.text) {
      pair(g, "text", "background", min, true); pair(g, "button_label", "button", min, true); pair(g, "secondary_button_label", "background", min, true);
    }
    // 2. flat convention: <stem>_bg with <stem>_color / _text ; <stem> with <stem>_text for buttons
    for (const k of keys) {
      const m = /^(.*?)_?(bg|background|bg_color|background_color)$/.exec(k);
      if (m) { const stem = m[1]; for (const suffix of ["color", "text", "text_color", "label", "link", "heading", "heading_color"]) { const fgKey = stem ? `${stem}_${suffix}` : suffix; if (fgKey !== k) pair(g, fgKey, k, min, true); } }
      for (const suffix of ["text", "text_color", "label", "contrast", "on"]) if (g.colors[`${k}_${suffix}`] !== undefined) pair(g, `${k}_${suffix}`, k, min, true);
    }
    // 3. explicit --pair mappings
    for (const up of userPairs) { const [f, b] = (up || "").split(":"); if (f && b) pair(g, f, b, min, true); }
    // assumed checks for brand/link colors
    const bodyBgKey = keys.find((k) => /^(color_)?(body_)?(bg|background)(_color)?$|^color_body_bg$|^body_bg$/.test(k)) || keys.find((k) => /body.*bg|page.*bg/.test(k));
    for (const k of keys) {
      if (!/^(color_)?(primary|secondary|accent|success|danger|warning|info|link|brand)(_color)?$|^link(_color)?$/.test(k)) continue;
      if (bodyBgKey && k !== bodyBgKey) pair(g, k, bodyBgKey, /link/.test(k) ? min : 3, false, /link/.test(k) ? " (link text on body background)" : " (UI use on body background, 3:1)");
      if (!/link/.test(k)) { const white = { colors: { ...g.colors, __white: "#ffffff" }, path: g.path }; pair(white, "__white", k, min, false, " (ASSUMED white text on this color)"); }
    }
  }

  const explicit = rows.filter((r) => r.explicit);
  console.log("RESULT | group | pair | ratio | basis");
  let fail = 0, warn = 0;
  for (const r of rows) {
    const ok = r.ratio >= r.need;
    const tag = ok ? "PASS" : r.explicit ? "FAIL" : "WARN";
    if (!ok) { if (r.explicit) fail++; else warn++; }
    console.log(`${tag} | ${r.group} | ${r.label} | ${r.ratio.toFixed(2)} (need ${r.need}) | ${r.explicit ? "paired by name" : "assumed"}`);
  }
  console.log(`\nChecked ${explicit.length} named pair(s) and ${rows.length - explicit.length} assumed pair(s); ${fail} failing, ${warn} warning(s).`);
  if (explicit.length === 0) {
    console.log("WARNING: no color pairs could be matched automatically, so contrast is NOT VERIFIED (this is not a pass).");
    console.log('Tell the checker which settings go together, for example: --pair color_body_color:color_body_bg --pair color_primary_text:color_primary');
    process.exit(3);
  }
  process.exit(fail > 0 || (strict && warn > 0) ? 1 : 0);
}

main();
