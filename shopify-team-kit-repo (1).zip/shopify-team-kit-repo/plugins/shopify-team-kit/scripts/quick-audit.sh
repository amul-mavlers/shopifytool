#!/usr/bin/env bash
# Backward-compatible wrapper: the audit now runs in Node (single process, no Python/grep/awk).
exec node "$(dirname "$0")/quick-audit.mjs" "$@"
