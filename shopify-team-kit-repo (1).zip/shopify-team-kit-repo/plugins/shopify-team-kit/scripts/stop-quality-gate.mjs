#!/usr/bin/env node
/**
 * stop-quality-gate.mjs: opt-in Claude Code Stop hook (Node: works on Windows, macOS and Linux).
 * Claude cannot finish a turn while changed theme files fail the static audit for the project's quality profile.
 * Exit 2 = block (stderr is fed back to Claude, which keeps working); exit 0 = allow.
 * Fails open on anything unexpected and never blocks twice in a row (stop_hook_active), so it cannot loop.
 * It is not silent when it cannot work: it prints a systemMessage so the user sees why the gate was skipped.
 * Works when the theme is the project folder or sits in a subfolder (monorepo, nested zip extraction).
 */
import fs from "node:fs";
import path from "node:path";
import { execFileSync, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const skip = (msg) => { if (msg) process.stdout.write(JSON.stringify({ systemMessage: `Quality gate hook: ${msg}` }) + "\n"); process.exit(0); };

let input = "";
try { input = fs.readFileSync(0, "utf8"); } catch { /* no stdin */ }
if (/"stop_hook_active"\s*:\s*true/.test(input)) process.exit(0); // already continuing after a block

const projectDir = path.resolve(process.env.CLAUDE_PROJECT_DIR || process.cwd());
const isTheme = (d) => fs.existsSync(path.join(d, "layout", "theme.liquid"));
const findTheme = (d, depth) => {
  if (isTheme(d)) return d;
  if (depth >= 3) return null;
  let ents; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return null; }
  for (const e of ents) {
    if (!e.isDirectory() || e.name === "node_modules" || e.name === ".git") continue;
    const r = findTheme(path.join(d, e.name), depth + 1); if (r) return r;
  }
  return null;
};
const themeRoot = findTheme(projectDir, 0);
if (!themeRoot) process.exit(0); // not a theme project: nothing to gate

// locate the audit script: theme/scripts, project/scripts, or next to this hook file
const here = path.dirname(fileURLToPath(import.meta.url));
const audit = [path.join(themeRoot, "scripts", "quick-audit.mjs"), path.join(projectDir, "scripts", "quick-audit.mjs"), path.join(here, "quick-audit.mjs")].find((p) => fs.existsSync(p));
if (!audit) skip("scripts/quick-audit.mjs was not found, so the gate was skipped. Run /shopify-team-kit:setup-project to install it.");

const git = (args, cwd) => { try { return execFileSync("git", args, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }); } catch { return null; } };
if (git(["rev-parse", "--git-dir"], themeRoot) === null) skip("this project is not a git repository, so changed files cannot be detected and the gate was skipped.");

let failOn = "high";
for (const d of [themeRoot, projectDir]) {
  try { if (/quality profile:[^A-Za-z]*strict/i.test(fs.readFileSync(path.join(d, "CLAUDE.md"), "utf8"))) { failOn = "med"; break; } } catch { /* no CLAUDE.md here */ }
}

const r = spawnSync(process.execPath, [audit, themeRoot, "--changed", "--fail-on", failOn], { encoding: "utf8" });
if (r.status === 1) {
  const out = (r.stdout || "").split(/\r?\n/).slice(0, 40).join("\n");
  process.stderr.write(`QUALITY GATE: changed theme files fail the static audit (profile fails on: ${failOn}). Fix these before finishing:\n${out}\nThen re-run: node scripts/quick-audit.mjs . --changed --fail-on ${failOn}\n`);
  process.exit(2);
}
process.exit(0);
