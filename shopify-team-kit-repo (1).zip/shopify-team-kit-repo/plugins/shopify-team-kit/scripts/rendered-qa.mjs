#!/usr/bin/env node
/**
 * rendered-qa.mjs: automated accessibility + SEO + performance checks on RENDERED pages.
 *
 * Usage: node rendered-qa.mjs <url|file.html> [more targets] [--fail-on high|med] [--no-fail]
 * Targets: a local preview URL (shopify theme dev serves http://127.0.0.1:9292), a dev-theme preview URL
 * that is reachable without a login, or saved HTML files.
 * Output: SEV | RULE | target | message, then a summary. Exit 1 if findings reach --fail-on (default high).
 *
 * What it does: runs axe-core (WCAG 2.0/2.1/2.2 A/AA + best-practice rules) on the DOM in jsdom and adds
 * Shopify-specific head/SEO/performance rules. Limits: jsdom has no layout engine, so color contrast,
 * focus visibility, target size and visual overlap are NOT checked here (see contrast-check.py and the
 * reviewer agent); JavaScript-rendered content is not executed.
 */
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
let JSDOM, axeSource;
try {
  ({ JSDOM } = await import("jsdom"));
  axeSource = readFileSync(require.resolve("axe-core/axe.min.js"), "utf8");
} catch {
  console.error("Missing dependencies (jsdom, axe-core). From this script's folder run: npm install --no-audit --no-fund");
  console.error("(setup-project does this for scripts/qa/ automatically.)");
  process.exit(2);
}

const args = process.argv.slice(2);
let failOn = "high", noFail = false;
const targets = [];
for (let i = 0; i < args.length; i++) {
  if (args[i] === "--fail-on") failOn = args[++i] || "high";
  else if (args[i].startsWith("--fail-on=")) failOn = args[i].split("=")[1];
  else if (args[i] === "--no-fail") noFail = true;
  else targets.push(args[i]);
}
if (!["high", "med"].includes(failOn)) { console.error("--fail-on must be high or med"); process.exit(2); }
if (!targets.length) { console.error("Usage: node rendered-qa.mjs <url|file.html> [...] [--fail-on high|med] [--no-fail]"); process.exit(2); }

const findings = [];
const add = (sev, rule, target, msg) => findings.push({ sev, rule, target, msg });
const sevFromImpact = (i) => (i === "critical" || i === "serious" ? "HIGH" : i === "moderate" ? "MED" : "LOW");

async function load(target) {
  if (/^https?:\/\//i.test(target)) {
    const res = await fetch(target, { redirect: "follow", headers: { "user-agent": "shopify-team-kit-rendered-qa" } });
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${target}`);
    return { html: await res.text(), url: target };
  }
  return { html: readFileSync(target, "utf8"), url: "http://localhost/" };
}

function customChecks(doc, target) {
  const q = (s) => [...doc.querySelectorAll(s)];
  // ---- head / SEO
  const title = doc.querySelector("title")?.textContent.trim() ?? "";
  if (!title) add("HIGH", "R01", target, "Missing or empty <title>");
  else if (title.length > 70) add("LOW", "R01", target, `Title is ${title.length} chars (aim for about 60)`);

  const desc = doc.querySelector('meta[name="description"]')?.getAttribute("content")?.trim() ?? "";
  if (!desc) add("MED", "R02", target, "Missing meta description");
  else if (desc.length > 170) add("LOW", "R02", target, `Meta description is ${desc.length} chars (aim for about 160)`);

  const canon = q('link[rel="canonical"]');
  if (canon.length === 0) add("HIGH", "R03", target, "Missing canonical link");
  else if (canon.length > 1) add("HIGH", "R03", target, `${canon.length} canonical links (must be exactly one)`);
  else if (!/^https?:\/\//i.test(canon[0].getAttribute("href") || "")) add("MED", "R03", target, "Canonical href is not an absolute URL");

  const h1 = q("h1").length;
  if (h1 === 0) add("HIGH", "R04", target, "No <h1> on the page");
  else if (h1 > 1) add("MED", "R04", target, `${h1} <h1> elements (one per page)`);

  let products = 0;
  q('script[type="application/ld+json"]').forEach((s, i) => {
    try {
      const walk = (n) => {
        if (Array.isArray(n)) return n.forEach(walk);
        if (n && typeof n === "object") {
          const t = n["@type"];
          if (t === "Product" || t === "ProductGroup" || (Array.isArray(t) && (t.includes("Product") || t.includes("ProductGroup")))) products++;
          Object.values(n).forEach(walk);
        }
      };
      walk(JSON.parse(s.textContent));
    } catch { add("HIGH", "R05", target, `JSON-LD block ${i + 1} is not valid JSON`); }
  });
  if (products > 1) add("MED", "R05", target, `${products} Product/ProductGroup JSON-LD blocks (duplicates from theme plus an app?)`);

  if (!doc.querySelector('meta[property="og:title"]')) add("LOW", "R06", target, "No Open Graph tags");
  const robots = doc.querySelector('meta[name="robots"]')?.getAttribute("content") || "";
  if (/noindex/i.test(robots)) add("MED", "R12", target, `meta robots "${robots}": confirm this page should be excluded from search`);
  const vp = doc.querySelector('meta[name="viewport"]')?.getAttribute("content") || "";
  if (/maximum-scale|user-scalable\s*=\s*(no|0)/i.test(vp)) add("HIGH", "R14", target, `Viewport blocks zoom: "${vp}"`);

  // ---- performance / CLS / LCP
  const imgs = q("img").filter((i) => !i.closest("noscript"));
  const noDims = imgs.filter((i) => !(i.getAttribute("width") && i.getAttribute("height")));
  if (noDims.length) add("MED", "R08", target, `${noDims.length} <img> without width and height (layout shift): e.g. ${noDims[0].getAttribute("src")?.slice(0, 70)}`);
  const firstContentImg = (doc.querySelector("main") || doc.body).querySelector("img");
  if (firstContentImg && /lazy/i.test(firstContentImg.getAttribute("loading") || ""))
    add("MED", "R09", target, "First image in <main> is lazy-loaded: if it is above the fold it is the LCP image and must be eager with fetchpriority=high");
  q("head script[src]").forEach((s) => {
    if (!s.hasAttribute("defer") && !s.hasAttribute("async") && s.getAttribute("type") !== "module")
      add("MED", "R10", target, `Render-blocking script in <head>: ${s.getAttribute("src").slice(0, 80)}`);
  });
  const sheets = q('link[rel="stylesheet"]').length;
  if (sheets > 8) add("LOW", "R11", target, `${sheets} stylesheet links on this page`);

  // ---- structure
  const seen = new Map();
  q("[id]").forEach((e) => seen.set(e.id, (seen.get(e.id) || 0) + 1));
  const dups = [...seen].filter(([, n]) => n > 1).map(([id]) => id);
  if (dups.length) add("MED", "R13", target, `Duplicate id values: ${dups.slice(0, 5).join(", ")}`);
  const firstLink = doc.querySelector("body a[href], body button");
  const skipOk = firstLink && firstLink.tagName === "A" && /^#./.test(firstLink.getAttribute("href") || "") && doc.getElementById(firstLink.getAttribute("href").slice(1));
  if (!skipOk) add("MED", "R18", target, "First focusable element is not a working skip link (#id that exists)");
}

async function audit(target) {
  const { html, url } = await load(target);
  const dom = new JSDOM(html, { url, runScripts: "outside-only", pretendToBeVisual: true });
  const { window } = dom;
  customChecks(window.document, target);
  window.eval(axeSource);
  const results = await window.axe.run(window.document, {
    runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa", "best-practice"] },
    rules: { "color-contrast": { enabled: false }, "color-contrast-enhanced": { enabled: false }, region: { enabled: false } },
    resultTypes: ["violations"],
  });
  for (const v of results.violations) {
    const node = v.nodes[0];
    const where = node ? ` e.g. ${String(node.target).slice(0, 80)}` : "";
    add(sevFromImpact(v.impact), `axe:${v.id}`, target, `${v.help} (${v.nodes.length} element${v.nodes.length > 1 ? "s" : ""})${where}`);
  }
  window.close();
}

for (const t of targets) {
  try { await audit(t); } catch (e) { add("HIGH", "R00", t, `Could not load or audit: ${e.message}`); }
}

const order = { HIGH: 0, MED: 1, LOW: 2 };
findings.sort((a, b) => order[a.sev] - order[b.sev]);
for (const f of findings) if (f.sev !== "LOW" || process.env.VERBOSE) console.log(`${f.sev} | ${f.rule} | ${f.target} | ${f.msg}`);
const c = (s) => findings.filter((f) => f.sev === s).length;
console.log(`\nSummary: HIGH=${c("HIGH")}  MED=${c("MED")}  LOW=${c("LOW")}${c("LOW") && !process.env.VERBOSE ? " (LOW hidden, set VERBOSE=1)" : ""}   Rendered HTML only: no color contrast, focus visibility, target size or JS-rendered content.`);
if (!noFail && (c("HIGH") || (failOn === "med" && c("MED")))) process.exit(1);
