# Shopify theme performance: recommendation tables

Condensed from shopify.dev "Performance best practices for Shopify themes". Impact = High / Medium / Low as rated by Shopify. Metric = the Core Web Vital or timing it moves.

## Contents
1. Metrics glossary
2. Essential
3. Liquid
4. Images
5. JavaScript
6. CSS and fonts
7. Resource hints and CDN
8. Mobile

## 1. Metrics glossary

- TTFB: time to first byte; on Shopify mostly Liquid rendering. Streamed responses show only the head in TTFB; the rest of Liquid time shows in document download time.
- FCP: first text or image painted; late when stylesheets and scripts in `<head>` block.
- LCP (Core Web Vital): largest element in the initial viewport, usually the hero or product image.
- CLS (Core Web Vital): unexpected layout movement (images without size, font swap, app-injected content).
- INP (Core Web Vital): responsiveness after tap or click; main-thread JavaScript is the usual cause.

## 2. Essential

| Rule | Metric | Impact |
|---|---|---|
| Never lazy-load the LCP image | LCP | High |
| `fetchpriority="high"` on the LCP image | LCP | High |
| Do not hide the LCP image behind animations | LCP | High |
| Render essential content in Liquid/HTML, not JS | LCP | High |
| Avoid deeply nested Liquid loops | TTFB | High |
| Load first-paint resources before `content_for_header` | FCP | High |
| Use `preload` sparingly (1 or 2 resources) | LCP | Medium |

## 3. Liquid

| Rule | Metric | Impact |
|---|---|---|
| Avoid nested loops (O(n^2)) incl. metafield access in loops | TTFB | High |
| Move metafield access outside loops; theme settings over metafields for static data | TTFB | High |
| Avoid over-fetching product variants | TTFB | High |
| Limit loop fetch (`limit`, `paginate`) | TTFB | High |
| Limit pagination depth (under 25,000 objects) | TTFB | Medium |
| Flatten nested `render`, especially in loops | TTFB | Medium |
| Defer dialog/drawer content loading | TTFB | Medium |
| Defer child product loading in combined listings | TTFB | Medium |
| Filter collections before entering loops | TTFB | Medium |
| Move repeated `assign` and filters outside loops | TTFB | Medium |
| Use `section.index` for above/below fold loading | LCP | Medium |
| Use the Section Rendering API for dynamic updates | TTFB | Medium |
| Cache repeated filter results with `assign` | TTFB | Low |
| Assign `block.settings` to a variable | TTFB | Low |
| `echo` or `{{ }}` instead of `append`/`prepend` | TTFB | Low |

## 4. Images

| Rule | Metric | Impact |
|---|---|---|
| `fetchpriority="high"` on LCP image | LCP | High |
| Never lazy-load LCP image | LCP | High |
| No animation hiding LCP image | LCP | High |
| No CSS `background-image` for hero/LCP | LCP | High |
| `srcset` + `sizes` with `image_tag` | LCP | Medium |
| `width` and `height` on every `<img>` (or `image_tag`) | CLS | Medium |
| `image_url` / `image_tag` instead of manual CDN URLs | LCP | Medium |
| Prevent dialogs hijacking LCP | LCP | Medium |
| `<picture>` for separate mobile/desktop images | LCP | Medium |

## 5. JavaScript

| Rule | Metric | Impact |
|---|---|---|
| Remove render-blocking apps | LCP | High |
| Render essential content server-side | LCP | High |
| Send critical data requests before DOM ready (async bundle in head) | LCP | High |
| Audit and remove unused scripts | INP | High |
| `defer` / `async` on non-critical scripts | LCP | High |
| Load JavaScript on user interaction (dynamic `import()`) | INP | High |
| Remove A/B anti-flicker when no test runs | LCP | High |
| Defer render-blocking CSS and JS | LCP | Medium |
| Debounce, throttle, yield in handlers | INP | Medium |
| Cancel view transitions on interaction | INP | Medium |
| Build DOM for hidden components only when opened | INP | Medium |
| Import maps instead of bundlers (do not add `es-module-shims`) | FCP | Low |

## 6. CSS and fonts

| Rule | Metric | Impact |
|---|---|---|
| Reduce stylesheet count | INP | High |
| Reduce CLS from font swapping (`size-adjust`) | CLS | High |
| Load critical CSS synchronously | FCP | High |
| First-paint resources above `content_for_header` | FCP | High |
| Self-host fonts on Shopify CDN | FCP | Medium |
| System fonts where possible | FCP | Medium |
| Reserve space for app-injected content | CLS | Medium |
| Animate `transform`/`opacity` | INP | Medium |
| Merge duplicate mobile/desktop menus | INP | Medium |
| Stylesheet subsetting compatibility (`{% stylesheet %}`) | FCP | Medium |

## 7. Resource hints and CDN

| Rule | Metric | Impact |
|---|---|---|
| Avoid request proxies | TTFB | High |
| Serve assets from Shopify CDN (`/assets`) | TTFB | Medium |
| `preload` sparingly | LCP | Medium |
| Speculation Rules API | TTFB | Medium |
| `preconnect` to critical third-party origins | LCP | Medium |

## 8. Mobile

| Rule | Metric | Impact |
|---|---|---|
| Test with real mobile CPU and network throttling | LCP | High |
| Remove intrusive interstitials | LCP | High |
| Responsive layouts that perform well | LCP | Medium |
| Tap targets at least 48x48 px (Shopify perf guide) | INP | Medium |
| No content wider than viewport | CLS | Medium |
| Content parity between mobile and desktop | LCP | Medium |

Team note: accessibility requires primary tap targets of at least 44x44 px; use 48 px where space allows so both guides are satisfied.
