# SEO snippets and checklist

## Contents
1. Title, description, canonical (from shopify.dev)
2. Open Graph and Twitter
3. Product JSON-LD
4. Organization and WebSite JSON-LD
5. BreadcrumbList JSON-LD
6. robots.txt.liquid note
7. Per-template checklist

## 1. Title, description, canonical

Pattern from shopify.dev "Add SEO metadata to your theme" (see also Dawn `layout/theme.liquid`):

```liquid
<title>
  {{ page_title -}}
  {%- if current_tags %} &ndash; tagged "{{ current_tags | join: ', ' }}"{% endif -%}
  {%- if current_page != 1 %} &ndash; Page {{ current_page }}{% endif -%}
  {%- unless page_title contains shop.name %} &ndash; {{ shop.name }}{% endunless -%}
</title>

{%- if page_description != blank -%}
  <meta name="description" content="{{ page_description | escape }}">
{%- endif -%}

<link rel="canonical" href="{{ canonical_url }}">
```

Edit SEO title and description per resource in Shopify admin under "Search engine listing". Bulk: export products, fill SEO Title and SEO Description columns, re-import.

## 2. Open Graph and Twitter

```liquid
<meta property="og:site_name" content="{{ shop.name | escape }}">
<meta property="og:url" content="{{ canonical_url }}">
<meta property="og:title" content="{{ page_title | default: shop.name | escape }}">
<meta property="og:type" content="{% if template.name == 'product' %}product{% elsif template.name == 'article' %}article{% else %}website{% endif %}">
{%- if page_description != blank -%}
  <meta property="og:description" content="{{ page_description | escape }}">
{%- endif -%}
{%- assign og_image = page_image | default: settings.share_image -%}
{%- if og_image != blank -%}
  <meta property="og:image" content="https:{{ og_image | image_url: width: 1200 }}">
{%- endif -%}
<meta name="twitter:card" content="summary_large_image">
```

Check whether the base theme already ships a meta-tags snippet (Dawn has one) and reuse it rather than duplicating tags.

## 3. Product JSON-LD

```liquid
<script type="application/ld+json">
  {{ product | structured_data }}
</script>
```

- Dawn's `main-product` section already includes this. Do not add a second block.
- Verify one block only: `curl -s https://STORE/products/HANDLE | grep -c 'application/ld+json'` then inspect each block's `@type`.

## 4. Organization and WebSite JSON-LD (theme.liquid, home page only is fine)

```liquid
{%- if template.name == 'index' -%}
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": {{ shop.name | json }},
  "url": {{ shop.url | json }}
  {%- if settings.logo != blank -%},
  "logo": {{ settings.logo | image_url: width: 600 | prepend: 'https:' | json }}
  {%- endif -%}
}
</script>
{%- endif -%}
```

Use `| json` for every dynamic value so quotes and special characters cannot break the JSON.

## 5. BreadcrumbList JSON-LD (snippet, rendered on product, collection, article)

```liquid
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Home", "item": {{ shop.url | json }} }
    {%- if collection != blank -%},
    { "@type": "ListItem", "position": 2, "name": {{ collection.title | json }}, "item": {{ collection.url | prepend: shop.url | json }} }
    {%- endif -%}
  ]
}
</script>
```

Add the final item for the product or article when the visible breadcrumb shows it. The structured data must match the visible breadcrumb.

## 6. robots.txt.liquid

Shopify allows editing via `templates/robots.txt.liquid`. Start from Shopify's current default template (see "Edit robots.txt.liquid" in Shopify Help) and add rules inside the `*` user-agent group, for example to reduce crawl waste from tag or facet URLs. Do not hand-write the whole file, and do not block `/collections/*` broadly. Test with Search Console after deploying.

## 7. Per-template checklist

| Check | Home | Collection | Product | Article | Page |
|---|---|---|---|---|---|
| Unique title (about 60 chars) | x | x | x | x | x |
| Meta description (about 160) | x | x | x | x | x |
| Canonical = `canonical_url` | x | x | x | x | x |
| Exactly one `<h1>` | x | x | x | x | x |
| Heading order without skips | x | x | x | x | x |
| JSON-LD valid and single per type | Organization | BreadcrumbList | Product + Breadcrumb | Article + Breadcrumb | optional |
| Image alt text | x | x | x | x | x |
| OG and Twitter tags | x | x | x | x | x |
| Internal links to canonical URLs | x | x | x | x | x |
| `lang` matches locale | x | x | x | x | x |
| Core Web Vitals pass (see performance skill) | x | x | x | x | x |
| No accidental `noindex` | x | x | x | x | x |
