# Page orchestration playbook (used by /figma-to-page)

## Contents
1. Why section-by-section
2. Splitting a page frame
3. Reuse, adapt or new
4. Token strategy
5. Page template JSON
6. Header and footer
7. Context and rate-limit management
8. Stop conditions
9. What Figma cannot provide

## 1. Why section-by-section
One request for a whole page overflows context, truncates the Figma response, and produces generic code. Per-section builds keep each response small, give a quality gate per commit, and make failures cheap to redo.

## 2. Splitting a page frame
- Use `get_metadata` on the page node to see top-level children. Each full-width child is a candidate section.
- Name sections from the Figma layer names; if layers are unnamed ("Frame 1234"), name by content and flag it as a design-file quality issue.
- Group tiny sibling frames that belong together (a heading frame plus its card grid) into one section.
- Repeated items inside a section (cards, logos, testimonials, FAQ rows) become blocks, not separate sections.

## 3. Reuse, adapt or new
| Situation | Action |
|---|---|
| Same layout exists in the theme (hero, rich text, image with text, collection list, featured collection, FAQ, newsletter) | Reuse and configure through settings; no new code |
| Existing section is close (different spacing, one extra element) | Adapt: ownership `owned` edits in place; `third-party` copies to `custom-*` |
| Layout not in the theme | New `custom-*` section |
Prefer reuse: less code, less QA, better performance.

## 4. Token strategy
Do tokens once in Phase 2. Sections consume CSS variables only. Gaps (a color or type style not in the theme) are added as settings, not hardcoded in a section. If the Figma uses off-scale values (13 px gaps, near-duplicate colors), snap to the nearest token and list the deviation in the report.

## 5. Page template JSON
```json
{
  "sections": {
    "hero": {
      "type": "custom-hero",
      "settings": { "heading": "Heading from Figma" },
      "blocks": {
        "cta": { "type": "button", "settings": { "label": "Shop now" } }
      },
      "block_order": ["cta"]
    },
    "features": { "type": "custom-features", "settings": {} }
  },
  "order": ["hero", "features"]
}
```
- Keys are unique ids; `order` is the render order; `block_order` orders blocks.
- Do not set image settings to guessed handles. Leave them empty and list what to upload.
- Name: `templates/index.json` for home, `templates/page.[name].json` for a custom page template.

## 6. Header and footer
They live in section groups (`sections/header-group.json`, `sections/footer-group.json`) rendered by `{% sections 'header-group' %}` in `layout/theme.liquid`. Change them only if the page design differs from the current ones, and warn that this affects every page.

## 7. Context and rate-limit management
- One Figma node per call; never the whole page at once after the plan.
- Do not re-read files already read. Commit after each section so work is saved.
- If the Figma MCP returns a rate-limit or truncation error: wait, re-query a smaller child node, and continue from the last committed section.
- Long runs: after Phase 3, summarize state in `docs/page-plan-[name].md` (checklist with done marks) so a new session can resume.

## 8. Stop conditions (ask the user)
- A section fails the quality gate twice.
- Design needs data or behavior not specified (filters, product logic, forms, integrations).
- Fonts or assets are not licensed or not available.
- Design fails WCAG contrast on core text or controls (report the color pairs; do not silently change brand colors).
- The plan would modify header, footer or global CSS used by other pages.

## 9. What Figma cannot provide
Real product data and mapping, hover/error/empty/loading states not drawn, cart/variant/filter/search behavior, form handling and integrations, real content and image assets, and accessibility behavior (focus order, announcements). The report must list each gap the build had to assume.
