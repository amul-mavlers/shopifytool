---
description: "Draft a short plain-language client update from the work done in this repo or conversation."
argument-hint: "[work done / period / audience, optional]"
allowed-tools: Read, Bash(git log:*), Bash(git diff:*)
---

Draft a client update. Input: $ARGUMENTS. If empty, use `git log --since="7 days ago" --oneline` and `git diff --stat main...HEAD`.

Format (plain language, no jargon, no code):
1. **Completed**: what changed and what the client will notice.
2. **In progress / pending**: with the reason.
3. **Needed from you**: specific inputs, approvals, assets, with a suggested date.
4. **Risks or decisions**: only if real.
5. **Next steps**.

Keep to under 180 words. Do not mention internal tooling. Do not state anything as tested or live unless the work log says so.
