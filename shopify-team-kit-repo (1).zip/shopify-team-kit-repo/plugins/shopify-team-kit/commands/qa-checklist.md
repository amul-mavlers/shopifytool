---
description: "Generate a precise manual QA / UAT checklist for a change or feature."
argument-hint: "[feature or branch, default: current changes]"
allowed-tools: Read, Glob, Grep, Task, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*)
---

Use the `shopify-qa-tester` agent to produce the QA checklist for: $ARGUMENTS (default: current branch changes). Return its table as is.
