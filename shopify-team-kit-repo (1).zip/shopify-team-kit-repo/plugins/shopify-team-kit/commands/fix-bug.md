---
description: "Find the root cause of a theme bug and fix it with the smallest safe change."
argument-hint: "[what happens] [expected] [page URL or template]"
allowed-tools: Read, Edit, Glob, Grep, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(node scripts/quick-audit.mjs:*), Bash(node scripts/contrast-check.mjs:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(npm install:*), Bash(curl -sI:*)
---

Bug report: $ARGUMENTS

1. Restate the bug as: Actual / Expected / Where (template or URL). If any of the three is missing and cannot be inferred, ask once.
2. Locate the cause by reading the relevant template, section, snippet, JS and CSS. Check for: wrong or missing guards, `render` scope (no leaked variables), schema defaults, Section Rendering API partial updates, Theme Editor events, cart event wiring, locale keys, app block interference.
3. Fix with the smallest change that follows `shopify-theme-standards`. Do not refactor unrelated code.
4. Explain in 3 lines: root cause, fix, and why it will not recur. List the files changed.
5. Run the quality gate (skill `shopify-quality-gate`) and fix everything it finds automatically; ask only for real blockers. Confirm the bug is gone by reproducing the original steps with the preview or rendered HTML where possible, and state the result in the Done report.
