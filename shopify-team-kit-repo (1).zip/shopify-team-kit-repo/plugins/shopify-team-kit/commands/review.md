---
description: "Review current changes (git diff) against standards, ADA, performance and SEO. Read-only."
argument-hint: "[optional branch, commit range or files]"
allowed-tools: Read, Glob, Grep, Task, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(node scripts/quick-audit.mjs:*), Bash(node scripts/contrast-check.mjs:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(npm install:*), Bash(curl -sI:*)
---

Use the `shopify-code-reviewer` agent to review: $ARGUMENTS (default: `git diff main...HEAD` plus uncommitted changes).

Return its table and verdict unchanged. Then ask whether to fix High and Medium issues; if yes, fix them, re-run the review, and show only what changed in the table.
