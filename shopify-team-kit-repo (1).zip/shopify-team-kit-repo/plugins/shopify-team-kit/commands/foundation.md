---
description: "One-time (re-runnable) global foundation: apply the team's global, SEO, accessibility, performance and layout standards to this theme after a plan you approve, then record the baseline."
argument-hint: "[optional: standard | strict]"
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(git checkout:*), Bash(git --version:*), Bash(node --version:*), Bash(shopify version:*), Bash(find:*), Bash(mkdir:*), Bash(cp:*), Bash(chmod:*), Bash(node scripts/quick-audit.mjs:*), Bash(node scripts/contrast-check.mjs:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(npm install:*), Bash(curl -sI:*)
---

Set up the global foundation for this theme. Profile argument: $ARGUMENTS (default: ask once, recommend `standard`).

Read `templates/foundation/FOUNDATION.md` from the installed kit (locate with `find ~/.claude/plugins -type d -name shopify-team-kit | head -1`, call it KIT) and follow it. Work on a branch `chore/foundation`. Never touch the live theme.

## Phase 1: inspect (read-only)
1. Confirm a theme root and that `CLAUDE.md` exists; if not, run the `/shopify-team-kit:setup-project` procedure first (facts only, skip its foundation offer).
2. Read `layout/theme.liquid`, `config/settings_schema.json`, the snippet list, `locales/en.default.json`.
3. Run `node scripts/quick-audit.mjs . --no-fail` and `node scripts/contrast-check.mjs .` and keep the numbers as the BEFORE baseline.
4. For every row of the FOUNDATION.md tables, decide: already present, equivalent exists (name it), missing, or conflicting.

## Phase 2: plan (then STOP for approval)
Show one table: `Area | Standard | Current | Action | Risk`. Cover: html lang, viewport, title, meta description, canonical, Open Graph/Twitter, Organization JSON-LD, skip link, main landmark, focus ring and visually-hidden utilities, reduced motion, script defer, fonts, stylesheet order, locale keys, color contrast, robots/sitemap/hreflang notes, third-party app scripts. State which files will be created or edited. **Do not edit any file before I approve.**

## Phase 3: apply (additive and minimal)
- Copy only the needed files from `KIT/templates/foundation/` (skip a snippet when an equivalent exists; reuse it). Never overwrite an existing file; if a name collides, stop and ask.
- Merge locale keys into `locales/en.default.json` without removing keys. Add other locales only if the store uses them (note missing translations).
- Patch `layout/theme.liquid` with the smallest edits from FOUNDATION.md. Keep existing code that already meets the standard.
- Do not change colors, fonts or design. Contrast and design issues are reported, not changed.

## Phase 4: record the profile and baseline
- Write the chosen Quality profile and targets into `CLAUDE.md` (add the lines if missing).
- Run the quality gate (skill `shopify-quality-gate`): fix everything it finds automatically (using the playbook) except items that need my input, then rerun the audit and contrast check for the AFTER numbers.
- Write `docs/foundation-report.md`: BEFORE/AFTER counts, what was added, what was reused, what was skipped and why, contrast results, open items (app scripts, hreflang/Markets, robots), and a Lighthouse mobile baseline table (home, collection, product) with `__` for me to fill in.
- Commit `chore: foundation (global, SEO, accessibility, performance)` only if I ask.
Finish with the Done report format from the quality-gate skill.
