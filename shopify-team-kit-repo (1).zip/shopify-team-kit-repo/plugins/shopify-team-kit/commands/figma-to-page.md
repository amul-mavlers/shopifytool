---
description: "Build a full Shopify page from a Figma page link: plan, approve, global tokens, section-by-section build with quality gates, template assembly, page-level audit and fidelity report."
argument-hint: "[figma page frame link] [optional: mobile page link] [template name, e.g. page.about or index]"
allowed-tools: Read, Write, Edit, Glob, Grep, Task, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(git checkout:*), Bash(node scripts/quick-audit.mjs:*), Bash(node scripts/contrast-check.mjs:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(npm install:*), Bash(curl -sI:*)
---

Build a full page from Figma: $ARGUMENTS

Use `figma-to-shopify`, `shopify-theme-standards`, `shopify-ada-wcag`, `shopify-performance`, `shopify-seo`. Read `references/page-orchestration.md` in the `figma-to-shopify` skill before starting. Work on a feature branch, never the live theme.

## Phase 0: preconditions (stop and tell me if any fails)
- Figma MCP connected (`/mcp`). `CLAUDE.md` exists (else run `/shopify-team-kit:setup-project`). Dev theme ID is set.
- The link is a page-level frame. Mobile frame link given or explicitly "none".
- Create the branch `feature/page-[name]`.

## Phase 1: PLAN (then STOP and wait for my approval)
1. Read the page frame with `get_metadata` (layer tree) and a screenshot. Do NOT fetch full design context for every child yet.
2. Split into sections (top-level children, in visual order). Classify each: header/footer (section groups), reuse existing section, adapt existing section, or new `custom-*` section.
3. For each section list: name, Figma node-id, reuse/adapt/new, settings and blocks expected, JS needed, risk (animation, tabs, sliders, forms, product data).
4. List global tokens found (colors, type styles, spacing, radius) versus what the theme already has, and the gaps.
5. List design gaps: missing mobile, states, fonts, overlays, content needing data (products, collections, blog, forms).
6. Write the plan to `docs/page-plan-[name].md` using `templates/page-plan.md` format. Show a short summary and ask me to approve or edit. **Do not write theme code before approval.**

## Phase 2: global tokens (once)
- Map Figma variables and styles to existing theme CSS variables and `config/settings_schema.json`. Add only the missing tokens, with sensible schema settings (colors, fonts, radius, spacing). Self-host fonts in `/assets` or use theme font pickers; do not use Google Fonts links.
- Verify with `shopify theme check`. Commit: `chore: design tokens for [page]`.

## Phase 3: build sections (sequential, one at a time, in page order)
For each section in the approved plan, run the same procedure as `/shopify-team-kit:figma-to-section` (design context for that node only, screenshot, assets, Liquid, schema, quality rules), plus:
- LCP: only the first visible image on the page is `eager` + `fetchpriority="high"`; all later images are lazy. Use `section.index` where the section may be reordered.
- Exactly one `h1` on the page (usually the hero or page title section); other sections use `h2` and below, set by context, not by visual size.
- After each section: `shopify theme check`, `node scripts/quick-audit.mjs . --changed`, fix High and Medium, then commit `feat: [section name]`. If a section fails the gate twice, stop and ask me.
- Report progress in one line per section: `done | name | files | open gaps`.

## Phase 4: assemble the page
- Create `templates/[name].json` (or `templates/page.[name].json`) with `sections` and `order` matching the Figma order. Fill settings and blocks with the Figma content as defaults. Image settings stay empty unless an asset is available; list which images the merchant must upload.
- Header and footer: use or update the section groups (`sections/header-group.json`, `sections/footer-group.json`) only if the plan says so.
- Note: the project `.shopifyignore` blocks `templates/*.json` and `sections/*.json` from pushes. If that stops the new template, tell me which line to remove for this push; do not remove it silently.
- Push to the DEV theme only: `shopify theme push --theme [DEV_THEME_ID]`.

## Phase 5: page-level quality gate
Use the `shopify-quality-gate` skill (profile from `CLAUDE.md`): fix everything automatically, and ask only for real blockers in one batched message. Add the page-level checks below.
1. `shopify theme check` and `node scripts/quick-audit.mjs .` (fix High and Medium).
2. Run the `shopify-code-reviewer` agent on `git diff main...HEAD`.
3. Page-level checks: one `h1`, heading order across sections, landmark structure, unique `id`s, skip link target, title and meta description for this template, canonical, JSON-LD present once, LCP element identified, total new JS/CSS size, number of new stylesheets.
4. Visual comparison:
   - If a browser tool is available (Claude in Chrome or a Playwright MCP): open the dev preview URL, take screenshots at 1440 px and 390 px, compare each section against the Figma screenshots, list differences with values (spacing, size, color, radius).
   - Otherwise give me the exact preview URL and the section-by-section comparison checklist.
   Fix differences you can fix; list the rest.

## Phase 6: fidelity report (final output)
Write `docs/page-report-[name].md` using `templates/page-report.md` and show a one-screen summary:
- Sections built, reused, adapted; files created or changed; commits.
- Quality gate results (theme check, audit counts, reviewer verdict).
- Fidelity: matches, known deviations with reasons.
- Needs my input (batched, each with a recommended default): images to upload, content to confirm, design gaps, data-dependent behavior (products, forms, filters), decisions needed. Anything fixable is already fixed.
Never say the page is "pixel perfect", "compliant" or "production ready". State what was verified and how.
