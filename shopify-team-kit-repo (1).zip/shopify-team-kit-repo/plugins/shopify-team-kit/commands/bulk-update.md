---
description: "Write and run a safe Shopify Admin GraphQL bulk update with dry-run first."
argument-hint: "[what to change] [which products/collections match]"
allowed-tools: Read, Write, Edit, Bash(node scripts/bulk/:*), Bash(git status:*)
---

Bulk change: $ARGUMENTS

1. Confirm scope in one message: store, target resource, exact filter, fields changed, expected count. Work only on a development store or after I confirm the production store explicitly.
2. Write a script (Node, in `scripts/bulk/`) using the Admin GraphQL API with: pagination, rate-limit/throttle handling (read `extensions.cost`), retry with backoff, user errors logged, and a `--dry-run` that is the DEFAULT and only logs planned changes (before/after values) to a CSV.
3. Validate GraphQL against the Shopify schema if the Shopify AI Toolkit plugin is installed; otherwise state that validation was not run.
4. Run the dry-run, show me the count and 10 sample diffs, and wait. Apply only after I say "apply". Write a backup CSV of the original values first so the change can be reverted.
5. Never put tokens in code or in chat; read from environment variables.
