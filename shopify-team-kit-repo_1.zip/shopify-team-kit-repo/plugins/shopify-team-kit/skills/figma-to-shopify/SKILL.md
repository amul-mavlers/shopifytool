---
name: figma-to-shopify
description: This skill should be used when the user shares a Figma link or node-id, or says "build this design", "implement this frame", "match the Figma", "design to code" or "convert this mockup" into a Shopify section, block or snippet. Provides the Figma MCP workflow that produces editable, standards-compliant Online Store 2.0 sections.
---

# Figma to Shopify section

Goal: a frame becomes a working, merchant-editable OS 2.0 section that matches the design, reuses the theme, and passes the accessibility, performance and SEO rules.

The Figma MCP returns design context (typically React + Tailwind) plus asset links. That output is a **reference, not code to paste**. Convert it into Liquid, theme CSS and schema.

Tool names below are the ones the official Figma MCP exposes today; run `/mcp` to confirm names in your version.

For a full page (several sections), use `/figma-to-page` and read `references/page-orchestration.md`; this file covers one section.

## Preconditions

1. Figma MCP connected and authenticated (`/mcp` shows figma connected). If not: `claude mcp add --transport http figma https://mcp.figma.com/mcp`, then `/mcp` and sign in. Restart Claude Code if tools do not appear.
2. A link to one frame or component (right-click, Copy link to selection). One frame per request. Desktop and mobile frames sent separately.
3. Project `CLAUDE.md` read and the closest existing section found (see `shopify-theme-standards`).

## Workflow (in order, do not skip)

1. **Parse the link.** The `node-id` in the URL uses a hyphen (`1-2`); the tool needs a colon (`1:2`). Confirm the intended node is selected: the frame itself, not a nested element.
2. **Get design context** for the node (`get_design_context`). If the response is truncated or too large, call `get_metadata` to see the layer tree and re-query the specific child nodes. If a section is split across unrelated frames, fetch each frame and merge.
3. **Get a screenshot** of the node (`get_screenshot`). This is the visual truth for comparison later.
4. **Get variables and tokens** (`get_variable_defs`). Map Figma colors, type styles and spacing to the theme's existing CSS variables and `settings_schema.json` tokens. Do not hardcode hex values or font sizes when a token exists. Flag tokens present in Figma but missing in the theme instead of inventing them.
5. **Extract assets** (images, icons, SVG) from the asset links. Real assets, never placeholders. Images become `image_picker` settings with sensible defaults; icons reuse the theme's icon snippet where one exists; decorative SVGs inline.
6. **Plan in 3 to 5 lines**: section name, settings, blocks, reused snippets, JS needed. Then build.
7. **Convert to Liquid**, following `shopify-theme-standards`:
   - Structure from the design; every text, image, link, color, alignment and spacing value a schema setting; repeated items are blocks with a `limit`.
   - Theme's existing classes, snippets, breakpoints and JS patterns first.
   - Tailwind utility output is translated to scoped CSS using theme variables. Do not add Tailwind.
   - Defaults in schema match the Figma content.
8. **Apply the quality skills while building**, not after:
   - Accessibility: semantic elements, heading level matches page context (not the design's visual size), alt text settings, labels, focus styles, 44 px targets, contrast of the design's color pairs (report to the designer if the design itself fails 4.5:1 or 3:1).
   - Performance: first image of the first section eager with `fetchpriority="high"`; others lazy; `image_tag` with `sizes`; no background-image hero; no animation on the LCP image.
   - SEO: heading hierarchy, one `h1` per page (usually in the main template, not in a promo section), real text not text-in-image.
9. **Verify visually.** Run `shopify theme dev`, open the section in the Theme Editor, compare with the screenshot at the design's desktop and mobile widths. Compare spacing, type, color, radius, shadow. Give differences as specific values, for example "heading to text gap 24 px, design 32 px".
10. **Quality gate.** `shopify theme check`, `scripts/quick-audit.sh`, then the `shopify-code-reviewer` agent. Fix High and Medium.
11. **Hand-off summary**: files created or changed, settings the merchant must configure, assets used, any design gaps (missing states, missing mobile frame, contrast failures).

## Design gaps to ask about (once, in one message)

- Missing hover, focus, error, empty, loading or long-text states.
- No mobile or tablet frame.
- Fonts not available in the theme or not licensed for web.
- Text over images without a defined overlay (contrast risk).
- Interactions or animations not specified.

## Do not

- Do not edit original theme files when ownership mode is `third-party`; create `custom-*` files.
- Do not paste the MCP's React/Tailwind output into the theme.
- Do not guess values the design shows; read them from the MCP. Do not guess values it does not show; ask.
- Do not use placeholder images when real assets are available.
- Do not build the entire page from one giant frame; split by section.
