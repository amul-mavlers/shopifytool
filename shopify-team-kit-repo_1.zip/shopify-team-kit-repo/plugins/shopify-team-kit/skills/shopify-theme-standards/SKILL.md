---
name: shopify-theme-standards
description: This skill should be used when the user creates, edits, refactors, debugs or reviews Shopify theme code (Liquid, sections, blocks, snippets, schema, CSS, JavaScript), mentions Dawn, the theme editor, shopify theme dev or push, or asks to "add a section", "fix the theme", "edit Liquid" or "update the snippet". Provides the team coding, structure, cart and Git standards for Online Store 2.0 themes.
---

# Shopify theme standards

Apply these rules to every theme change. The accessibility, performance and SEO rules live in their own skills; load them whenever the change touches markup, images, scripts or page metadata:

- `shopify-ada-wcag`: WCAG 2.2 AA
- `shopify-performance`: Core Web Vitals and Liquid speed
- `shopify-seo`: metadata, structured data, headings

## 0. Before writing code (token-efficient)

1. Read the project `CLAUDE.md` first. It states the theme ownership mode, base theme, store, dev theme ID and breakpoints.
2. `ls sections/ snippets/ blocks/` and find the closest existing component. Copy and adapt it instead of building from scratch.
3. Read `config/settings_schema.json` (global design tokens) and the theme's main CSS to learn class naming, spacing scale and breakpoints.
4. Do not re-read files already read in this session. State a 3 to 5 line plan, then write code. Output code and a short change summary, not essays.

## 1. Ownership mode (from project CLAUDE.md)

- `third-party` (purchased or marketplace theme): never edit original theme files. Put new work in `sections/custom-[name].liquid`, `snippets/custom-[name].liquid`, `assets/custom-[name].css|js`. Only touch an original file when the task cannot be done otherwise, and say so.
- `owned` (our own or fully forked theme): edit in place, keep the diff small and focused.

If the mode is not stated, ask once and propose adding it to CLAUDE.md.

## 2. Structure

- Keep the standard folders: `assets/ blocks/ config/ layout/ locales/ sections/ snippets/ templates/`. Do not invent new top-level folders.
- JSON templates only (Online Store 2.0). No new `.liquid` templates unless supporting a legacy theme.
- Keep `layout/theme.liquid` lean: load assets through snippets, no large inline scripts.

## 3. Liquid

- `{% render %}` only. Never `{% include %}` (deprecated, leaks scope).
- No business logic in templates: move conditionals and loops into named snippets. Max 3 nesting levels.
- Use `{% liquid %}` for multi-line logic blocks; use `{%- -%}` where whitespace matters.
- Always guard output: `{% if section.settings.heading != blank %}`. Provide defaults with `| default:`.
- Escape anything merchant- or customer-controlled (`| escape`, `| strip_html`). Use `| json` when emitting into JS or JSON-LD.
- Cache repeated filter results and `block.settings` in a variable with `assign` before use.
- Themes can only read metafields. Never write them from Liquid or client JS. Access them with static keys (`product.metafields.custom.tagline`), never dynamic keys, and document every namespace/key in `README.md`.
- All customer-facing strings use `{{ 'key' | t }}` with keys in `locales/`. No hardcoded English, even for single-locale stores.

## 4. Sections, blocks and schema

- Every merchant-editable area is a section or a block. Nothing merchant-facing is hardcoded: text, images, links, colors, spacing all come from schema settings.
- Each section schema has `name`, `settings`, `blocks` (with `limit`), and `presets` so it shows in "Add section". Include `{ "type": "@app" }` in blocks for app compatibility.
- Padding top/bottom: `range` setting (0 to 100, step 4). Use schema `default` values that match the design.
- Sections must re-render in isolation (Section Rendering API) and survive add, remove and reorder in the Theme Editor.
- Handle Theme Editor events in JS: `shopify:section:load`, `shopify:section:unload`, `shopify:block:select`.
- Handle empty states: no image, no collection, no products, no variants, very long text.
- Put a comment at the top of each section: purpose and any non-obvious setting.

Section skeleton:

```liquid
{% comment %} Section: custom-[name]. Purpose: [one line] {% endcomment %}

{% stylesheet %}
  .custom-[name] { /* scoped styles, theme CSS variables only */ }
{% endstylesheet %}

{%- style -%}
  #shopify-section-{{ section.id }} .custom-[name] {
    padding-block-start: {{ section.settings.padding_top }}px;
    padding-block-end: {{ section.settings.padding_bottom }}px;
  }
{%- endstyle -%}

<div class="custom-[name]">
  {%- if section.settings.heading != blank -%}
    <h2 class="custom-[name]__heading">{{ section.settings.heading | escape }}</h2>
  {%- endif -%}
</div>

{% schema %}
{
  "name": "Section name",
  "settings": [],
  "blocks": [{ "type": "@app" }],
  "presets": [{ "name": "Section name" }]
}
{% endschema %}
```

## 5. CSS

- CSS custom properties for all tokens (color, spacing, type, radius). Global settings in `config/settings_schema.json`, exposed as variables in `layout/theme.liquid`.
- Mobile first. Use the theme's existing breakpoints, never arbitrary ones.
- No `!important`, no inline styles (except dynamic CSS variables through `{% style %}`), no broad tag selectors. Scope with section ID or BEM-like classes.
- Animate `transform` and `opacity` only.

## 6. JavaScript

- Vanilla JS and custom elements (the Dawn pattern). No jQuery. No React/Vue/Alpine without approval.
- Reuse the theme's existing JS patterns (sliders, modals, drawers) before adding anything.
- `addEventListener` only, no inline `onclick`. Namespace globals and custom events with a project prefix.
- Wrap every `fetch` and Cart API call in try/catch with a visible, announced fallback message (see accessibility skill).
- Cart: use the Cart API (`/cart/add.js`, `/cart/change.js`, `/cart/update.js`) or the Section Rendering API; update UI optimistically and roll back on error. Dispatch the theme's cart events after mutations.
- Never redirect to `/checkout` from JS. Do not touch checkout or customer account files unless asked.

## 7. Shopify CLI and Git

- Develop with `shopify theme dev --store [store]`. Test on the real preview URL, not only localhost.
- Never push to the live theme: no `--live`, no `--allow-live`. Push only to the dev theme: `shopify theme push --theme [DEV_THEME_ID]`.
- Run `shopify theme check` before every commit. Fix errors; treat warnings in new code as errors.
- Keep `config/settings_data.json` out of Git on team projects unless the project CLAUDE.md defines a sync strategy (it holds live merchant customizations). Keep a `.shopifyignore` for files that must not overwrite the remote theme.
- Feature branches: `feature/`, `fix/`, `chore/`. Small commits in imperative mood. One PR per task. Never commit secrets or tokens.

## 8. Definition of done

A change is done only when all of these are true:

1. `shopify theme check` passes.
2. `scripts/quick-audit.sh` shows no High findings in changed files.
3. Works in the Theme Editor (add, remove, reorder, empty state).
4. Mobile and desktop verified, keyboard path verified.
5. The `shopify-code-reviewer` agent has reviewed the diff and High/Medium issues are fixed.
6. A short change summary lists the files changed and any settings the merchant must configure.
