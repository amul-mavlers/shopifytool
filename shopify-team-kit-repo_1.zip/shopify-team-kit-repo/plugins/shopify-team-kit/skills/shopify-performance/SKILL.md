---
name: shopify-performance
description: This skill should be used when the user mentions page speed, a slow store, Lighthouse, Core Web Vitals, LCP, CLS, INP, TTFB, lazy loading, render-blocking or third-party scripts, and whenever hero sections, product or collection templates, Liquid loops, images, scripts, fonts or layout/theme.liquid are written or reviewed. Provides Shopify theme performance rules and an audit method.
---

# Shopify theme performance

Source of truth: Shopify "Performance best practices for Shopify themes" (shopify.dev). Rules below are condensed from it, with team targets added.

## Targets

- Core Web Vitals "good" (Google): **LCP at or under 2.5 s, INP at or under 200 ms, CLS at or under 0.1**, measured on mobile with real-user data where available.
- Lighthouse mobile performance **80 or higher** on home, collection and product (team target). Shopify Theme Store minimum is 60, so 80 gives headroom.
- Measure before and after every performance change. Use field data (Shopify Web Performance Dashboard, CrUX) as the signal and lab tests (Lighthouse, WebPageTest medians) to validate fixes. Never claim a speed-up without a before/after number.

Full recommendation tables with impact ratings: `references/shopify-performance-rules.md`.

## Essential rules (check these first)

1. **Never lazy-load the LCP image.** `loading="lazy"` only for images outside the initial viewport. Above the fold: `loading="eager"`.
2. **`fetchpriority="high"` on the LCP image** (usually the first hero or the first product image).
3. **Do not hide the LCP image behind animations** (fade-ins, reveal effects).
4. **No CSS `background-image` for hero/LCP content.** Use `<img>` so the preload scanner finds it. Use `<picture>` for separate mobile and desktop art.
5. **Render essential content in Liquid and HTML, not JavaScript** (product info, hero, nav). Client-rendered content delays LCP and hurts SEO.
6. **No deeply nested Liquid loops.** Nested loops across products, variants or options are quadratic and are the most common cause of high TTFB.
7. **Put first-paint resources (base stylesheet, font preloads, import map) above `{{ content_for_header }}`** so they download while Shopify renders sections. Check inline `Shopify.*` scripts and cascade order before moving anything.
8. **Use `preload` for at most 1 or 2 late-discovered resources.** Overuse slows pages.

## Liquid (TTFB)

- Use `image_url` + `image_tag` (auto `srcset`, `width`, `height`, CDN). Never hand-built CDN URLs; never the deprecated `img_url`.
- Move metafield access and repeated `assign`/filter calls outside loops. Prefer theme settings over metafields for static data.
- Limit what loops fetch: `for ... limit:` on `collection.products`; use `paginate` for other arrays; keep pagination depth under 25,000 objects.
- Do not iterate `product.variants` where the first variant or `options_with_values` is enough (variant over-fetching). Defer combined-listing children through the Section Rendering API.
- Flatten nested `render` calls, especially inside loops. Filter collections before looping.
- Guard expensive Liquid in drawers and dialogs so it loads only when opened. Use `section.index` to load above-the-fold and below-the-fold sections differently.
- Update UI with the Section Rendering API instead of full reloads. Use `echo` or `{{ }}` for concatenation instead of `append`/`prepend` chains. Assign `block.settings` to a variable.

## Images (LCP, CLS)

- Always `width` and `height` (or `image_tag`) to prevent layout shift.
- `srcset` and `sizes` that match the real layout width, not the viewport.
- Dialogs and popups must not become the LCP element: keep them small or delay them.

## JavaScript (INP, LCP)

- `defer` on non-critical scripts; `async` only for independent third-party scripts. No `document.write`.
- Load modules on interaction with dynamic `import()` inside event listeners. Use import maps; Shopify already includes `es-module-shims`, do not add your own copy.
- Build DOM for closed drawers, filters and dialogs only when first opened.
- Debounce and throttle scroll, resize, input handlers; use passive listeners.
- Audit every script: apps, pixels, theme code. Remove what does not earn its cost. Remove A/B anti-flicker snippets when no test is running. Remove or defer render-blocking app scripts.
- No heavy frameworks where Liquid and CSS do the job.

## CSS and fonts (FCP, CLS, INP)

- Reduce stylesheet count (each extra `<link>` adds a style recalculation). Load critical CSS synchronously; use the async pattern only for below-the-fold sections.
- Shopify subsets CSS from `{% stylesheet %}` tags per page: keep each file's classes used only in that file or the files it renders.
- Fonts: system fonts when the design allows; otherwise self-host on Shopify CDN (upload to `/assets`), not Google Fonts. Reduce CLS from swaps with fallback `size-adjust` and metric overrides.
- Animate `transform` and `opacity` only. One responsive menu, not duplicated desktop and mobile menus. Reserve space (`min-height`) for app-injected content.

## Resource hints and CDN

- Serve assets from the Shopify CDN (`/assets`). No reverse proxies in front of the storefront.
- `preconnect` only to critical third-party origins. Consider the Speculation Rules API for fast navigation.

## Mobile

- Test with CPU and network throttling on real or emulated mid-range devices.
- No intrusive full-screen interstitials on load (hurts rankings and LCP).
- Primary tap targets at least 44 to 48 px. No horizontal scroll. Content parity between mobile and desktop.

## Audit method

1. Static scan: `bash scripts/quick-audit.sh [theme-dir]` (P-rules).
2. `shopify theme check` (flags large bundles, remote assets, parser-blocking scripts).
3. Shopify Theme Inspector (Chrome) to find the slowest Liquid lines.
4. Lighthouse (mobile) on home, collection, product; compare with the Web Performance Dashboard.
5. Debug by metric gap: slow TTFB means Liquid; fast TTFB but slow LCP means image, CSS or JS.
6. Beware "fake performance apps" that game Lighthouse. Do not install them.

Report findings as: `Issue | File:line | Metric | Impact | Fix`. Fix the top 3 by impact first, re-measure, then continue.
