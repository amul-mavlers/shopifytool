---
name: shopify-ada-wcag
description: This skill should be used when the user mentions ADA, WCAG, accessibility, a11y, screen readers, keyboard navigation, contrast, focus, alt text, ARIA or an accessibility audit or lawsuit, and whenever theme markup, forms, menus, drawers, modals, sliders, product or cart UI is written or reviewed. Provides WCAG 2.2 AA build rules and an audit method for Shopify themes.
---

# Shopify accessibility (WCAG 2.2 AA)

Target: **WCAG 2.2 Level AA**. It is a superset of 2.1 AA, which most laws and settlements cite (ADA, EN 301 549 / EAA, Section 508). AAA is not required.

Fixes must be made in theme code or content. Never recommend an accessibility overlay widget as a fix.

Full criterion to Shopify mapping: `references/wcag-shopify-map.md`. Read it when auditing or when a rule below needs the exact criterion.

## Build rules (apply to every markup change)

**Page structure**
- `<html lang="{{ request.locale.iso_code }}">`. Viewport must allow zoom: never `maximum-scale` or `user-scalable=no`.
- Skip link first in `<body>`, visible on focus, targeting `<main id="MainContent" tabindex="-1">`.
- Landmarks: `<header> <nav> <main> <footer>`. One `<h1>` per page. Headings follow content order, never styling order. No skipped levels.
- No `tabindex` above 0. No `autofocus`.

**Images and media**
- Meaningful images: real `alt` (from image alt, a schema setting, or a fallback). Decorative: `alt=""`. Icon-only buttons and links: accessible name via visually hidden text or `aria-label`.
- No autoplay. If autoplay is unavoidable, muted and pausable. Video needs captions; audio needs a transcript.
- Slideshows: pause/stop control and next/previous buttons. No drag-only interaction (WCAG 2.5.7): always provide buttons.

**Color and contrast**
- Text under 24px regular (18.5px bold): 4.5:1. Large text: 3:1. Icons, input borders, focus rings, meaningful graphics: 3:1 (1.4.11).
- Check every state: hover, focus, active, disabled, placeholder. Never use color alone to convey meaning (sale price, errors, selected swatch).

**Keyboard and focus**
- Everything works with Tab, Shift+Tab, Enter, Space, Esc. No hover-only content. Focus order = DOM order.
- Never `outline: none` without a replacement. Use a visible `:focus-visible` style with 3:1 contrast.
- Focus must not be hidden behind sticky headers, cookie banners or chat widgets (2.4.11). Use `scroll-padding-top` equal to sticky header height.

**Touch targets**
- Primary controls (menu links, add to cart, search, cart, hamburger, modal close, variant and quantity controls): at least 44x44 px (Shopify theme requirement; 48 px preferred on mobile). Never below 24x24 px (WCAG 2.5.8 minimum).

**Navigation and menus**
- Wrap in `<nav>`; `aria-current="page"` on the current link. Do not use `role="menu"` or `role="menuitem"` for site navigation.
- Dropdowns: a `<button>` with `aria-expanded` and `aria-controls`. Enter/Space opens, Tab moves into the panel, Esc closes and returns focus to the button.

**Drawers and modals (cart, quick view, filters, search)**
- Prefer `<dialog>` or `role="dialog"` with `aria-labelledby`. On open, move focus inside; trap focus; Esc closes; on close, return focus to the trigger. Background content inert.

**Forms**
- Every input has a real `<label for>`; placeholder is not a label. `required` on required fields, `autocomplete` on known fields (name, email, address, tel).
- Errors: text (not color alone), `aria-describedby` pointing at the error text, focus moved to the first error or an error summary, suggestion on how to fix (3.3.1, 3.3.3).
- Do not force re-entry of data already given (3.3.7). Login or any gate must not rely on a cognitive test only (3.3.8): allow password managers or email links, provide an alternative to image CAPTCHAs.

**Dynamic updates (status messages, 4.1.3)**
- Use `aria-live="polite"` (or `role="status"`) for: added to cart, cart count, variant price and availability changes, filter result counts, form success. `role="alert"` only for urgent errors.

**Product and cart specifics**
- Sale vs regular price: distinguish with visually hidden text, not only strikethrough or color.
- Variant pickers: fieldset + legend per option; selected state exposed via native radio/`aria-checked`, not color only.
- Links that open a new window warn the user (icon with text alternative). Link text is meaningful out of context.
- Data tables: `<caption>`, `<th scope="col|row">`.

**Layout**
- Content reflows at 320 CSS px without horizontal scroll (1.4.10). Text resizes to 200% without clipping (1.4.4). Survives increased text spacing (1.4.12). Hover/focus popovers are dismissible, hoverable, persistent (1.4.13).
- Help or contact link in a consistent place across pages (3.2.6). Same label for same function (3.2.4).

## Audit method

Automated tools catch only about 30 to 40% of issues. Always do all three layers:

1. **Static scan**: `bash scripts/quick-audit.sh [theme-dir]` (A-rules). Fix every High.
2. **Tooling on key templates** (home, collection, product, cart, one content page, search): axe DevTools, WAVE or Lighthouse accessibility.
3. **Manual**: keyboard-only pass from home to cart; screen reader pass (VoiceOver or NVDA) on product page and cart; zoom to 200%; reflow at 320 px; check focus not obscured.

Report findings as a table: `Criterion | Level | File:line | Issue | Severity | Fix`. Severity: High = blocks a task or fails an audit alone (no keyboard access, missing labels, contrast fail on body text, focus trap, no alt on product images); Medium = degrades use; Low = polish.

## Do not

- Do not claim "compliant" or "WCAG conformant". Say which criteria were checked and how. Legal compliance is a client and counsel decision.
- Do not add overlay or "accessibility widget" apps.
