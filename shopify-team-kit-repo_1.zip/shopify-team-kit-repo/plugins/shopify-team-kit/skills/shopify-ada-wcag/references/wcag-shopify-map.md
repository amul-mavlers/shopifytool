# WCAG 2.2 AA: where each criterion breaks in a Shopify theme

Sources: W3C WCAG 2.2; Shopify "Accessibility best practices for Shopify themes" (shopify.dev); Fudge WCAG 2.2 AA checklist for Shopify. Level A and AA only. WCAG 2.2 added 6 A/AA criteria (marked NEW) and removed 4.1.1 Parsing.

## Contents
1. Perceivable
2. Operable
3. Understandable
4. Robust
5. Test flow per template

## 1. Perceivable

| SC | Lvl | Where it breaks | Fix in theme |
|---|---|---|---|
| 1.1.1 Non-text Content | A | Missing alt on product/section images; icon buttons without a name | `alt` from image or schema setting; `alt=""` if decorative; visually hidden text for icon controls |
| 1.2.2 / 1.2.5 Captions, audio description | A / AA | Product videos, lifestyle reels | Captions; audio description or text alternative |
| 1.3.5 Identify Input Purpose | AA | Account, checkout-adjacent, newsletter fields | `autocomplete` tokens (name, email, tel, street-address, postal-code) |
| 1.4.1 Use of Color | A | Sale price or error shown by color only | Add text, icon, underline, visually hidden text |
| 1.4.3 Contrast (Minimum) | AA | Brand colors on body text, buttons, placeholders | 4.5:1 normal, 3:1 large; fix tokens in settings |
| 1.4.4 Resize Text | AA | Fixed pixel heights clipping text | `min-height`, relative units |
| 1.4.10 Reflow | AA | Sticky headers, wide tables, multi-column at 320px | Single column at 320 CSS px, tables in overflow container |
| 1.4.11 Non-text Contrast | AA | Light input borders, outline buttons, weak focus ring | 3:1 for UI components and graphics |
| 1.4.12 Text Spacing | AA | Containers that clip with larger spacing | No fixed heights on text containers |
| 1.4.13 Content on Hover or Focus | AA | Mega-menus, tooltips, size-guide popovers | Dismissible (Esc), hoverable, persistent |

## 2. Operable

| SC | Lvl | Where it breaks | Fix in theme |
|---|---|---|---|
| 2.1.1 Keyboard | A | Mega-menus, cart drawer, quick view, galleries built in JS | Native buttons/links; key handlers for custom widgets |
| 2.1.2 No Keyboard Trap | A | Modals that cannot be exited | Esc closes; focus returns to trigger |
| 2.4.1 Bypass Blocks | A | Skip link removed in customized themes | Skip link to `main` with `tabindex="-1"` |
| 2.4.3 Focus Order | A | Positive tabindex, DOM order differs from visual | DOM order = visual order |
| 2.4.7 Focus Visible | AA | Global `outline: none` | Visible `:focus-visible` style |
| 2.4.11 Focus Not Obscured (Min) NEW | AA | Sticky header, cookie banner, chat widget cover focus | `scroll-padding`, z-index review, banner placement |
| 2.5.3 Label in Name | A | Visible "Add to cart" vs different `aria-label` | Accessible name contains visible text |
| 2.5.7 Dragging Movements NEW | AA | Drag-only sliders, "slide to confirm" | Add buttons or tap alternative |
| 2.5.8 Target Size (Minimum) NEW | AA | Steppers, swatches, footer icons, close buttons | At least 24x24 CSS px (team standard 44x44 on primary controls) |

## 3. Understandable

| SC | Lvl | Where it breaks | Fix in theme |
|---|---|---|---|
| 3.1.1 Language of Page | A | Missing or wrong `lang` | `lang="{{ request.locale.iso_code }}"` |
| 3.1.2 Language of Parts | AA | Multi-locale content snippets | `lang` on foreign-language passages |
| 3.2.3 / 3.2.4 Consistent Navigation / Identification | AA | Cart called "Cart" on one template, "Bag" on another | Same placement and naming everywhere |
| 3.2.6 Consistent Help NEW | A | Contact or chat link moves between pages | Same location on every page |
| 3.3.1 / 3.3.3 Error Identification / Suggestion | A / AA | Red border only; no guidance | Text error + suggestion; `aria-describedby` |
| 3.3.2 Labels or Instructions | A | Newsletter, search, contact, quantity, variant fields | Real `<label>`; placeholder is not a label |
| 3.3.7 Redundant Entry NEW | A | Re-typing shipping as billing | "Same as" option; do not ask twice |
| 3.3.8 Accessible Authentication (Min) NEW | AA | CAPTCHA-only login | Magic link, password manager support, non-cognitive alternative |

## 4. Robust

| SC | Lvl | Where it breaks | Fix in theme |
|---|---|---|---|
| 4.1.2 Name, Role, Value | A | `<div>` buttons, accordions without state | Native elements; `aria-expanded`, `aria-controls`, `aria-checked` |
| 4.1.3 Status Messages | AA | "Added to cart", "Only 2 left", price change not announced | `aria-live="polite"` / `role="status"` |

4.1.1 Parsing is obsolete in WCAG 2.2: do not test against it (duplicate IDs can still break 4.1.2).

## 5. Test flow per template

Templates: home, collection (with filters), product (with variants), cart (drawer and page), search (predictive), a content page, account/login.

1. Run `scripts/quick-audit.sh`.
2. axe DevTools or WAVE or Lighthouse accessibility on each template.
3. Keyboard only: Tab through, open and close every menu, drawer and modal, add to cart, reach checkout link.
4. Screen reader (VoiceOver macOS/iOS or NVDA Windows): product page, add to cart announcement, cart drawer.
5. Zoom 200%, then viewport 320 px: no clipped or overlapping content, no horizontal scroll.
6. Touch: tap targets on mobile, no drag-only controls.
