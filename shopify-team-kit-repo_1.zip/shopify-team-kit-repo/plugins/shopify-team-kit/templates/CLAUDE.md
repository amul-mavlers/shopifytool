# Project: [Client / Store name]

> Short on purpose. The detailed rules live in the Shopify Team Kit skills
> (shopify-theme-standards, shopify-ada-wcag, shopify-performance, shopify-seo, figma-to-shopify)
> and load automatically. Only project-specific facts go here.

## Project facts (fill in)
- Store: [store].myshopify.com
- Quality profile: [standard | strict]   <!-- strict: audit fails on Medium, reviewer must say OK TO MERGE, Lighthouse target 90 -->
- Theme ownership: [owned | third-party]   <!-- third-party = never edit original theme files; use custom-* files -->
- Base theme: [Dawn x.y | name + version]
- Dev theme ID: [ID]    <!-- all pushes go here, never the live theme -->
- Breakpoints (from theme CSS): [e.g. 750px, 990px]
- Markets / languages: [e.g. US en, UK en]
- Apps in use (script-injecting): [list, or none]
- Design source: [Figma file link]

## Commands
- Preview: `shopify theme dev --store [store].myshopify.com`
- Lint: `shopify theme check`
- Static audit: `bash scripts/quick-audit.sh .`  (or `--changed`)
- Push to dev theme: `shopify theme push --theme [DEV_THEME_ID]`

## Hard rules (always)
1. Never push to or edit the live theme (no `--live`, no `--allow-live`).
2. Do not touch checkout or customer account files unless asked.
3. Do not delete existing sections, snippets or settings without asking.
4. No new apps, libraries or third-party scripts without approval.
5. Every merchant-facing value is a schema setting, block or locale key.
6. Targets: WCAG 2.2 AA, Core Web Vitals good (LCP <= 2.5 s, INP <= 200 ms, CLS <= 0.1), Lighthouse mobile >= 80.

## Workflow
1. Read this file, find the closest existing section, state a 3 to 5 line plan.
2. Build. 3. `shopify theme check` + quick-audit. 4. `/shopify-team-kit:review`.
5. Fix High and Medium. 6. Summarize files changed and settings to configure.

## Project-specific notes
<!-- Client rules, brand constraints, known issues, metafield namespaces/keys the theme reads, delivery rules (e.g. UK-only shipping) -->
-
