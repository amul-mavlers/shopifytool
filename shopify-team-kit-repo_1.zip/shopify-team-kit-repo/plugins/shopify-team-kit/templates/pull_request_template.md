## What changed
<!-- one or two lines; link the ticket -->

## Files and settings
- Files changed:
- Settings the merchant must configure:

## Checks (tick or explain)
- [ ] `shopify theme check` passes
- [ ] `quick-audit.sh --changed` has no High
- [ ] `/shopify-team-kit:review` run; High and Medium fixed
- [ ] Theme Editor: add, remove, reorder, empty state
- [ ] Mobile + desktop checked against design
- [ ] Keyboard path checked (Tab, Esc, focus visible)
- [ ] Lighthouse mobile before / after: __ / __ (if perf-related)
- [ ] Tested on dev theme, not live

## Not verified
<!-- screen reader, specific browsers, etc. -->
