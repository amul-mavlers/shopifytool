---
description: "One-time project setup. Detects the theme, creates CLAUDE.md, .shopifyignore, .gitignore entries and runs a baseline audit."
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(git --version:*), Bash(node --version:*), Bash(shopify version:*), Bash(find:*), Bash(mkdir:*), Bash(cp:*), Bash(chmod:*), Bash(bash scripts/quick-audit.sh:*), Bash(python3 scripts/contrast-check.py:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(npm install:*), Bash(curl -sI:*)
---

Set up this Shopify theme repo for the Shopify Team Kit. Be quick and do not ask more than needed.

1. **Detect**: confirm this is a theme (`layout/theme.liquid`, `sections/`, `templates/`). If not, say so and stop. Note base theme (Dawn or other) from `config/settings_schema.json` theme_info or `README`.
2. **Tools**: check `git --version`, `node --version`, `shopify version`. Report missing ones with the install command; do not install anything globally without asking.
3. **Locate the kit files**: find the installed plugin folder (`find ~/.claude/plugins -type d -name shopify-team-kit 2>/dev/null | head -1`; if nothing is found, ask me for the path to the kit). Call it KIT. Copy `KIT/scripts/quick-audit.sh` and `KIT/scripts/contrast-check.py` to `./scripts/` (create `scripts/`, do not overwrite a newer existing copy) and make it executable. All audit commands run it from there. Also create `./scripts/qa/`, copy `KIT/scripts/rendered-qa.mjs` there and `KIT/scripts/qa-package.json` as `scripts/qa/package.json`, run `npm install --no-audit --no-fund --prefix scripts/qa`, and make sure `scripts/qa/node_modules/` is in `.gitignore`.
4. **CLAUDE.md**:
   - If it exists, read it and list any missing sections versus `KIT/templates/CLAUDE.md`. Offer additions; do not overwrite.
   - If missing, copy the template and fill what you can detect. Ask ONE message for the rest: store handle, ownership mode (`owned` or `third-party`), dev theme ID, breakpoints (default from the theme CSS), languages/markets, any apps in use.
5. **Safety files**: create `.shopifyignore` from `KIT/templates/.shopifyignore` if missing. Check `.gitignore` for `config/settings_data.json`, `node_modules/`, `.env`, `.DS_Store`; add missing lines only after telling me which and why.
6. **Baseline**: run `bash scripts/quick-audit.sh .` and `shopify theme check` (if installed). Summarize counts by severity and the top 5 findings. Do not fix anything yet.
7. Offer the optional Stop hook (automatic enforcement): explain it in two lines, and only if I agree copy `KIT/scripts/stop-quality-gate.sh` to `./scripts/` and merge `KIT/templates/hooks/settings.hooks.json` into `.claude/settings.json` (merge, never overwrite existing hooks).
8. Offer the foundation: ask whether to run `/shopify-team-kit:foundation` now (global, SEO, accessibility, performance standards applied after an approved plan). Recommend yes for new projects.
9. Finish with a 5-line summary: what was created, what is missing, baseline counts, and the next command to run (`/shopify-team-kit:new-section` or `/shopify-team-kit:audit`).
