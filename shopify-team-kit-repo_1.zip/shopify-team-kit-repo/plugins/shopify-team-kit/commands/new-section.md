---
description: "Build a new theme section or block from a text description, following team standards, ADA, performance and SEO rules."
argument-hint: "[section name] [what it should show and how it behaves]"
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(bash scripts/quick-audit.sh:*), Bash(python3 scripts/contrast-check.py:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(npm install:*), Bash(curl -sI:*)
---

Build a new Shopify theme section: $ARGUMENTS

Use the skills `shopify-theme-standards`, `shopify-ada-wcag`, `shopify-performance`, `shopify-seo`.

1. Read `CLAUDE.md`. List `sections/` and `snippets/`, find the closest existing section, read it. State a 3 to 5 line plan (settings, blocks, reused snippets, JS needed). If a requirement is ambiguous, ask one batched question; otherwise proceed.
2. Create the section (`custom-` prefix when ownership is `third-party`). Everything merchant-facing is a setting or block; add `presets`, `limit`s and `@app`. Handle empty states. Use `t` keys for fixed strings and add them to `locales/en.default.json`.
3. Build accessibility in (semantic markup, heading level from context, alt settings, labels, focus, 44 px targets, live regions where content updates).
4. Build performance in (`image_tag` + `sizes`, eager + `fetchpriority="high"` only when this section is first on the page via `section.index`, otherwise lazy; no background-image hero; scripts deferred or loaded on interaction).
5. Run the quality gate (skill `shopify-quality-gate`) and fix everything it finds automatically; ask only for real blockers (its ask policy).
6. Output the Done report, plus: files created, how to add the section in the Theme Editor, settings the merchant should configure, and anything not verified (browser, screen reader).
