---
description: "Full pre-release pass: run every check and automatically fix what fails; ask only for real blockers."
argument-hint: "[optional path or template] [--report-only to change nothing]"
allowed-tools: Read, Write, Edit, Glob, Grep, Task, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(bash scripts/quick-audit.sh:*), Bash(python3 scripts/contrast-check.py:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(npm install:*), Bash(curl -sI:*)
---

Full pre-release audit and automatic fix of: $ARGUMENTS (default: whole theme). With `--report-only`, change nothing and just report.

Run the `shopify-quality-gate` skill on the whole target (not only changed files): theme check, `bash scripts/quick-audit.sh .`, contrast, rendered-page QA on home, a collection, a product, the cart and any changed page, and the `shopify-code-reviewer` agent. Then run the fix loop with the auto-fix playbook until the profile is clean or the rounds run out.

Output the Done report from the skill: counts before and after, what was auto-fixed, and a single batched "Needs your input" list with recommended defaults. No manual test lists.
