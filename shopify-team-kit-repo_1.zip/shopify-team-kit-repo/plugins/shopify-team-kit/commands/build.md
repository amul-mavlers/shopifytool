---
description: "Single entry point: build anything (text task, bug, Figma frame, Figma page) with the team standards and the full quality gate + QA plan in the same run."
argument-hint: "[what to build or fix | Figma frame link | Figma page link]"
allowed-tools: Read, Write, Edit, Glob, Grep, Task, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(git checkout:*), Bash(bash scripts/quick-audit.sh:*), Bash(python3 scripts/contrast-check.py:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(npm install:*), Bash(curl -sI:*)
---

Build, verify and fix automatically: $ARGUMENTS

Use `shopify-theme-standards`, `shopify-ada-wcag`, `shopify-performance`, `shopify-seo` while building, and `shopify-quality-gate` at the end. This one command replaces running build, review, QA and fixing separately: it ends with the work already fixed and verified.

## 1. Route
- Contains a figma.com link: read the node's layer tree (`get_metadata`). If it is a full page (several full-width child sections), follow `/shopify-team-kit:figma-to-page` (including its plan approval stop). If it is one section or component, follow `/shopify-team-kit:figma-to-section`.
- Describes a defect (bug, broken, not working, wrong, fix): follow `/shopify-team-kit:fix-bug`.
- Otherwise: follow `/shopify-team-kit:new-section` (or edit the named existing file).
- Ambiguous: ask one question, then continue.

## 2. Preconditions (do not block, just report)
- Read `CLAUDE.md` (profile, ownership, dev theme). If missing: tell me to run `/shopify-team-kit:setup-project`, then stop.
- If `assets/kit-base.css` or the skip link is missing: say the foundation is not applied (`/shopify-team-kit:foundation`) and continue only if I agree.
- Work on a feature branch; never the live theme.

## 3. Plan
3 to 5 lines: files, settings and blocks, reuse, JS, risks. For a Figma page the plan needs my approval before code (per figma-to-page). For anything else, continue unless the plan needs a decision from me.

## 4. Build
Follow the routed command's steps and the skills' rules. Keep diffs small; reuse existing sections and snippets.

## 5. Quality gate: resolve everything automatically (same run)
Run the `shopify-quality-gate` skill: theme check, static audit, rendered-page QA, contrast, reviewer, and the automatic fix loop using its auto-fix playbook. Fix what fails and re-verify; do not stop at the first green check and do not hand me a list of things to fix or test.
Ask me only when blocked by a dependency or a real decision (the skill's ask policy), all in ONE message at the end with a recommended default for each. Finish all unblocked work first.

## 6. Output
The Done report from the quality-gate skill (including "Needs your input"). Offer to commit.
