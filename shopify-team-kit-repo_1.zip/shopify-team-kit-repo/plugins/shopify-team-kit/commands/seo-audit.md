---
description: "Technical on-page SEO audit of the theme (metadata, canonical, JSON-LD, headings, alt, links) with fixes."
argument-hint: "[path, template, or live URL, default: whole theme] [--report-only to change nothing]"
allowed-tools: Read, Edit, Glob, Grep, WebFetch, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(bash scripts/quick-audit.sh:*), Bash(python3 scripts/contrast-check.py:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(npm install:*), Bash(curl -sI:*)
---

SEO audit of: $ARGUMENTS (default: whole theme)

Use the `shopify-seo` skill and `references/seo-snippets-and-checklist.md`.

1. Run `bash scripts/quick-audit.sh .` (S-rules).
2. Read `layout/theme.liquid` (or the meta snippet) and the product, collection, article and page templates. Check title, description, canonical, OG/Twitter, `lang`, one h1, heading order, JSON-LD (duplicates, hardcoded values), alt text, internal link targets, `noindex`, `robots.txt.liquid`.
3. If a live or preview URL is given, fetch it and check the rendered source for the same items.
4. Output the per-template table from the checklist with Pass/Fail and then a findings table: `Check | File:line or URL | Severity | Fix`.
5. Unless `--report-only`: fix findings using the auto-fix playbook, keeping to theme-level changes, then re-run steps 1 to 3 and report before/after counts. Ask only for real blockers (batched, with defaults). Do not promise rankings.
