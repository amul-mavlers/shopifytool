#!/usr/bin/env bash
# Optional regression test against real Shopify themes (needs git and network).
# Usage: bash tests/real-themes.sh [workdir]
# Clones Dawn, Horizon and Skeleton (Shopify's open-source themes) and asserts the audit stays quiet:
# no HIGH findings, MED findings under a ceiling, and a sane runtime. Detects false-positive regressions.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="${1:-$(mktemp -d)}"
fail=0
declare_theme() { # name repo max_med
  name="$1"; repo="$2"; maxmed="$3"
  if [ ! -d "$WORK/$name" ]; then
    git clone --depth 1 -q "https://github.com/Shopify/$repo.git" "$WORK/$name" 2>/dev/null || { echo "SKIP  $name (clone failed)"; return; }
  fi
  start=$(date +%s)
  out="$(bash "$ROOT/scripts/quick-audit.sh" "$WORK/$name" --no-fail | tail -1)"
  secs=$(( $(date +%s) - start ))
  high="$(printf '%s' "$out" | sed -E 's/.*HIGH=([0-9]+).*/\1/')"; med="$(printf '%s' "$out" | sed -E 's/.*MED=([0-9]+).*/\1/')"
  if [ "$high" -eq 0 ] && [ "$med" -le "$maxmed" ] && [ "$secs" -le 15 ]; then echo "PASS  $name  HIGH=$high MED=$med (max $maxmed)  ${secs}s"
  else echo "FAIL  $name  HIGH=$high MED=$med (max $maxmed)  ${secs}s"; fail=1; fi
}
declare_theme dawn dawn 4
declare_theme horizon horizon 6
declare_theme skeleton skeleton-theme 6
exit $fail
