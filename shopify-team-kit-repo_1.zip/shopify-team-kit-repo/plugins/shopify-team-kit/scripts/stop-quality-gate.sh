#!/usr/bin/env bash
# Opt-in Claude Code Stop hook: Claude cannot finish a turn while changed theme files fail the audit.
# Exit 2 = block (stderr is fed back to Claude, which keeps working); exit 0 = allow.
# Fails open on anything unexpected, and never blocks twice in a row (stop_hook_active), so it cannot loop.
# Claude Code itself also ends the turn after several consecutive blocks.
# Deliberately no `set -e`: any unexpected failure must fall through to exit 0 (fail open), never exit 1/2 by accident.
input="$(cat 2>/dev/null || true)"
printf '%s' "$input" | grep -Eq '"stop_hook_active"[[:space:]]*:[[:space:]]*true' && exit 0

cd "${CLAUDE_PROJECT_DIR:-.}" 2>/dev/null || exit 0
[ -f layout/theme.liquid ] || exit 0
git rev-parse --git-dir >/dev/null 2>&1 || exit 0

changed="$(git status --porcelain 2>/dev/null | sed 's/^...//; s/.* -> //' | grep -E '^(layout|sections|snippets|blocks|templates|assets|config|locales)/' || true)"
[ -n "$changed" ] || exit 0

AUDIT="scripts/quick-audit.sh"
[ -f "$AUDIT" ] || exit 0

failon="high"
grep -qiE 'quality profile:[^A-Za-z]*strict' CLAUDE.md 2>/dev/null && failon="med"

out="$(bash "$AUDIT" . --changed --fail-on "$failon" 2>&1)"; rc=$?
if [ "$rc" -eq 1 ]; then
  {
    echo "QUALITY GATE: changed theme files fail the static audit (profile fails on: $failon). Fix these before finishing:"
    printf '%s\n' "$out" | head -40
    echo "Then re-run: bash scripts/quick-audit.sh . --changed --fail-on $failon"
  } >&2
  exit 2
fi
exit 0
