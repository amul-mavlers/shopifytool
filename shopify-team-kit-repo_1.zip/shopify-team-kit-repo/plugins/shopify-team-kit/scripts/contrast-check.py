#!/usr/bin/env python3
"""contrast-check.py: WCAG contrast check for Shopify theme color schemes.

Usage: python3 contrast-check.py [theme-dir] [--min 4.5]
Reads config/settings_data.json (falls back to nothing if absent), finds every color scheme
(an object with "background" and "text" hex colors) and checks:
  text on background, button_label on button, secondary_button_label on background.
Only hex colors (#rgb, #rrggbb, #rrggbbaa) are checked; rgba()/gradients are reported as skipped.
Exit code 1 if any pair is below the minimum. This checks configured colors, not rendered pages
(overlays, images and opacity still need a manual check).
"""
import json, re, sys, os

def parse_json(path):
    raw = open(path, encoding="utf-8").read()
    raw = re.sub(r"/\*.*?\*/", "", raw, flags=re.S)  # Shopify adds a leading comment block
    return json.loads(raw)

HEX = re.compile(r"^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$")

def to_rgb(h):
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

def lum(rgb):
    def ch(c):
        c = c / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b

def ratio(a, b):
    la, lb = lum(to_rgb(a)), lum(to_rgb(b))
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)

def find_schemes(node, path="", out=None):
    out = [] if out is None else out
    if isinstance(node, dict):
        if isinstance(node.get("background"), str) and isinstance(node.get("text"), str):
            out.append((path, node))
        for k, v in node.items():
            find_schemes(v, f"{path}/{k}" if path else k, out)
    elif isinstance(node, list):
        for i, v in enumerate(node):
            find_schemes(v, f"{path}[{i}]", out)
    return out

def main():
    args = [a for a in sys.argv[1:]]
    minimum = 4.5
    if "--min" in args:
        i = args.index("--min"); minimum = float(args[i + 1]); del args[i:i + 2]
    root = args[0] if args else "."
    path = os.path.join(root, "config", "settings_data.json")
    if not os.path.exists(path):
        print(f"No {path}: nothing to check (it may be git-ignored; pull the theme first).")
        return 0
    try:
        data = parse_json(path)
    except Exception as e:
        print(f"Cannot parse {path}: {e}")
        return 2
    schemes = find_schemes(data)
    if not schemes:
        print("No color schemes found in settings_data.json.")
        return 0
    pairs = [("text", "background"), ("button_label", "button"), ("secondary_button_label", "background")]
    fails = checked = skipped = 0
    print(f"Minimum ratio: {minimum}:1 (normal text, WCAG 1.4.3)")
    print("RESULT | scheme | foreground on background | ratio")
    for spath, s in schemes:
        parts = [x for x in spath.split("/") if x != "settings"]
        name = parts[-1] if parts else spath
        for fg_key, bg_key in pairs:
            fg, bg = s.get(fg_key), s.get(bg_key)
            if not isinstance(fg, str) or not isinstance(bg, str):
                continue
            if not (HEX.match(fg) and HEX.match(bg)):
                skipped += 1
                continue
            r = ratio(fg, bg)
            checked += 1
            ok = r >= minimum
            fails += 0 if ok else 1
            print(f"{'PASS' if ok else 'FAIL'} | {name} | {fg_key} {fg} on {bg_key} {bg} | {r:.2f}")
    print(f"\nChecked {checked} pairs in {len(schemes)} schemes; {fails} below {minimum}:1; {skipped} skipped (non-hex).")
    return 1 if fails else 0

if __name__ == "__main__":
    sys.exit(main())
