#!/usr/bin/env bash
# quick-audit.sh: fast static checks for Shopify themes (ADA, performance, SEO, standards).
# Deterministic complement to Claude's review. It finds patterns; it cannot prove compliance.
#
# Usage:  bash quick-audit.sh [theme-dir] [--changed] [--no-fail] [--fail-on high|med] [--verbose]
#   theme-dir  theme root (default: current dir)
#   --changed  only report findings in files changed vs main (git)
#   --no-fail  always exit 0 (default: exit 1 if any High finding)
#   --fail-on  high (default) or med: severity that makes the exit code 1 (use med for the strict profile)
#   --verbose  also list LOW findings (hidden by default; counted in the summary)
# Output: SEV | RULE | file:line | message   then a summary.

set -u
DIR="."
CHANGED=0
FAIL=1
VERBOSE=0
FAILON="high"
while [ $# -gt 0 ]; do
  case "$1" in
    --changed) CHANGED=1 ;;
    --no-fail) FAIL=0 ;;
    --verbose) VERBOSE=1 ;;
    --fail-on) shift; FAILON="${1:-high}" ;;
    --fail-on=*) FAILON="${1#--fail-on=}" ;;
    *) DIR="$1" ;;
  esac
  shift
done
case "$FAILON" in high|med) ;; *) echo "--fail-on must be high or med"; exit 2 ;; esac

cd "$DIR" 2>/dev/null || { echo "Cannot open $DIR"; exit 2; }
if [ ! -f layout/theme.liquid ] && [ ! -d sections ]; then
  echo "Not a Shopify theme root (no layout/theme.liquid or sections/). Pass the theme directory."
  exit 2
fi

DIRS=""
for d in layout sections snippets blocks templates assets; do
  [ -d "$d" ] && DIRS="$DIRS $d"
done

CHANGED_LIST=""
if [ "$CHANGED" -eq 1 ] && git rev-parse --git-dir >/dev/null 2>&1; then
  base="main"; git rev-parse --verify main >/dev/null 2>&1 || base="master"
  CHANGED_LIST="$( { git diff --name-only "$base"...HEAD 2>/dev/null; git diff --name-only 2>/dev/null; git diff --name-only --staged 2>/dev/null; git ls-files --others --exclude-standard 2>/dev/null; } | sort -u)"
fi

OUT="$(mktemp)"

emit() { # sev rule file line msg
  if [ "$CHANGED" -eq 1 ] && ! printf '%s\n' "$CHANGED_LIST" | grep -qxF "$3"; then return; fi
  printf '%s | %s | %s:%s | %s\n' "$1" "$2" "$3" "$4" "$5" >> "$OUT"
}

# scan SEV RULE "message" "ERE pattern" "file include globs (space separated)"
scan() {
  sev="$1"; rule="$2"; msg="$3"; pat="$4"; globs="$5"
  [ -z "$DIRS" ] && return
  inc=""
  for g in $globs; do inc="$inc --include=$g"; done
  # shellcheck disable=SC2086
  grep -rnE $inc -e "$pat" $DIRS 2>/dev/null | while IFS= read -r line; do
    f="${line%%:*}"; rest="${line#*:}"; ln="${rest%%:*}"
    printf '%s\t%s\t%s\t%s\t%s\n' "$sev" "$rule" "$f" "$ln" "$msg"
  done
}

collect() { # run scan and emit results in the current shell
  while IFS=$'\t' read -r s r f l m; do
    [ -n "$s" ] && emit "$s" "$r" "$f" "$l" "$m"
  done
}

filter_out() { # drop findings whose source line matches ERE $1 (reads TSV on stdin)
  pat="$1"
  while IFS=$'\t' read -r s r f l m; do
    src="$(sed -n "${l}p" "$f")"
    printf '%s' "$src" | grep -qE "$pat" || printf '%s\t%s\t%s\t%s\t%s\n' "$s" "$r" "$f" "$l" "$m"
  done
}

L="*.liquid"; LJ="*.liquid *.js"; LC="*.liquid *.css"; ALL="*.liquid *.css *.js"

# ---------- Accessibility ----------
scan HIGH A01 "Viewport blocks zoom (maximum-scale / user-scalable=no): WCAG 1.4.4" 'maximum-scale|user-scalable *= *["'"'"']?no' "$L" | collect
# Does the theme define a visible global focus ring? (a :focus-visible rule that sets outline/box-shadow)
RING=0
if find $DIRS \( -name '*.css' -o -name '*.liquid' \) -print 2>/dev/null | while IFS= read -r f; do
  awk '
    /[{][ \t]*$/ { sel=$0; sub(/[{].*/,"",sel); inr=1; ok=0 }
    inr && /box-shadow|outline *: *(var|[1-9]|[a-z-]+ +solid)|outline-width/ { ok=1 }
    inr && /[}]/ { if (ok && sel ~ /focus-visible/ && sel !~ /not\(:focus-visible\)/) { print "ring"; exit } inr=0 }
  ' "$f"
done | grep -q ring; then RING=1; fi

find $DIRS \( -name '*.css' -o -name '*.liquid' \) -print 2>/dev/null | while IFS= read -r f; do
  awk -v F="$f" -v RING="$RING" '
    function check(sel, n) {
      if (sel ~ /not\(:focus-visible\)/) return
      if (sel ~ /tabindex/) return
      if (sel ~ /:hover|:disabled|\.disabled|\[disabled\]|:active/ && sel !~ /:focus/) return
      if (sel ~ /^[ \t]*(\*|html|body|:focus|\*:focus|a|button|input|a:focus|button:focus|input:focus)[ \t]*(,|$)/ && sel !~ /focus-visible/)
        printf "HIGH\tA02\t%s\t%d\tGlobal outline removal on [%s]: keyboard focus becomes invisible (WCAG 2.4.7)\n", F, n, sel
      else if (sel ~ /dialog|modal|popover|drawer|hotspot|tooltip/)
        printf "LOW\tA02\t%s\t%d\toutline removed on a container that receives programmatic focus: verify its interactive children keep a focus ring (WCAG 2.4.7)\n", F, n
      else if (sel ~ /:focus/ && RING == 1)
        printf "LOW\tA02\t%s\t%d\toutline removed here; the theme has a global focus ring: verify this component still shows focus (wrapper or pseudo-element ring) (WCAG 2.4.7)\n", F, n
      else if (sel ~ /:focus/)
        printf "MED\tA02\t%s\t%d\toutline removed on a focus selector with no visible replacement in the same rule and no global focus ring found: add a visible focus style (WCAG 2.4.7)\n", F, n
      else
        printf "LOW\tA02\t%s\t%d\toutline removed (not a focus selector): verify this element still shows keyboard focus (WCAG 2.4.7)\n", F, n
    }
    {
      l=$0
      if (l ~ /[{][^}]*outline[ ]*:[ ]*(none|0)[ ;!}]/) {
        if (l !~ /box-shadow|outline-color|border/) { sel=l; sub(/[{].*/,"",sel); check(sel, NR) }
        next
      }
      if (l ~ /[{][ \t]*$/) { sel=l; sub(/[{].*/,"",sel); inrule=1; repl=0; nl=0 }
      if (inrule && l ~ /outline[ ]*:[ ]*(none|0)[ ;!]/) nl=NR
      if (inrule && l ~ /box-shadow|outline-color|outline-style|outline[ ]*:[ ]*[1-9]|border(-color)?[ ]*:/) repl=1
      if (inrule && l ~ /[}]/) { if (nl>0 && !repl) check(sel, nl); inrule=0; nl=0 }
    }' "$f" | collect
done
scan HIGH A03 "Positive tabindex breaks focus order (WCAG 2.4.3)" 'tabindex *= *["'"'"']?[1-9]' "$L" | collect
scan LOW  A04 "autofocus: acceptable only to move focus to an error/status message; avoid on page load" '[ <]autofocus([ >=]|$)' "$L" | filter_out 'tabindex *= *["'"'"']-1|role *= *["'"'"']alert' | collect
scan LOW  A06 "Inline event handler: prefer addEventListener; confirm keyboard parity" ' on(click|mouseover|mouseenter|keydown|keyup) *= *["'"'"']' "$L" | collect
scan MED  A07 "role=menu/menuitem on site navigation: use nav + disclosure pattern" 'role *= *["'"'"']menu(item|bar)?["'"'"']' "$L" | collect
scan LOW  A09 "href=\"#\" link used as a control: use <button>" 'href *= *["'"'"']#["'"'"']' "$L" | collect
scan LOW  A10 "target=_blank: warn users it opens a new window (icon + text alternative)" 'target *= *["'"'"']_blank' "$L" | collect

if [ -f layout/theme.liquid ]; then
  grep -qiE 'skip|#MainContent|id="MainContent"' layout/theme.liquid || emit MED A14 layout/theme.liquid 1 "No skip link found in layout (WCAG 2.4.1)"
  grep -qE '<main' layout/theme.liquid || emit MED A15 layout/theme.liquid 1 "No <main> landmark in layout"
fi


# ---------- Tag-aware checks (multi-line tags, Liquid inside tags): A05 A08 A11 A12 A13 ----------
TAG_AWK='
function report(sev, rule, ln, msg) { printf "%s\t%s\t%s\t%d\t%s\n", sev, rule, F, ln, msg }
function eval_tag(name, buf, ln,    l) {
  l = tolower(name)
  if (l == "img") {
    if (buf !~ /[ \t]alt([ \t]*=|[ \t]|$)/) report("MED", "A05", ln, "<img> without an alt attribute (use image_tag, or alt=\"\" if decorative)")
  } else if (l == "video" || l == "audio") {
    if (buf ~ /[ \t]autoplay([ \t=]|$)/) {
      if (buf !~ /[ \t]muted([ \t=]|$)/) report("MED", "A08", ln, "autoplay without muted: no unexpected audio (WCAG 1.4.2); add a pause control (2.2.2)")
      else report("LOW", "A08", ln, "muted autoplay: verify a visible pause control (WCAG 2.2.2)")
    }
  } else if (l == "a" || l == "div" || l == "span") {
    if (buf ~ /role[ \t]*=[ \t]*["'"'"']button["'"'"']/) report("MED", "A11", ln, "role=button on a non-button element: prefer <button> with native keyboard support")
  } else if (l == "html") {
    if (buf !~ /lang[ \t]*=/) report("HIGH", "A12", ln, "<html> has no lang attribute (WCAG 3.1.1)")
    else if (buf ~ /lang[ \t]*=[ \t]*["'"'"']en["'"'"']/) report("LOW", "A13", ln, "lang hardcoded to en: use {{ request.locale.iso_code }}")
  }
}
BEGIN { skip = 0; inliq = 0; intag = 0; rawskip = "" }
{
  line = $0
  if (rawskip != "") { if (tolower(line) ~ ("</" rawskip)) rawskip = ""; next }
  if (!intag && !inliq) {
    if (skip == 0 && line ~ /[{]%-? *(doc|comment|schema|raw|javascript|stylesheet|style) *-?%[}]/ && line !~ /[{]%-? *end(doc|comment|schema|raw|javascript|stylesheet|style)/) { skip = 1; next }
  }
  if (skip == 1) { if (line ~ /[{]%-? *end(doc|comment|schema|raw|javascript|stylesheet|style) *-?%[}]/) skip = 0; next }
  n = length(line)
  for (i = 1; i <= n; i++) {
    c = substr(line, i, 1); c2 = substr(line, i, 2)
    if (inliq) {
      if ((liqclose == "%}" && c2 == "%}") || (liqclose == "}}" && c2 == "}}")) { inliq = 0; if (intag) tagbuf = tagbuf c2; i++ }
      else if (intag) tagbuf = tagbuf c
      continue
    }
    if (c2 == "{%") { inliq = 1; liqclose = "%}"; if (intag) tagbuf = tagbuf c2; i++; continue }
    if (c2 == "{{") { inliq = 1; liqclose = "}}"; if (intag) tagbuf = tagbuf c2; i++; continue }
    if (intag) {
      if (c == ">") {
        eval_tag(tagname, tagbuf, tagline); intag = 0
        lt = tolower(tagname)
        if (lt == "script" || lt == "style") { rest = tolower(substr(line, i + 1)); if (rest !~ ("</" lt)) rawskip = lt }
      } else tagbuf = tagbuf c
      continue
    }
    if (c == "<") {
      nm = substr(line, i + 1)
      if (match(nm, /^[A-Za-z][A-Za-z0-9-]*/)) { tagname = substr(nm, 1, RLENGTH); intag = 1; tagbuf = ""; tagline = NR; i += RLENGTH }
    }
  }
  if (intag) tagbuf = tagbuf " "
}'
find $DIRS -name '*.liquid' -print 2>/dev/null | while IFS= read -r f; do
  awk -v F="$f" "$TAG_AWK" "$f" | collect
done
scan MED  A08 "video_tag with autoplay and no muted: no unexpected audio (WCAG 1.4.2)" 'video_tag[^%}]*autoplay *: *true' "$L" | filter_out 'muted *: *true' | collect

# multiple h1 in one file
grep -rlE '<h1' $DIRS --include=*.liquid 2>/dev/null | while IFS= read -r f; do
  n="$(grep -oE '<h1' "$f" | wc -l | tr -d ' ')"
  [ "$n" -gt 1 ] && emit LOW A16 "$f" "$(grep -nE '<h1' "$f" | tail -1 | cut -d: -f1)" "$n <h1> in this file: verify only one renders per page (conditional is fine)"
done

# ---------- Performance ----------
scan HIGH P01 "{% include %} is deprecated: use {% render %}" '\{%-? *include ' "$L" | collect
scan HIGH P02 "document.write blocks parsing" 'document\.write *\(' "$LJ" | collect
scan HIGH P03 "<script src> without defer/async/module: render-blocking" '<script[^>]*[ ]src *=' "$L" | while IFS=$'\t' read -r s r f l m; do
  src="$(sed -n "${l}p" "$f")"; case "$src" in *defer*|*async*|*'type="module"'*|*"type='module'"*) ;; *) printf '%s\t%s\t%s\t%s\t%s\n' "$s" "$r" "$f" "$l" "$m";; esac
done | collect
scan MED  P04 "jQuery usage: not needed in modern themes" 'jQuery *\(|\$\(document\)|\$\(["'"'"'][.#a-zA-Z]|jquery([.-][0-9]|(\.min)?\.js)' "$LJ" | filter_out '^[[:space:]]*(\*|//|/\*)' | collect
scan MED  P05 "CSS background-image for content/hero: LCP image should be <img> (check if this is the hero)" 'background-image *: *url|style *= *"[^"]*background-image' "$LC" | while IFS=$'\t' read -r sv r f l m; do
  case "$f" in *hero*|*banner*|*slideshow*|*main-product*|*image-with*|*section.liquid) ;; *) sv=LOW;; esac
  printf '%s\t%s\t%s\t%s\t%s\n' "$sv" "$r" "$f" "$l" "$m"
done | collect
scan HIGH P06 "loading=lazy together with fetchpriority=high: contradictory; LCP image must be eager" 'loading *= *["'"'"']lazy["'"'"'][^>]*fetchpriority *= *["'"'"']high|fetchpriority *= *["'"'"']high["'"'"'][^>]*loading *= *["'"'"']lazy' "$L" | collect
for f in sections/*hero* sections/*image-banner* sections/*slideshow* sections/*main-product* sections/*image-with* snippets/*hero*; do
  [ -f "$f" ] || continue
  grep -qE 'section\.index|forloop\.first|fetchpriority' "$f" && continue
  grep -nE "loading *[:=] *[\"']?lazy" "$f" 2>/dev/null | while IFS=: read -r l _; do
    emit MED P07 "$f" "$l" "lazy loading in a likely above-the-fold file: first image must be eager + fetchpriority=high (use section.index)"
  done
done
scan MED  P08 "Hardcoded Shopify CDN URL: use image_url / image_tag or asset_url" 'cdn\.shopify\.com' "$L" | filter_out 'preconnect|shopifycloud|/storefront/' | collect
scan MED  P09 "img_url is deprecated: use image_url + image_tag" '\| *img_url' "$L" | collect
scan MED  P10 "External font host: self-host on Shopify CDN (/assets) or use system fonts" 'fonts\.googleapis\.com|fonts\.gstatic\.com|use\.typekit\.net|use\.fontawesome\.com' "$ALL" | collect
scan LOW  P11 "!important: fix specificity instead" '!important' "$LC" | collect
scan MED  P12 "Iterating all product.variants: check if first variant / options_with_values is enough" 'for +[a-z_]+ +in +[a-z_]*\.?variants' "$L" | collect
scan MED  P13 "Dynamic metafield key or metafield read: ensure it is outside loops" '\.metafields\[' "$L" | collect

# nested for-loop depth and metafields in loops (awk). Catalog-scale loops (products, variants, options,
# collections) nested 2+ deep are High; bounded loops such as menu links are only noted.
find $DIRS -name '*.liquid' -print 2>/dev/null | while IFS= read -r f; do
  awk -v F="$f" '
    function catalog_count(   i, c) { c=0; for (i=1;i<=depth;i++) c+=cat[i]; return c }
    {
      if ($0 ~ /[{]%-? *for /) {
        depth++
        cat[depth] = ($0 ~ /in +(collection\.products|collections|all_products|search\.results|[a-z_.]*\.variants|[a-z_.]*\.options|[a-z_]+\.products)/) ? 1 : 0
        if (depth>=3) {
          c=catalog_count()
          if (c>=2) printf "HIGH\tP14\t%s\t%d\tLoop depth %d over catalog data (products/variants/options): quadratic rendering, the main cause of high TTFB\n",F,NR,depth
          else if (c==1) printf "MED\tP14\t%s\t%d\tLoop depth %d including a catalog loop: check cost on large catalogs\n",F,NR,depth
          else printf "LOW\tP14\t%s\t%d\tLoop depth %d (bounded data such as menu links): fine unless the lists are large\n",F,NR,depth
        }
      }
      if (depth>=1 && $0 ~ /\.metafields\./ && catalog_count()>=1) printf "MED\tP15\t%s\t%d\tMetafield access inside a catalog loop: move it outside or use theme settings\n",F,NR
      if ($0 ~ /[{]%-? *endfor/) { if (depth>0) depth-- }
    }' "$f" | collect
done

if [ -f layout/theme.liquid ]; then
  ns="$(grep -cE 'rel *= *["'"'"']stylesheet|stylesheet_tag' layout/theme.liquid)"
  [ "$ns" -gt 5 ] && emit MED P16 layout/theme.liquid 1 "$ns stylesheet links in layout (conditional ones included): verify the count loaded per page"
  np="$(grep -cE 'rel *= *["'"'"']preload' layout/theme.liquid)"
  [ "$np" -gt 2 ] && emit MED P17 layout/theme.liquid 1 "$np preload hints in layout: keep to 1 or 2"
  grep -q 'content_for_header' layout/theme.liquid || emit HIGH S00 layout/theme.liquid 1 "content_for_header missing: required by Shopify"
fi

# ---------- SEO ----------
if [ -f layout/theme.liquid ]; then
  META_FILES="layout/theme.liquid"
  [ -d snippets ] && META_FILES="$META_FILES $(grep -rlE 'canonical_url|page_title|page_description|og:title' snippets 2>/dev/null | tr '\n' ' ')"
  # shellcheck disable=SC2086
  grep -qE 'canonical_url' $META_FILES 2>/dev/null || emit HIGH S01 layout/theme.liquid 1 "No canonical_url tag found in layout or meta snippets"
  # shellcheck disable=SC2086
  grep -qE 'page_title|<title' $META_FILES 2>/dev/null || emit HIGH S02 layout/theme.liquid 1 "No <title>/page_title found"
  # shellcheck disable=SC2086
  grep -qE 'page_description' $META_FILES 2>/dev/null || emit MED S03 layout/theme.liquid 1 "No meta description from page_description found"
  # shellcheck disable=SC2086
  grep -qE 'og:title|meta-tags' $META_FILES 2>/dev/null || emit LOW S04 layout/theme.liquid 1 "No Open Graph tags found"
fi
scan MED  S05 "Hardcoded canonical: use {{ canonical_url }}" 'rel *= *["'"'"']canonical["'"'"']' "$L" | while IFS=$'\t' read -r s r f l m; do
  a=$((l>3 ? l-3 : 1)); src="$(sed -n "${a},$((l+3))p" "$f")"; case "$src" in *canonical_url*) ;; *) printf '%s\t%s\t%s\t%s\t%s\n' "$s" "$r" "$f" "$l" "$m";; esac
done | collect
scan MED  S06 "Hardcoded Product JSON-LD: use {{ product | structured_data }} and avoid duplicate Product blocks" '"@type" *: *"Product"' "$L" | collect
scan LOW  S07 "noindex found: confirm this is intended" 'noindex' "$L" | collect
scan LOW  S08 "Collection-scoped product URL (within:): prefer canonical product.url for internal links" '\| *within *:' "$L" | collect
for f in snippets/*header* snippets/*logo* sections/*header*; do
  [ -f "$f" ] || continue
  case "$f" in *password*) continue;; esac
  grep -qE "(page_type|template\.name|template) *== *['\"]index['\"]" "$f" && continue
  grep -nE '<h1' "$f" 2>/dev/null | while IFS=: read -r l _; do
    emit MED S09 "$f" "$l" "<h1> in header/logo: the logo should not be the h1 on inner pages"
  done
done
[ -f templates/robots.txt.liquid ] || emit LOW S10 templates/robots.txt.liquid 1 "No robots.txt.liquid (optional): consider if tag/facet crawl control is needed"

# ---------- Standards ----------
scan MED  T01 "Hardcoded English in markup: use {{ 'key' | t }} (verify)" '>[A-Z][a-z]+( [a-z]+){1,6}<' "$L" | filter_out '^[[:space:]]*"[A-Za-z_]+" *:|@param|@example|\{%-? *doc' | collect
scan LOW  T02 "Inline style attribute: use CSS variables / {% style %}" ' style *= *"[^{]*[a-z-]+ *:' "$L" | collect

# ---------- Output ----------
HIGH="$(grep -c '^HIGH |' "$OUT")"; MED="$(grep -c '^MED |' "$OUT")"; LOW="$(grep -c '^LOW |' "$OUT")"
if [ -s "$OUT" ]; then
  awk -F' \\| ' -v V="$VERBOSE" '{o=($1=="HIGH")?0:($1=="MED")?1:2; if (o<2 || V==1) print o"\t"$0}' "$OUT" | sort -k1,1n -s | cut -f2-
fi
echo
echo "Summary: HIGH=$HIGH  MED=$MED  LOW=$LOW$( [ "$VERBOSE" -eq 0 ] && [ "$LOW" -gt 0 ] && echo " (LOW hidden, use --verbose)")   Static checks only: also run theme check, keyboard + screen reader tests, Lighthouse."
rm -f "$OUT"
if [ "$FAIL" -eq 1 ] && [ "$HIGH" -gt 0 ]; then exit 1; fi
if [ "$FAIL" -eq 1 ] && [ "$FAILON" = "med" ] && [ "$MED" -gt 0 ]; then exit 1; fi
exit 0
