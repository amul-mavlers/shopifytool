#!/usr/bin/env bash
# One-command installer for the Shopify Team Kit (Claude Code plugin).
# Usage: bash install.sh [marketplace-source] [--with-figma]
#   marketplace-source  folder or Git source of this repo (default: the folder this script is in),
#                       e.g. your-org/shopify-team-kit-repo for a GitHub-hosted copy
#   --with-figma        also connect the official Figma MCP server (you still sign in with /mcp)
# Needs: bash (macOS, Linux, Git Bash or WSL), Claude Code (`claude`). Recommended: git, node, Shopify CLI.
set -u
SRC=""; WITH_FIGMA=0
for a in "$@"; do
  case "$a" in
    --with-figma) WITH_FIGMA=1 ;;
    *) SRC="$a" ;;
  esac
done
[ -n "$SRC" ] || SRC="$(cd "$(dirname "$0")" && pwd)"
MKT="shopify-team-kit-marketplace"; PLUGIN="shopify-team-kit"

say() { printf '%s\n' "$*"; }
if ! command -v claude >/dev/null 2>&1; then
  say "Claude Code is not installed. Install it first:  curl -fsSL https://claude.ai/install.sh | bash"
  exit 1
fi
say "Prerequisites:"
for t in git node npm shopify python3; do
  if command -v "$t" >/dev/null 2>&1; then say "  ok       $t"; else
    case "$t" in
      shopify) say "  missing  shopify  (npm install -g @shopify/cli@latest) needed for theme dev and theme check" ;;
      python3) say "  missing  python3  needed for the contrast check" ;;
      node|npm) say "  missing  $t  needed for rendered-page QA" ;;
      *) say "  missing  $t" ;;
    esac
  fi
done

say ""; say "Adding marketplace from: $SRC"
out="$(claude plugin marketplace add "$SRC" 2>&1)"; rc=$?
say "$out" | tail -2
if [ $rc -ne 0 ] && ! printf '%s' "$out" | grep -qi 'already'; then
  say "Could not add the marketplace. Check the path or Git source above."; exit 1
fi

say ""; say "Installing plugin..."
out="$(claude plugin install "$PLUGIN@$MKT" 2>&1)"; rc=$?
say "$out" | tail -2
if [ $rc -ne 0 ] && ! printf '%s' "$out" | grep -qi 'already'; then
  say "Install failed. Run: claude plugin validate \"$SRC\""; exit 1
fi

if [ "$WITH_FIGMA" -eq 1 ]; then
  say ""; say "Connecting Figma MCP..."
  claude mcp add --transport http figma https://mcp.figma.com/mcp 2>&1 | tail -1
  say "Open Claude Code, run /mcp and sign in to Figma."
fi

say ""
say "Installed. Next, inside your theme repo:"
say "  claude"
say "  /shopify-team-kit:setup-project     (once per project)"
say "  /shopify-team-kit:foundation        (once per project)"
say "  /shopify-team-kit:build <task | bug | Figma link>"
