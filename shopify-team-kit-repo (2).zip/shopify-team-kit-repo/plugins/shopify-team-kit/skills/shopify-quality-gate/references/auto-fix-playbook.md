# Auto-fix playbook: one recipe per rule

Use during the fix loop. "ASK" means put a question in the batched "Needs your input" message (with a recommended default) instead of changing it silently. Everything else: fix and re-verify.

## Contents
1. quick-audit rules (A, P, S, T)
2. rendered-qa rules (R) and axe findings
3. Contrast
4. Shopify Theme Check offenses
5. General fix rules

## 1. quick-audit rules

| ID | Fix | ASK when |
|---|---|---|
| A01 | Remove `maximum-scale` and `user-scalable=no` from the viewport meta | never |
| A02 | Global removal: delete it and rely on the `:focus-visible` ring from `kit-base.css` (add the foundation if missing). Focus selector with no replacement: add `box-shadow`/`outline` ring using theme variables | the ring color clashes with the brand palette |
| A03 | Remove positive `tabindex`; reorder the DOM instead | reordering changes the visual layout |
| A04 | Remove `autofocus` unless it is the error/status message pattern (`tabindex="-1"` + `role="alert"`) | never |
| A05 | Use `image_tag` (alt comes from the image); otherwise `alt="{{ x.alt \| escape }}"` or `alt=""` when decorative; add a schema setting for merchant-provided alt | never |
| A06 | Move handler to JS with `addEventListener`; keep keyboard parity | never (Low) |
| A07 | Remove `role="menu"/"menuitem"`; use `nav` + disclosure button with `aria-expanded` and `aria-controls` | never |
| A08 | Add `muted`, `playsinline` and a visible pause control, or remove `autoplay` | the design depends on an autoplaying video |
| A09 | Replace with `<button type="button">`, or a real URL | never |
| A10 | Add `rel="noopener"` and visually hidden text from `accessibility.opens_in_new_window` | never |
| A11 | Replace the element with `<button type="button">`, keep classes and move handlers | never |
| A12 | Add `lang="{{ request.locale.iso_code }}"` | never |
| A13 | Replace the hardcoded language with `{{ request.locale.iso_code }}` | never |
| A14 | Render `kit-skip-link` (apply the foundation if missing) and ensure `<main id="MainContent" tabindex="-1">` | never |
| A15 | Wrap `content_for_layout` in `<main id="MainContent" tabindex="-1">`; remove any second `main` in sections | never |
| A16 | One `h1` per page: keep the page title, change extras to `h2` and keep the class for styling | never |
| P01 | `{% include 'x' %}` to `{% render 'x', var: var %}`: read the snippet, pass every outer variable it uses explicitly | the snippet assigns variables the parent reads afterwards |
| P02 | Replace `document.write` with DOM insertion or a deferred script | never |
| P03 | Add `defer` (modules: `type="module"`; independent third parties: `async`); keep order for dependent scripts | the script is injected by an app or needs a specific position |
| P04 | Rewrite jQuery usage in vanilla JS | an app depends on jQuery |
| P05 | Replace CSS `background-image` hero with `<img>` + `object-fit: cover` (or `<picture>`), same look | never |
| P06 | Remove `loading="lazy"` from the LCP image; keep `fetchpriority="high"` | never |
| P07 | First image: `loading="eager"` + `fetchpriority="high"` when `section.index == 1`; others lazy | never |
| P08 | Replace hardcoded CDN image URLs with `image_url`/`asset_url` (leave `shopifycloud` and preconnect) | never |
| P09 | `img_url` to `image_url: width: N` with `image_tag` | never |
| P10 | Self-host the font in `/assets` with `font-display: swap`, or use theme font pickers or system fonts | the font is proprietary and the file is not provided |
| P11 | Fix specificity instead of `!important` | never (Low) |
| P12 | Use the first variant or `options_with_values` instead of looping all variants | the feature really needs all variants |
| P13 | Use static metafield keys | never |
| P14 | Hoist work out of loops, flatten with a snippet, add `limit`/`paginate`, precompute with `assign` | the fix changes behavior (for example menu depth) |
| P15 | Hoist the metafield read before the loop into a variable | never |
| P16 | Merge small stylesheets or load section CSS with `{% stylesheet %}`; defer below-the-fold CSS | the files are app or vendor assets |
| P17 | Keep at most 1 or 2 preloads (LCP image or critical font); remove the rest | never |
| S00 | Add `{{ content_for_header }}` before `</head>` | never |
| S01 | Render `kit-meta-tags` or add `<link rel="canonical" href="{{ canonical_url }}">` | never |
| S02 | Add the `<title>` block (page_title, tags, page number, shop name) | never |
| S03 | Add `<meta name="description" content="{{ page_description \| escape }}">` | never |
| S04 | Add Open Graph and Twitter tags via `kit-meta-tags` | never |
| S05 | Replace the hardcoded canonical with `{{ canonical_url }}` | never |
| S06 | Remove hardcoded Product JSON-LD, use `{{ product \| structured_data }}` | the hardcoded block has fields the filter lacks (for example ratings): keep those with live values and ask |
| S07 | Remove `noindex` from pages that should rank (home, collection, product, content) | intent unclear |
| S08 | Use `product.url` for internal links unless collection context is needed | never (Low) |
| S09 | Make the logo a `div`/`span` except on the home page; keep classes | never |
| S10 | Optional: add `robots.txt.liquid` from Shopify's default | the client wants crawl control for tags or facets |
| T01 | Move text to `locales/en.default.json` and use `{{ 'key' \| t }}` | never |
| T02 | Move styles to a class or `{% style %}` with CSS variables | never (Low) |

## 2. rendered-qa rules and axe

| ID | Fix | ASK when |
|---|---|---|
| R00 | Could not load the page: check the URL, server and password; use a saved HTML file if needed | **always: need the preview URL or access** |
| R01 | Add or fix `<title>` (about 60 characters) | never |
| R02 | Add or fix the meta description (about 160) | never |
| R03 | Exactly one absolute canonical via `canonical_url`; remove duplicates from apps or the theme | the duplicate comes from an app |
| R04 | Exactly one `h1` per page | never |
| R05 | Invalid JSON-LD: build it with the `json` filter; duplicate Product: keep the theme's `structured_data` block and remove the other | the duplicate comes from an app |
| R06 | Add Open Graph tags via `kit-meta-tags` | never |
| R08 | Use `image_tag`, or add `width` and `height` from `image.width` and `image.height` | never |
| R09 | The first visible image: eager + `fetchpriority="high"` | never |
| R10 | Add `defer`/`async`/module to head scripts | the script comes from an app |
| R11 | Reduce stylesheet count (see P16) | never (Low) |
| R12 | Remove `noindex` from pages that should rank | intent unclear |
| R13 | Make ids unique with `section.id`, `block.id` or `forloop.index` | never |
| R14 | Fix the viewport (A01) | never |
| R18 | Add the skip link and `main id` (A14) | never |
| axe:* | Apply the rule's guidance: add labels (`for`/`id`), accessible names (visually hidden text or `aria-label` from a locale key), alt text, heading order, valid ARIA (remove wrong roles), landmarks, list structure | the fix would change the design |

## 3. Contrast (`contrast-check.py`)

- Text below 4.5:1 or UI below 3:1: compute the nearest shade of the same hue that passes (darken on light backgrounds, lighten on dark) and apply it to the theme default color scheme.
- ASK when the failing color is a brand color: offer (A, recommended) the adjusted shade, or (B) keep the brand color and use it only for large text or decoration.

## 4. Shopify Theme Check offenses (step 1 of the gate; catches what the static audit cannot)

| Offense | Fix | ASK when |
|---|---|---|
| TranslationKeyExists / MatchingTranslations | Add the key to `locales/en.default.json` (and the other locale files the store uses) with the English text | the store has other locales and no translation is available (add English, list it) |
| MissingAsset | Create the referenced `assets/` file, or correct the path | the file's content is unknown (third-party library, design asset): **ask for it** |
| MissingRenderSnippetArguments / UnusedDocParam | Read the snippet's `{% doc %}` block and pass every required `@param` in the `render` tag (after converting `include` to `render`); remove or document unused params | the value for a required param is unknown (for example a product resource) |
| MissingTemplate / MissingRenderSnippet / UnknownFilter | Create the snippet or fix the name or path | the intended content is unknown |
| ValidSchema / ValidSettingsKey / SchemaPresetsBlockOrder / UniqueStaticBlockId | Fix the schema JSON as the message says; unique ids; matching block order. "Missing property label": add a label (and a locale key if the theme uses `t:` labels). "Value is not accepted": use a valid setting type. "Property X is not allowed" (for example `templates` in an older section schema): remove the property or move it to its current form (page restrictions use `enabled_on` / `disabled_on` with a `templates` list); check Shopify's section schema reference for the property | the property carried real behavior (such as where the section may appear) and the replacement is not obvious |
| UndefinedObject / UnusedAssign / VariableName | Pass the missing variable, remove the unused assign, rename to snake_case | never |
| LiquidHTMLSyntaxError / UnclosedHTMLElement | Close tags, fix syntax | never |
| ParserBlockingScript / RemoteAsset / AssetSizeJavaScript / AssetSizeCSS | See P03, P08, P04; split or defer large assets | the asset is an app or vendor file |
| DeprecatedFilter / DeprecatedTag / DeprecatedLazysizes | Use the modern filter, `render`, native `loading="lazy"` | never |
| ImgWidthAndHeight / ImgLazyLoading | See R08 and P06/P07 | never |
| LiquidComplexity / NestedSnippet | See P14 and P15 | the fix changes behavior |
| any other | Read the offense message and docs link, apply the smallest compliant change | the fix changes behavior or needs unknown input |

## 5. General fix rules
- Smallest change that satisfies the rule; no redesign, no refactor of unrelated code.
- Follow `shopify-theme-standards` while fixing (render, schema, locales, ownership mode: `third-party` themes get `custom-*` copies).
- After every round re-run the same checks on the affected files; never assume a fix worked.
- Record each fix; the Done report counts them.
