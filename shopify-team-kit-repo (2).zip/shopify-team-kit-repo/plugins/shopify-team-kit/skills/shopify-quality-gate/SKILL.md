---
name: shopify-quality-gate
description: This skill should be used at the end of any Shopify theme build, fix or refactor, when the user says "QA", "test", "review", "fix everything", "ready", "done", "release" or "PR", and from the /build, /figma-to-section, /figma-to-page, /new-section, /fix-bug and /foundation commands. Provides the automatic resolve-and-verify gate, the ask-only-when-blocked policy and the Done report.
---

# Shopify quality gate: resolve, don't report

Goal: the user receives work that already passed, not a list of things to test. Find problems, **fix them directly**, re-verify, and ask the user only when a real dependency or decision blocks progress.

Read the **Quality profile** from the project `CLAUDE.md` (`standard` if absent).

| | standard | strict |
|---|---|---|
| Must be clean | no High | no High and no Medium (`--fail-on med`) |
| Reviewer verdict | not BLOCK | OK TO MERGE |
| Contrast check | when colors changed | always |
| Rendered QA | key pages touched | key pages touched, `--fail-on med` |
| Fix rounds | 3 | 4 |

## Procedure

1. **Static checks** (changed files): Theme Check, then run `shopify theme check` if the Shopify CLI is installed, otherwise `node scripts/qa/theme-check.mjs .` (the same engine, installed by setup; it prints theme-relative paths, exit 1 means errors). Report the error count in the Done report; never skip Theme Check silently. Then `node scripts/quick-audit.mjs . --changed` (strict: `--fail-on med`).
2. **Contrast** (colors or color schemes changed, or strict): `node scripts/contrast-check.mjs .`. Exit 0 = pairs checked and passing; exit 1 = a pair fails; **exit 3 = nothing could be paired, so contrast is NOT VERIFIED** (never report that as a pass: add `--pair fgKey:bgKey` for this theme's setting names, or list it under "Not verifiable here").
3. **Rendered QA** (axe-core + SEO/performance rules on real HTML): get the HTML of the pages the change appears on, then `node scripts/qa/rendered-qa.mjs <urls or files>`.
   - Preview source, in order: a running `shopify theme dev` (`http://127.0.0.1:9292`, check with `curl -sI`); start `shopify theme dev` in the background if the CLI is logged in and the dev store is in `CLAUDE.md`; otherwise the preview URL from the user.
   - Pages: map each changed section/snippet to the templates that render it (grep `templates/*.json`, `sections/*.json`, `layout/`); always include the home page when the layout or foundation changed, plus one collection, one product and the cart when shared snippets changed.
   - If dependencies are missing run `npm install --no-audit --no-fund --prefix scripts/qa` once.
4. **Review**: run the `shopify-code-reviewer` agent on the diff.
5. **Fix loop** (rounds from the table): fix every finding that fails the profile using `references/auto-fix-playbook.md` (one recipe per rule ID). After each round re-run steps 1 to 4 on the affected files. Repeat until clean or out of rounds.
6. **Classify what remains** and stop:
   - **Fixed**: counted in the report.
   - **Needs your input**: a real blocker (ask policy below).
   - **Not verifiable here**: one line only.
7. **Done report** (exactly this shape; no manual test lists):

```
DONE
Change: <one line>
Files: <list>
Verified automatically: theme check <pass|n/a> | audit H/M/L <before> -> <after> | rendered QA <pages> <before> -> <after> | contrast <pass|not verified|n/a> | review <verdict> | fix rounds <n>
Auto-fixed: <count> issues, top items: <up to 5 bullets>
Needs your input: <numbered questions, each with a recommended default> | none
Not verifiable here: <one line, e.g. real-device and screen-reader behavior> | none
```

## Ask policy: ask only for these, all in one batched message at the end

1. **Missing dependency or input**: preview URL or store password, dev theme ID, Figma access or a frame, assets or copy, licensed fonts, API credentials, a product or collection to test with.
2. **Standard vs design or requirement conflict**: a brand color that fails contrast, an autoplay hero video, removing an app's script, a design that needs a pattern the standards forbid.
3. **Wide blast radius or irreversible**: header/footer/global CSS changes used by every page, deleting files, pushing anywhere, changing merchant data.
4. **Ambiguous intent** that changes the result.

Everything else: fix it. Do not ask permission for fixes the playbook covers. Do not stall: finish all unblocked work first, then ask. Each question gives: what is blocked, 2 options, a **recommended default**, and what was already done around it. If the user does not answer, nothing blocked is applied.

## Rules
- Never claim "compliant", "pixel perfect", "production ready" or "fully tested". State what ran and its result.
- Never weaken a rule, edit the audit scripts or add suppressions to make a finding disappear. A confirmed false positive is listed in the report with the reason.
- Never hide a failure: if a High remains after the last round, it goes under "Needs your input" with the diagnosis and the options.
- Do not commit, push or deploy unless asked; if asked, push to the dev theme only.
- Keep the gate proportional: a one-line copy change still gets theme check and audit, and the report can be three lines.
