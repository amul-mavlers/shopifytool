---
description: "Performance audit (Core Web Vitals, Liquid, images, JS, CSS, fonts) with ranked fixes."
argument-hint: "[path or template name, default: whole theme] [--report-only to change nothing]"
allowed-tools: Read, Edit, Glob, Grep, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(node scripts/quick-audit.mjs:*), Bash(node scripts/contrast-check.mjs:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(node scripts/qa/theme-check.mjs:*), Bash(npm install:*), Bash(curl -sI:*)
---

Performance audit of: $ARGUMENTS (default: whole theme)

Use the `shopify-performance` skill and `references/shopify-performance-rules.md`.

1. Run `node scripts/quick-audit.mjs .` (P-rules) and `shopify theme check` if available.
2. Read `layout/theme.liquid`, the hero/first sections, product and collection templates, card snippets, and the largest JS/CSS in `assets/`. Look for: LCP image handling, background-image heroes, nested loops, metafields in loops, variant iteration, blocking scripts, stylesheet count, Google Fonts, preloads, duplicate menus, unused app scripts.
3. Output a table ranked by impact: `# | Issue | File:line | Metric | Impact | Fix`.
4. Ask me for (or state how to get) baseline numbers: Lighthouse mobile for home, collection, product; LCP element; Web Performance Dashboard. Do not claim improvements without before/after numbers.
5. Unless `--report-only`: fix findings by impact using the auto-fix playbook, keep diffs small, re-run step 1, and report before/after counts. Ask only for real blockers (batched, with defaults).
