---
description: "WCAG 2.2 AA audit of a file, section, template or the whole theme, with fixes."
argument-hint: "[path or template name, default: whole theme] [--report-only to change nothing]"
allowed-tools: Read, Edit, Glob, Grep, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(node scripts/quick-audit.mjs:*), Bash(node scripts/contrast-check.mjs:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(node scripts/qa/theme-check.mjs:*), Bash(npm install:*), Bash(curl -sI:*)
---

Accessibility audit of: $ARGUMENTS (default: whole theme)

Use the `shopify-ada-wcag` skill and `references/wcag-shopify-map.md`.

1. Run `node scripts/quick-audit.mjs . ` and keep the A-rule findings.
2. Read the target files and check against the build rules: structure, images, contrast (compute ratios for color tokens used in text/UI pairs), keyboard and focus, target size, navigation, dialogs, forms, live regions, reflow.
3. Output a table: `Criterion | Level | File:line | Issue | Severity | Fix`. Group repeated issues.
4. Unless `--report-only`: fix every High and Medium finding using the auto-fix playbook (`shopify-quality-gate/references/auto-fix-playbook.md`) without changing the visual design, re-run step 1 and rendered QA, and show before/after counts. Ask only for real blockers (batched, with a recommended default), e.g. a brand color that fails contrast.
Never state the site is "compliant"; state what was checked.
