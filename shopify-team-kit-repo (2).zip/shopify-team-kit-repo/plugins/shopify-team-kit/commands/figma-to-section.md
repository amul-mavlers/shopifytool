---
description: "Convert a Figma frame into an editable Shopify section using the Figma MCP, with a visual check and quality gate."
argument-hint: "[figma frame link] [optional: mobile frame link] [section name]"
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(git status:*), Bash(git diff:*), Bash(git log:*), Bash(git ls-files:*), Bash(git rev-parse:*), Bash(git branch:*), Bash(node scripts/quick-audit.mjs:*), Bash(node scripts/contrast-check.mjs:*), Bash(node scripts/qa/rendered-qa.mjs:*), Bash(shopify theme check:*), Bash(node scripts/qa/theme-check.mjs:*), Bash(npm install:*), Bash(curl -sI:*)
---

Build this Figma design as a Shopify section: $ARGUMENTS

Follow the `figma-to-shopify` skill exactly (parse node-id, design context, screenshot, variables, assets, plan, Liquid, quality skills, visual check, quality gate, hand-off).

- If the Figma MCP is not connected, tell me the one command to connect it and stop.
- If the link is not a single frame or component, ask for the right link.
- Ask all design-gap questions (missing states, mobile frame, fonts, overlays) in one message before coding.
- Run the quality gate (skill `shopify-quality-gate`): fix everything it finds automatically; ask only for real blockers (batched, with defaults).
- Finish with the hand-off summary and, if I can run a preview, the exact `shopify theme dev` URL path to compare.
