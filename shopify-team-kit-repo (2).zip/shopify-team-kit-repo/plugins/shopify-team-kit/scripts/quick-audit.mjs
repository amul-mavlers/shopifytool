#!/usr/bin/env node
/**
 * quick-audit.mjs: fast static checks for Shopify themes (ADA, performance, SEO, standards).
 * Single-process Node implementation (no Python, grep, awk or sed): fast on Windows, macOS and Linux.
 * Deterministic complement to Claude's review. It finds patterns; it cannot prove compliance.
 *
 * Usage: node quick-audit.mjs [theme-dir] [--changed] [--no-fail] [--fail-on high|med] [--verbose] [--no-group]
 *   theme-dir  theme root (default: current dir). If it is not a theme root, nearby folders are searched.
 *   --changed  only report findings in files changed vs main/master (committed, staged, unstaged, untracked)
 *   --no-fail  always exit 0 (default: exit 1 if any High finding)
 *   --fail-on  high (default) or med: severity that makes the exit code 1 (use med for the strict profile)
 *   --verbose  also list LOW findings (hidden by default; counted in the summary)
 *   --no-group list every occurrence (default: a rule with more than 3 identical findings is shown once with a count)
 * Output: SEV | RULE | file:line | message, then a summary. Exit: 0 ok, 1 findings reached --fail-on, 2 usage/not a theme.
 */
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";

// ---------------------------------------------------------------- args
const argv = process.argv.slice(2);
let dir = ".", changedOnly = false, noFail = false, verbose = false, group = true, failOn = "high";
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === "--changed") changedOnly = true;
  else if (a === "--no-fail") noFail = true;
  else if (a === "--verbose") verbose = true;
  else if (a === "--no-group") group = false;
  else if (a === "--fail-on") failOn = argv[++i] || "high";
  else if (a.startsWith("--fail-on=")) failOn = a.slice(10);
  else dir = a;
}
if (!["high", "med"].includes(failOn)) { console.log("--fail-on must be high or med"); process.exit(2); }

let root = path.resolve(dir);
if (!fs.existsSync(root) || !fs.statSync(root).isDirectory()) { console.log(`Cannot open ${dir}`); process.exit(2); }
const isThemeRoot = (d) => fs.existsSync(path.join(d, "layout", "theme.liquid")) || fs.existsSync(path.join(d, "sections"));
if (!isThemeRoot(root)) {
  const found = [];
  const walk = (d, depth) => {
    if (depth > 3 || found.length >= 5) return;
    let ents; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      if (!e.isDirectory() || e.name === "node_modules" || e.name === ".git") continue;
      const p = path.join(d, e.name);
      if (fs.existsSync(path.join(p, "layout", "theme.liquid"))) found.push(p); else walk(p, depth + 1);
    }
  };
  walk(root, 1);
  console.log("Not a Shopify theme root (no layout/theme.liquid or sections/).");
  const show = (p) => { const rel = path.relative(process.cwd(), p); return rel && !rel.startsWith("..") && !path.isAbsolute(rel) ? rel : p; };
  if (found.length) { console.log("Did you mean:"); for (const f of found) console.log("  " + show(f) + "  (run the audit with this folder)"); }
  else console.log("Pass the theme directory (the folder that contains layout/, sections/ and templates/).");
  process.exit(2);
}

// ---------------------------------------------------------------- files
const DIRS = ["layout", "sections", "snippets", "blocks", "templates", "assets"].filter((d) => fs.existsSync(path.join(root, d)));
const files = []; // {rel, ext, text, lines}
const listFiles = (d) => {
  let ents; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
  for (const e of ents) {
    const p = path.join(d, e.name);
    if (e.isDirectory()) listFiles(p);
    else if (/\.(liquid|css|js)$/.test(e.name)) {
      let text; try { text = fs.readFileSync(p, "utf8"); } catch { continue; }
      const rel = path.relative(root, p).split(path.sep).join("/");
      files.push({ rel, ext: path.extname(e.name).slice(1), text, lines: text.split(/\r?\n/) });
    }
  }
};
for (const d of DIRS) listFiles(path.join(root, d));
files.sort((a, b) => (a.rel < b.rel ? -1 : 1));
const byRel = new Map(files.map((f) => [f.rel, f]));
const liquid = files.filter((f) => f.ext === "liquid");
const withExt = (...exts) => files.filter((f) => exts.includes(f.ext));

// ---------------------------------------------------------------- changed files
let changedSet = null;
if (changedOnly) {
  const git = (args) => { try { return execFileSync("git", args, { cwd: root, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }); } catch { return null; } };
  if (git(["rev-parse", "--git-dir"]) === null) {
    console.log("Note: --changed ignored (not a git repository): auditing all files.");
  } else {
    const base = git(["rev-parse", "--verify", "main"]) !== null ? "main" : "master";
    // --relative keeps paths relative to the theme folder even when the theme sits inside a bigger repo
    const outs = [git(["diff", "--name-only", "--relative", `${base}...HEAD`]), git(["diff", "--name-only", "--relative"]), git(["diff", "--name-only", "--staged", "--relative"]), git(["ls-files", "--others", "--exclude-standard"])];
    changedSet = new Set(outs.filter(Boolean).join("\n").split(/\r?\n/).filter(Boolean).map((s) => s.replace(/\\/g, "/")));
  }
}

// ---------------------------------------------------------------- findings
const findings = [];
const emit = (sev, rule, file, line, msg) => {
  if (changedSet && !changedSet.has(file)) return;
  findings.push({ sev, rule, file, line, msg });
};
// scan one regex per line. opts: { filter: RegExp on the line to drop, sev: (file)=>sev }
const scan = (sev, rule, msg, re, fileList, opts = {}) => {
  for (const f of fileList) {
    for (let i = 0; i < f.lines.length; i++) {
      const ln = f.lines[i];
      if (!re.test(ln)) continue;
      if (opts.drop && opts.drop.test(ln)) continue;
      if (opts.dropWindow) { const a = Math.max(0, i - 3), w = f.lines.slice(a, i + 4).join("\n"); if (opts.dropWindow.test(w)) continue; }
      emit(opts.sev ? opts.sev(f.rel) : sev, rule, f.rel, i + 1, msg);
    }
  }
};
const L = liquid, LJ = withExt("liquid", "js"), LC = withExt("liquid", "css"), ALL = withExt("liquid", "css", "js");

// ---------------------------------------------------------------- Accessibility
scan("HIGH", "A01", "Viewport blocks zoom (maximum-scale / user-scalable=no): WCAG 1.4.4", /maximum-scale|user-scalable *= *["']?no/, L);

// A02: outline removal. A theme-wide ring (a :focus-visible rule that sets outline/box-shadow) downgrades component-level removals.
const cssLike = withExt("css", "liquid");
let RING = false;
for (const f of cssLike) {
  let sel = "", inr = false, ok = false;
  for (const l of f.lines) {
    if (/[{][ \t]*$/.test(l)) { sel = l.replace(/[{].*/, ""); inr = true; ok = false; }
    if (inr && /box-shadow|outline *: *(var|[1-9]|[a-z-]+ +solid)|outline-width/.test(l)) ok = true;
    if (inr && /[}]/.test(l)) { if (ok && /focus-visible/.test(sel) && !/not\(:focus-visible\)/.test(sel)) { RING = true; break; } inr = false; }
  }
  if (RING) break;
}
const a02 = (f, sel, n) => {
  if (/not\(:focus-visible\)/.test(sel)) return;
  if (/tabindex/.test(sel)) return;
  if (/:hover|:disabled|\.disabled|\[disabled\]|:active/.test(sel) && !/:focus/.test(sel)) return;
  if (/^[ \t]*(\*|html|body|:focus|\*:focus|a|button|input|a:focus|button:focus|input:focus)[ \t]*(,|$)/.test(sel) && !/focus-visible/.test(sel))
    emit("HIGH", "A02", f, n, `Global outline removal on [${sel}]: keyboard focus becomes invisible (WCAG 2.4.7)`);
  else if (/dialog|modal|popover|drawer|hotspot|tooltip/.test(sel))
    emit("LOW", "A02", f, n, "outline removed on a container that receives programmatic focus: verify its interactive children keep a focus ring (WCAG 2.4.7)");
  else if (/:focus/.test(sel) && RING)
    emit("LOW", "A02", f, n, "outline removed here; the theme has a global focus ring: verify this component still shows focus (wrapper or pseudo-element ring) (WCAG 2.4.7)");
  else if (/:focus/.test(sel))
    emit("MED", "A02", f, n, "outline removed on a focus selector with no visible replacement in the same rule and no global focus ring found: add a visible focus style (WCAG 2.4.7)");
  else
    emit("LOW", "A02", f, n, "outline removed (not a focus selector): verify this element still shows keyboard focus (WCAG 2.4.7)");
};
for (const f of cssLike) {
  let sel = "", inrule = false, repl = false, nl = 0;
  f.lines.forEach((l, idx) => {
    const NR = idx + 1;
    if (/[{][^}]*outline[ ]*:[ ]*(none|0)[ ;!}]/.test(l)) {
      if (!/box-shadow|outline-color|border/.test(l)) a02(f.rel, l.replace(/[{].*/, ""), NR);
      return;
    }
    if (/[{][ \t]*$/.test(l)) { sel = l.replace(/[{].*/, ""); inrule = true; repl = false; nl = 0; }
    if (inrule && /outline[ ]*:[ ]*(none|0)[ ;!]/.test(l)) nl = NR;
    if (inrule && /box-shadow|outline-color|outline-style|outline[ ]*:[ ]*[1-9]|border(-color)?[ ]*:/.test(l)) repl = true;
    if (inrule && /[}]/.test(l)) { if (nl > 0 && !repl) a02(f.rel, sel, nl); inrule = false; nl = 0; }
  });
}
scan("HIGH", "A03", "Positive tabindex breaks focus order (WCAG 2.4.3)", /tabindex *= *["']?[1-9]/, L);
scan("LOW", "A04", "autofocus: acceptable only to move focus to an error/status message; avoid on page load", /[ <]autofocus([ >=]|$)/, L, { drop: /tabindex *= *["']-1|role *= *["']alert/ });
scan("LOW", "A06", "Inline event handler: prefer addEventListener; confirm keyboard parity", / on(click|mouseover|mouseenter|keydown|keyup) *= *["']/, L);
scan("MED", "A07", "role=menu/menuitem on site navigation: use nav + disclosure pattern", /role *= *["']menu(item|bar)?["']/, L);
scan("LOW", "A09", 'href="#" link used as a control: use <button>', /href *= *["']#["']/, L);
scan("LOW", "A10", "target=_blank: warn users it opens a new window (icon + text alternative)", /target *= *["']_blank/, L);

const layout = byRel.get("layout/theme.liquid");
if (layout) {
  if (!/skip|#MainContent|id="MainContent"/i.test(layout.text)) emit("MED", "A14", layout.rel, 1, "No skip link found in layout (WCAG 2.4.1)");
  if (!/<main/.test(layout.text)) emit("MED", "A15", layout.rel, 1, "No <main> landmark in layout");
}

// Tag-aware checks (multi-line tags, Liquid inside tags): A05 A08 A11 A12 A13
const evalTag = (f, name, buf, ln) => {
  const l = name.toLowerCase();
  if (l === "img") {
    if (!/[ \t]alt([ \t]*=|[ \t]|$)/.test(buf)) emit("MED", "A05", f, ln, '<img> without an alt attribute (use image_tag, or alt="" if decorative)');
  } else if (l === "video" || l === "audio") {
    if (/[ \t]autoplay([ \t=]|$)/.test(buf)) {
      if (!/[ \t]muted([ \t=]|$)/.test(buf)) emit("MED", "A08", f, ln, "autoplay without muted: no unexpected audio (WCAG 1.4.2); add a pause control (2.2.2)");
      else emit("LOW", "A08", f, ln, "muted autoplay: verify a visible pause control (WCAG 2.2.2)");
    }
  } else if (l === "a" || l === "div" || l === "span") {
    if (/role[ \t]*=[ \t]*["']button["']/.test(buf)) {
      if (/data-bs-toggle|data-toggle/.test(buf)) emit("LOW", "A11", f, ln, "role=button with a Bootstrap data-bs-toggle: Bootstrap JS handles activation; verify Space and Enter work and aria-expanded updates (WCAG 4.1.2)");
      else emit("MED", "A11", f, ln, "role=button on a non-button element: prefer <button> with native keyboard support");
    }
  } else if (l === "html") {
    if (!/lang[ \t]*=/.test(buf)) emit("HIGH", "A12", f, ln, "<html> has no lang attribute (WCAG 3.1.1)");
    else if (/lang[ \t]*=[ \t]*["']en["']/.test(buf)) emit("LOW", "A13", f, ln, "lang hardcoded to en: use {{ request.locale.iso_code }}");
  }
};
const BLOCKS = "doc|comment|schema|raw|javascript|stylesheet|style";
const openRe = new RegExp(`[{]%-? *(${BLOCKS}) *-?%[}]`), endRe = new RegExp(`[{]%-? *end(${BLOCKS})`), endFullRe = new RegExp(`[{]%-? *end(${BLOCKS}) *-?%[}]`);
for (const f of L) {
  let skip = false, inliq = false, intag = false, rawskip = "", liqclose = "", tagbuf = "", tagname = "", tagline = 0;
  f.lines.forEach((line, idx) => {
    if (rawskip) { if (line.toLowerCase().includes("</" + rawskip)) rawskip = ""; return; }
    if (!intag && !inliq && !skip && openRe.test(line) && !endRe.test(line)) { skip = true; return; }
    if (skip) { if (endFullRe.test(line)) skip = false; return; }
    const n = line.length;
    for (let i = 0; i < n; i++) {
      const c = line[i], c2 = line.substr(i, 2);
      if (inliq) {
        if ((liqclose === "%}" && c2 === "%}") || (liqclose === "}}" && c2 === "}}")) { inliq = false; if (intag) tagbuf += c2; i++; }
        else if (intag) tagbuf += c;
        continue;
      }
      if (c2 === "{%") { inliq = true; liqclose = "%}"; if (intag) tagbuf += c2; i++; continue; }
      if (c2 === "{{") { inliq = true; liqclose = "}}"; if (intag) tagbuf += c2; i++; continue; }
      if (intag) {
        if (c === ">") {
          evalTag(f.rel, tagname, tagbuf, tagline); intag = false;
          const lt = tagname.toLowerCase();
          if (lt === "script" || lt === "style") { if (!line.slice(i + 1).toLowerCase().includes("</" + lt)) rawskip = lt; }
        } else tagbuf += c;
        continue;
      }
      if (c === "<") {
        const m = /^[A-Za-z][A-Za-z0-9-]*/.exec(line.slice(i + 1));
        if (m) { tagname = m[0]; intag = true; tagbuf = ""; tagline = idx + 1; i += m[0].length; }
      }
    }
    if (intag) tagbuf += " ";
  });
}
scan("MED", "A08", "video_tag with autoplay and no muted: no unexpected audio (WCAG 1.4.2)", /video_tag[^%}]*autoplay *: *true/, L, { drop: /muted *: *true/ });

for (const f of L) { // multiple h1 in one file
  const n = (f.text.match(/<h1/g) || []).length;
  if (n > 1) { let last = 0; f.lines.forEach((l, i) => { if (/<h1/.test(l)) last = i + 1; }); emit("LOW", "A16", f.rel, last, `${n} <h1> in this file: verify only one renders per page (conditional is fine)`); }
}

// ---------------------------------------------------------------- Performance
scan("HIGH", "P01", "{% include %} is deprecated: use {% render %}", /\{%-? *include /, L);
scan("HIGH", "P02", "document.write blocks parsing", /document\.write *\(/, LJ);
scan("HIGH", "P03", "<script src> without defer/async/module: render-blocking", /<script[^>]*[ ]src *=/, L, { drop: /defer|async|type="module"|type='module'/ });
scan("MED", "P04", "jQuery usage: not needed in modern themes", /jQuery *\(|\$\(document\)|\$\(["'][.#a-zA-Z]|jquery([.-][0-9]|(\.min)?\.js)/, LJ, { drop: /^\s*(\*|\/\/|\/\*)/ });
scan("MED", "P05", "CSS background-image for content/hero: LCP image should be <img> (check if this is the hero)", /background-image *: *url|style *= *"[^"]*background-image/, LC,
  { sev: (rel) => (/hero|banner|slideshow|main-product|image-with|section\.liquid$/.test(rel) ? "MED" : "LOW") });
scan("HIGH", "P06", "loading=lazy together with fetchpriority=high: contradictory; LCP image must be eager", /loading *= *["']lazy["'][^>]*fetchpriority *= *["']high|fetchpriority *= *["']high["'][^>]*loading *= *["']lazy/, L);
for (const f of liquid) {
  const base = f.rel.split("/").pop(), dirOf = f.rel.split("/")[0];
  const heroLike = (dirOf === "sections" && f.rel.split("/").length === 2 && /hero|image-banner|slideshow|main-product|image-with/.test(base)) || (dirOf === "snippets" && f.rel.split("/").length === 2 && /hero/.test(base));
  if (!heroLike) continue;
  if (/section\.index|forloop\.first|fetchpriority/.test(f.text)) continue;
  f.lines.forEach((l, i) => { if (/loading *[:=] *["']?lazy/.test(l)) emit("MED", "P07", f.rel, i + 1, "lazy loading in a likely above-the-fold file: first image must be eager + fetchpriority=high (use section.index)"); });
}
scan("MED", "P08", "Hardcoded Shopify CDN URL: use image_url / image_tag or asset_url", /cdn\.shopify\.com/, L, { drop: /preconnect|shopifycloud|\/storefront\// });
scan("MED", "P09", "img_url is deprecated: use image_url + image_tag", /\| *img_url/, L);
scan("MED", "P10", "External font host: self-host on Shopify CDN (/assets) or use system fonts", /fonts\.googleapis\.com|fonts\.gstatic\.com|use\.typekit\.net|use\.fontawesome\.com/, ALL);
scan("LOW", "P11", "!important: fix specificity instead", /!important/, LC);
scan("MED", "P12", "Iterating all product.variants: check if first variant / options_with_values is enough", /for +[a-z_]+ +in +[a-z_]*\.?variants/, L);
scan("MED", "P13", "Dynamic metafield key or metafield read: ensure it is outside loops", /\.metafields\[/, L);

// nested loops: catalog-scale loops nested 2+ deep are High; bounded loops (menu links) are only noted
for (const f of L) {
  let depth = 0; const cat = [];
  const count = () => { let c = 0; for (let i = 1; i <= depth; i++) c += cat[i] || 0; return c; };
  f.lines.forEach((l, idx) => {
    const NR = idx + 1;
    if (/[{]%-? *for /.test(l)) {
      depth++;
      cat[depth] = /in +(collection\.products|collections|all_products|search\.results|[a-z_.]*\.variants|[a-z_.]*\.options|[a-z_]+\.products)/.test(l) ? 1 : 0;
      if (depth >= 3) {
        const c = count();
        if (c >= 2) emit("HIGH", "P14", f.rel, NR, `Loop depth ${depth} over catalog data (products/variants/options): quadratic rendering, the main cause of high TTFB`);
        else if (c === 1) emit("MED", "P14", f.rel, NR, `Loop depth ${depth} including a catalog loop: check cost on large catalogs`);
        else emit("LOW", "P14", f.rel, NR, `Loop depth ${depth} (bounded data such as menu links): fine unless the lists are large`);
      }
    }
    if (depth >= 1 && /\.metafields\./.test(l) && count() >= 1) emit("MED", "P15", f.rel, NR, "Metafield access inside a catalog loop: move it outside or use theme settings");
    if (/[{]%-? *endfor/.test(l)) { if (depth > 0) depth--; }
  });
}

if (layout) {
  const ns = layout.lines.filter((l) => /rel *= *["']stylesheet|stylesheet_tag/.test(l)).length;
  if (ns > 5) emit("MED", "P16", layout.rel, 1, `${ns} stylesheet links in layout (conditional ones included): verify the count loaded per page`);
  const np = layout.lines.filter((l) => /rel *= *["']preload/.test(l)).length;
  if (np > 2) emit("MED", "P17", layout.rel, 1, `${np} preload hints in layout: keep to 1 or 2`);
  if (!/content_for_header/.test(layout.text)) emit("HIGH", "S00", layout.rel, 1, "content_for_header missing: required by Shopify");
}

// ---------------------------------------------------------------- SEO
if (layout) {
  const metaFiles = [layout, ...files.filter((f) => f.rel.startsWith("snippets/") && /canonical_url|page_title|page_description|og:title/.test(f.text))];
  const any = (re) => metaFiles.some((f) => re.test(f.text));
  if (!any(/canonical_url/)) emit("HIGH", "S01", layout.rel, 1, "No canonical_url tag found in layout or meta snippets");
  if (!any(/page_title|<title/)) emit("HIGH", "S02", layout.rel, 1, "No <title>/page_title found");
  if (!any(/page_description/)) emit("MED", "S03", layout.rel, 1, "No meta description from page_description found");
  if (!any(/og:title|meta-tags/)) emit("LOW", "S04", layout.rel, 1, "No Open Graph tags found");
}
scan("MED", "S05", "Hardcoded canonical: use {{ canonical_url }}", /rel *= *["']canonical["']/, L, { dropWindow: /canonical_url/ });
scan("MED", "S06", "Hardcoded Product JSON-LD: use {{ product | structured_data }} and avoid duplicate Product blocks", /"@type" *: *"Product"/, L);
scan("LOW", "S07", "noindex found: confirm this is intended", /noindex/, L);
scan("LOW", "S08", "Collection-scoped product URL (within:): prefer canonical product.url for internal links", /\| *within *:/, L);
for (const f of liquid) {
  const parts = f.rel.split("/"); if (parts.length !== 2) continue;
  const base = parts[1];
  const hdr = (parts[0] === "snippets" && /header|logo/.test(base)) || (parts[0] === "sections" && /header/.test(base));
  if (!hdr || /password/.test(f.rel)) continue;
  if (/(page_type|template\.name|template) *== *['"]index['"]/.test(f.text)) continue;
  f.lines.forEach((l, i) => { if (/<h1/.test(l)) emit("MED", "S09", f.rel, i + 1, "<h1> in header/logo: the logo should not be the h1 on inner pages"); });
}
if (!byRelAny("templates/robots.txt.liquid")) emit("LOW", "S10", "templates/robots.txt.liquid", 1, "No robots.txt.liquid (optional): consider if tag/facet crawl control is needed");
function byRelAny(rel) { return fs.existsSync(path.join(root, rel)); }

// ---------------------------------------------------------------- Standards
scan("MED", "T01", "Hardcoded English in markup: use {{ 'key' | t }} (verify)", />[A-Z][a-z]+( [a-z]+){1,6}</, L, { drop: /^\s*"[A-Za-z_]+" *:|@param|@example|\{%-? *doc/ });
scan("LOW", "T02", "Inline style attribute: use CSS variables / {% style %}", / style *= *"[^{]*[a-z-]+ *:/, L);

// ---------------------------------------------------------------- output
const order = { HIGH: 0, MED: 1, LOW: 2 };
findings.sort((a, b) => order[a.sev] - order[b.sev]); // stable: keeps discovery order within a severity
const count = (s) => findings.filter((f) => f.sev === s).length;
const HIGH = count("HIGH"), MED = count("MED"), LOW = count("LOW");
const shown = findings.filter((f) => f.sev !== "LOW" || verbose);
if (group) {
  const groups = new Map();
  for (const f of shown) { const k = f.sev + "|" + f.rule + "|" + f.msg; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(f); }
  const done = new Set();
  for (const f of shown) {
    const k = f.sev + "|" + f.rule + "|" + f.msg, g = groups.get(k);
    if (g.length <= 3 || f.sev === "HIGH") { console.log(`${f.sev} | ${f.rule} | ${f.file}:${f.line} | ${f.msg}`); continue; }
    if (done.has(k)) continue; done.add(k);
    const filesN = new Set(g.map((x) => x.file)).size;
    const sample = g.slice(0, 3).map((x) => `${x.file}:${x.line}`).join(", ");
    console.log(`${f.sev} | ${f.rule} | ${g[0].file}:${g[0].line} | ${f.msg}  [x${g.length} in ${filesN} file${filesN > 1 ? "s" : ""}; first: ${sample}; use --no-group to list all]`);
  }
} else for (const f of shown) console.log(`${f.sev} | ${f.rule} | ${f.file}:${f.line} | ${f.msg}`);
console.log();
console.log(`Summary: HIGH=${HIGH}  MED=${MED}  LOW=${LOW}${!verbose && LOW > 0 ? " (LOW hidden, use --verbose)" : ""}   Static checks only: also run theme check, keyboard + screen reader tests, Lighthouse.`);
if (!noFail && (HIGH > 0 || (failOn === "med" && MED > 0))) process.exit(1);
process.exit(0);
