#!/usr/bin/env node
/**
 * theme-check.mjs: runs Shopify Theme Check (the engine behind `shopify theme check`) without the Shopify CLI.
 * Usage: node theme-check.mjs [theme-dir] [--warnings-fail] [--max N]
 * Prints SEV | Check | file:line | message (paths relative to the theme folder), then a summary.
 * Exit: 0 no errors, 1 errors (or warnings with --warnings-fail), 2 engine missing or could not run.
 * The engine comes from the npm package @shopify/theme-check-node (installed into scripts/qa/ by setup-project).
 */
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath, pathToFileURL } from "node:url";

/** file:// URI (POSIX or Windows, e.g. file:///c:/Users/a%20b/theme/x.liquid) to a path relative to root. Pure function (tested). */
export function toRelative(uri, root) {
  let p = decodeURIComponent(String(uri).replace(/^file:\/\//, ""));
  if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1); // /c:/Users -> c:/Users
  p = p.replace(/\\/g, "/");
  const r = String(root).replace(/\\/g, "/").replace(/\/+$/, "");
  const win = /^[A-Za-z]:/.test(r);
  const a = win ? p.toLowerCase() : p, b = win ? r.toLowerCase() : r;
  return a.startsWith(b + "/") ? p.slice(r.length + 1) : p;
}

/** Theme Check builds file:// URLs from this path and rejects relative ones on Windows, so always resolve it. (tested) */
export const resolveRoot = (dir) => path.resolve(dir);

async function main() {
  const args = process.argv.slice(2);
  let dir = ".", warnFail = false, max = 60;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--warnings-fail") warnFail = true;
    else if (args[i] === "--max") max = parseInt(args[++i], 10) || 60;
    else dir = args[i];
  }
  const root = resolveRoot(dir);
  if (!fs.existsSync(root)) { console.log(`Cannot open ${dir}`); process.exit(2); }

  const here = path.dirname(fileURLToPath(import.meta.url));
  const bases = [path.join(here, "package.json"), path.join(here, "qa", "package.json"), path.join(process.cwd(), "scripts", "qa", "package.json"), path.join(process.cwd(), "tests", "package.json")];
  let check = null;
  for (const b of bases) { try { ({ check } = createRequire(b)("@shopify/theme-check-node")); break; } catch { /* try next location */ } }
  if (!check) {
    console.log("Theme Check engine not found. Install it once: npm install --no-audit --no-fund --prefix scripts/qa (setup-project does this), or use the Shopify CLI: shopify theme check");
    process.exit(2);
  }
  try {
    const offenses = await check(root);
    const name = (s) => (s === 0 ? "ERROR" : s === 1 ? "WARN" : "INFO");
    const sorted = [...offenses].sort((a, b) => a.severity - b.severity);
    for (const o of sorted.slice(0, max)) console.log(`${name(o.severity)} | ${o.check} | ${toRelative(o.uri, root)}:${o.start.line + 1} | ${o.message}`);
    if (sorted.length > max) console.log(`... ${sorted.length - max} more (use --max ${sorted.length})`);
    const errors = offenses.filter((o) => o.severity === 0).length, warns = offenses.filter((o) => o.severity === 1).length;
    console.log(`\nSummary: errors=${errors} warnings=${warns} total=${offenses.length}`);
    process.exit(errors || (warnFail && warns) ? 1 : 0);
  } catch (e) { console.log("Theme Check failed: " + e.message); process.exit(2); }
}
if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) main();
